package com.capg.airline.dao;

public interface IQueryMap {
	public static final String QUERY_LOGIN="SELECT password FROM USERS WHERE UPPER(username)=? and UPPER(role)=?";
	public static final String CHECK_LOGIN="SELECT password, role FROM USERS WHERE username=?";

	public static final String SEARCH_BY_FLIGHTNO="SELECT * FROM FLIGHT_INFO WHERE flightno=?";
	public static final String SEARCH_BY_CITY="SELECT * FROM FLIGHT_INFO WHERE UPPER(ARR_CITY)=UPPER(?) AND UPPER(DEPT_CITY)=UPPER(?) AND dept_date>=sysdate ORDER BY dept_date";
	public static final String CHECK_FIRST_CLASS_SEAT_MAX_NO_RESERVED="SELECT MAX(seat_number) from BOOKING_INFO where flightno=? and class_type=?";
	public static final String CHECK_BUSINESS_CLASS_SEAT_MAX_NO_RESERVED="SELECT MAX(seat_number) from BOOKING_INFO where flightno=? and class_type=?";
	public static final String NO_OF_FIRST_CLASS_SEATS="SELECT no_of_first_seats FROM flight_info where flightno=?";
	public static final String NO_OF_BUSINESS_CLASS_SEATS="SELECT no_of_business_seats FROM flight_info where flightno=?";
	public static final String NO_OF_BOTH_CLASS_SEATS="SELECT no_of_first_seats,no_of_business_seats FROM flight_info where flightno=?";
	public static final String GET_FIRST_CLASS_FARE_COST="SELECT first_seat_fare from flight_info where flightno=?";
	public static final String GET_BUSINESS_CLASS_FARE_COST="SELECT business_seat_fare from flight_info where flightno=?";
	public static final String GET_BOOKING_ID_SEQ_VALUE="SELECT to_char(BOOKING_ID_SEQ.CURRVAL) FROM DUAL";
	public static final String CONFIRM_BOOKING="INSERT INTO BOOKING_INFO VALUES(to_char(BOOKING_ID_SEQ.nextval),?,1,?,?,?,?,?,?,?)";
	public static final String CHECK_BOOKING_ID="SELECT flightno from Booking_info where booking_id=?";
	public static final String UPDATE_MAIL_ID="	UPDATE BOOKING_INFO SET cust_email=? where booking_id=?";
	public static final String CANCEL_RESERVATION="DELETE FROM Booking_info where booking_id=?";
	
	
	public static final String TOTAL_BOOKED_SEATS="SELECT COUNT(BOOKING_ID) FROM BOOKING_INFO";
	public static final String FUTURE_BOOKED_SEATS="SELECT COUNT(BOOKING_ID) FROM BOOKING_INFO, FLIGHT_INFO WHERE BOOKING_INFO.flightno=FLIGHT_INFO.flightno and dept_date>=sysdate";
	public static final String AIRLINE_EXECUTIVE_SIGNUP="INSERT INTO USERS VALUES(to_char(AIRLINE_EXECUTIVE_ID_SEQ.nextval),to_char(AIRLINE_EXECUTIVE_ID_SEQ.currval), 'AIRLINE EXECUTIVE',?)";
	public static final String ADMIN_SIGNUP="INSERT INTO USERS VALUES(to_char(ADMIN_ID_SEQ.nextval),to_char(ADMIN_ID_SEQ.currval),'ADMIN',?)";
	public static final String GET_ADMIN_ID_SEQ_VALUE="SELECT to_char(ADMIN_ID_SEQ.CURRVAL) FROM DUAL";
	public static final String GET_AIRLINE_EXECUTIVE_ID_SEQ_VALUE="SELECT to_char(AIRLINE_EXECUTIVE_ID_SEQ.CURRVAL) FROM DUAL";

	public static final String CHECK_IF_FLIGHTNO_EXIST="SELECT * FROM FLIGHT_INFO WHERE flightno=? AND DEPT_DATE>=SYSDATE";
	public static final String UPDATE_FIRST_CLASS_SEAT="UPDATE FLIGHT_INFO SET no_of_first_seats=? where flightno=?";
	public static final String UPDATE_BUSINESS_CLASS_SEAT="UPDATE FLIGHT_INFO SET no_of_business_seats=? where flightno=?";
	public static final String UPDATE_ARR_DATE="UPDATE FLIGHT_INFO SET arr_date=TO_DATE(?, 'yyyy/mm/dd hh24:mi:ss') where flightno=?";
	public static final String UPDATE_DEPT_DATE="UPDATE FLIGHT_INFO SET dept_date=TO_DATE(?, 'yyyy/mm/dd hh24:mi:ss') where flightno=?";
	public static final String UPDATE_FIRST_CLASS_FARE="UPDATE FLIGHT_INFO SET first_seat_fare=? where flightno=?";
	public static final String UPDATE_BUSINESS_CLASS_FARE="UPDATE FLIGHT_INFO SET business_seat_fare=?  where flightno=?";

	public static final String FLIGHTS_DEPART_ON_DATE="SELECT * FROM FLIGHT_INFO WHERE trunc(dept_date)=to_date(?,'yyyy/mm/dd')";
	public static final String FLIGHTS_DEPART_FROM_CITY="SELECT * FROM FLIGHT_INFO WHERE UPPER(dept_city)=upper(?) and dept_date>=sysdate";
	public static final String FLIGHTS_ARRIVING_TO_CITY="SELECT * FROM FLIGHT_INFO WHERE UPPER(arr_city)=upper(?) and dept_date>=sysdate";
	public static final String BOOKING_LIST_OF_FLIGHT="SELECT * FROM BOOKING_INFO WHERE flightno=?";
}

