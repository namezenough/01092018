package com.capg.airline.service;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.dao.CombinedDAOImpl;
import com.capg.airline.dao.ICombinedDAO;
import com.capg.airline.exception.MyAirlineException;

public class CombinedServImpl implements ICombinedServ {

	ICombinedDAO comDaoObj=null;
	public CombinedServImpl(){
		comDaoObj=new CombinedDAOImpl();
	}
	@Override
	public int checkLogin(AirlineBean bean) throws MyAirlineException{
		// TODO Auto-generated method stub
		return comDaoObj.checkLogin(bean);
	}

}
