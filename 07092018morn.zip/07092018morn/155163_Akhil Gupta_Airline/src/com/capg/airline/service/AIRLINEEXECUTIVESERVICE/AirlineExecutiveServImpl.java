package com.capg.airline.service.AIRLINEEXECUTIVESERVICE;

import java.util.ArrayList;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.dao.AIRLINEEXECUTIVEDAO.AirlineExecutiveDAO;
import com.capg.airline.exception.MyAirlineException;

public class AirlineExecutiveServImpl implements IAirlineExecutiveServ {

	AirlineExecutiveDAO daoae=null;
	 public AirlineExecutiveServImpl() {
		 	daoae=new AirlineExecutiveDAO();
	 }
		
	
	@Override
	public int checkAirlineExecutiveLogin(AirlineBean bean)  throws MyAirlineException{
	
		
		return daoae.checkAirlineExecutiveLogin(bean);
	}

	
	
	
	
	@Override
	public int totalBookedSeats()  throws MyAirlineException{
		
		return daoae.totalBookedSeats();
	}


	@Override
	public int futureBookedSeats()  throws MyAirlineException{
		// TODO Auto-generated method stub
		return daoae.futureBookedSeats();
	}


	
	
	
	@Override
	public ArrayList<AirlineBean> checkOccupancy(AirlineBean bean) throws MyAirlineException {
		// TODO Auto-generated method stub
		return daoae.checkOccupancy(bean);
	}

}
