package com.capg.airline.service.CUSTOMERSERVICE;

import java.util.ArrayList;
import java.util.LinkedHashMap;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.exception.MyAirlineException;

public interface ICustomerServ {
	public abstract AirlineBean searchFlightByNo(AirlineBean bean) throws MyAirlineException;
	public abstract LinkedHashMap<String, AirlineBean> searchByCity(AirlineBean bean) throws MyAirlineException;
	public abstract int checkAvailability(AirlineBean bean) throws MyAirlineException;
	public abstract ArrayList<String > confirmBoking(AirlineBean bean) throws MyAirlineException;
	public abstract String checkBookingId(AirlineBean bean) throws MyAirlineException;
	public abstract int updateMailId(AirlineBean bean) throws MyAirlineException;
	public abstract int cancelReservation(AirlineBean bean) throws MyAirlineException;


}
