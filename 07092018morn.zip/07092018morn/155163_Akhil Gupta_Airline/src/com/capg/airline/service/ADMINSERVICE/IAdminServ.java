package com.capg.airline.service.ADMINSERVICE;

import java.util.ArrayList;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.exception.MyAirlineException;

public interface IAdminServ {
	public abstract int checkAdminLogin(AirlineBean bean) throws MyAirlineException;
	public abstract int airlineExecutiveSignUp(AirlineBean bean) throws MyAirlineException;
	public abstract int adminSignUp(AirlineBean bean) throws MyAirlineException;
	public abstract int checkIfFlightnoExist(AirlineBean bean) throws MyAirlineException;
	public abstract int increaseFirstClassSeats(AirlineBean bean) throws MyAirlineException;
	public abstract int increaseBusinessClassSeats(AirlineBean bean) throws MyAirlineException;
	public abstract int decreaseFirstClassSeats(AirlineBean bean) throws MyAirlineException;
	public abstract int decreaseBusinessClassSeats(AirlineBean bean) throws MyAirlineException;
	public abstract int updateFlightTiming(AirlineBean bean) throws MyAirlineException;
	public abstract int updateFirstCLassFare(AirlineBean bean) throws MyAirlineException;
	public abstract int updateBusinessCLassFare(AirlineBean bean) throws MyAirlineException;
	public abstract ArrayList<AirlineBean> flightsDepartingOnDate(AirlineBean bean) throws MyAirlineException;
	public abstract ArrayList<AirlineBean> flightsDepartingFromCity(AirlineBean bean) throws MyAirlineException;
	public abstract ArrayList<AirlineBean> flightsArrivingToCity(AirlineBean bean) throws MyAirlineException;
	public abstract ArrayList<AirlineBean> bookingListOfFlight(AirlineBean bean) throws MyAirlineException;


}
