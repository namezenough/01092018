package com.capg.airline.service;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.exception.MyAirlineException;

public interface ICombinedServ {
	public abstract int checkLogin(AirlineBean bean) throws MyAirlineException;
 
}
