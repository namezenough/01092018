package com.capg.airline.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capg.airline.exception.MyAirlineException;

public class AirlineValidate {

	public boolean validateMobile(String mobileNo) throws MyAirlineException {
		Matcher match=null;
		Pattern patt=Pattern.compile("[0-9]{10}");
		match=patt.matcher(mobileNo);
		if(match.matches()==false)
		{
			System.err.flush();
			System.err.println("Mobile no should be of 10 digits");
		}
		return match.matches();
	}	
}
