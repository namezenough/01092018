package com.capg.airline.ui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;



import com.capg.airline.beans.AirlineBean;
import com.capg.airline.exception.MyAirlineException;
import com.capg.airline.service.AIRLINEEXECUTIVESERVICE.AirlineExecutiveServImpl;

public class AirlineExecutiveUi {
	Scanner scanner=new Scanner(System.in);
	AirlineExecutiveServImpl aeservobj=new AirlineExecutiveServImpl();
	AirlineBean bean=new AirlineBean();
	int loop=0;
	int logincheck=0;
int AirlineExecutive() throws MyAirlineException{
	
	
	String innercount;
	
	if(loop==0){
		System.out.println("Press 1 to Log Out");
		System.out.println("Press 2 to exit ");
		System.out.println("Press any other key to continue as Airline Executive");
		
		innercount=scanner.next();
		if(innercount.equals("1"))
		{
			
			return 100;							
			
		}
		if(innercount.equals("2"))
		{
			System.out.println("Thanks for visiting us");
			
			return 4;						
			
		}
	}
				System.out.println("***Airline Executive Menu****");
				System.out.println("Press 1 for Generating Report");
				System.out.println("Press 2 to Check flight Occupancy");
				System.out.println("Press 3 to Log Out");
				System.out.println("Press 4 to exit");
				String menucount=scanner.next();
				if(menucount.equals("1")){
					System.out.println("Welcome to Report Generation");
					AEReportGeneration();
				}
				else if(menucount.equals("2")){
					AEFlightOccupancy();
				}
				else if(menucount.equals("3")){
					AirlineUi.main(null);
				}
				else if(menucount.equals("4")){
					System.out.println("Thanks for visiting us");
					System.exit(0);
					return 4;
					
				}
				else{
					System.out.println("You entered Wrong Number");
				}
		
					
		return 0;
	}  //end of AirlineExecutive method
	



	
	
	
	int AEReportGeneration()  throws MyAirlineException{
		String aeReportGenCount=null;
		System.out.println("Enter 1 to get the total no of people who have booked the flights till now from this portal.");
		System.out.println("Enter 2 to get no of poeple who have booked the flights for future.");
		aeReportGenCount=scanner.next();
		if(aeReportGenCount.equals("1")) // start of condition get the total no of people who have booked the flights till now from this portal.
		{
			int totalSeatsBooked=aeservobj.totalBookedSeats();
			if(totalSeatsBooked==0){
				System.err.println("No seat is ever booked");
			}
			else{
				System.out.println(totalSeatsBooked + " seats are booked from this portal ever.");
				System.out.println("");
				loop=1;
				logincheck=1;
				AirlineExecutive();
				
			} 
		}// end of condition: get the total no of people who have booked the flights till now from this portal.
		else if(aeReportGenCount.equals("2")){  // start of condition: to get no of poeple who have booked the flights for future.
			int futureSeatsBooked=aeservobj.futureBookedSeats();
			if(futureSeatsBooked==0){
				System.err.println("No seat is booked for future");
			}
			else{
				System.out.println(futureSeatsBooked + " seats are booked from this portal for future.");
				System.out.println("");
				loop=1;
				logincheck=1;
				AirlineExecutive();
				
			} 
			
		}// end of condition: to get no of poeple who have booked the flights for future.
		else{
			System.err.println("You entered wrong Input. Please Try Again");
			AEReportGeneration();
		}
		return 0;
	}
	
	
	
	
	
	
	int AEFlightOccupancy() throws MyAirlineException{
		System.out.println("Enter the flight no or Press 1 to go back");
		System.out.println("");
		String flightno=scanner.next();
		if(flightno.equals("1")){
			loop=1;
			logincheck=1;
			AirlineExecutive();
		}
		else{
		bean.setFlightno(flightno);
		ArrayList<AirlineBean> checkOccupancyList=new ArrayList<AirlineBean>();
		checkOccupancyList=aeservobj.checkOccupancy(bean);
		if(checkOccupancyList.isEmpty()){
			System.out.println("No such flight exist. Please try again");
			AEFlightOccupancy();
		}
		Iterator<AirlineBean> iterObj=checkOccupancyList.iterator();
		while(iterObj.hasNext()){
			AirlineBean beanobj=iterObj.next();
			System.out.println("Total First Class Seats: "+beanobj.getTotalFirstClassSeats());
			System.out.println("No of first Class seats booked: "+beanobj.getFilledFirstClassSeats());
			System.out.println("Total Business Class Seats: "+ beanobj.getTotalBusinessClassSeats());
			System.out.println("No of Business Class Seats Booked: "+beanobj.getFilledBusinessClassSeats());
			System.out.println("");
			loop=1;
			logincheck=1;
			AirlineExecutive();
		}}
		return 0;
	}
}
