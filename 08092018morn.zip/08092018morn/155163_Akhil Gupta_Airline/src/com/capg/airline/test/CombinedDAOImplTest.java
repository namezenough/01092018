package com.capg.airline.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.dao.CombinedDAOImpl;
import com.capg.airline.dao.ICombinedDAO;
import com.capg.airline.exception.MyAirlineException;

public class CombinedDAOImplTest extends CombinedDAOImpl {
ICombinedDAO combObj=new CombinedDAOImpl();
AirlineBean beanObj=new AirlineBean();
	@Test
	public void testCheckLogin() throws MyAirlineException{
		beanObj.setUser_id("00");
		assertEquals(0, combObj.checkLogin(beanObj));
		
	}

}
