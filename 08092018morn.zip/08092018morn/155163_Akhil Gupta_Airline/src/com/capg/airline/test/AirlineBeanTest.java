package com.capg.airline.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capg.airline.beans.AirlineBean;

public class AirlineBeanTest {
AirlineBean beanObj=new AirlineBean();
	@Test
	public void testGetClassType() {
		
	}

	@Test
	public void testGetNoOfBookings() {
		beanObj.setNoOfBookings(1);
		assertEquals(1, beanObj.getNoOfBookings());
		
	}

	@Test
	public void testGetFirstClassFare() {
		beanObj.setFirstClassFare(100);
		assertEquals(100,beanObj.getFirstClassFare());
		}

	@Test
	public void testGetBusinessClassFare() {
		beanObj.setBusinessClassFare(100);
		assertEquals(100,beanObj.getBusinessClassFare() );
		}

	@Test
	public void testGetFirstSeatInc() {
		beanObj.setFirstSeatInc(1);
		assertEquals(1,beanObj.getFirstSeatInc() );
		}

	@Test
	public void testGetBusinessSeatInc() {
		beanObj.setBusinessSeatInc(1);
		assertEquals(1,beanObj.getBusinessSeatInc() );
		}

	@Test
	public void testGetFirstSeatDec() {
		beanObj.setFirstSeatDec(1);
		assertEquals(1,beanObj.getFirstSeatDec() );
		}

	@Test
	public void testGetBusinessSeatDec() {
		beanObj.setBusinessSeatDec(1);
		assertEquals(1,beanObj.getBusinessSeatDec() );}

	@Test
	public void testGetMobileNo() {
		String s="123";
		Long l=Long.parseLong(s);
		beanObj.setMobileNo(l);
		assertEquals(l,beanObj.getMobileNo() );
		}

	@Test
	public void testGetTotalFirstClassSeats() {
		beanObj.setTotalFirstClassSeats(1);
		assertEquals(1,beanObj.getTotalFirstClassSeats() );
		}

	@Test
	public void testSetFilledFirstClassSeats() {
		beanObj.setFilledFirstClassSeats(1);
		assertEquals(1,beanObj.getFilledFirstClassSeats() );	}

	@Test
	public void testGetTotalBusinessClassSeats() {
		beanObj.setTotalBusinessClassSeats(1);
		assertEquals(1,beanObj.getTotalBusinessClassSeats() );	}

	@Test
	public void testGetFilledBusinessClassSeats() {
		beanObj.setFilledBusinessClassSeats(1);
		assertEquals(1,beanObj.getFilledBusinessClassSeats() );	}

	@Test
	public void testGetBookingId() {
		beanObj.setBookingId("1");
		assertEquals("1",beanObj.getBookingId() );	}

	@Test
	public void testGetFareCost() {
		beanObj.setFareCost(1);
		assertEquals(1,beanObj.getFareCost() );	}

	@Test
	public void testGetEmailID() {
		beanObj.setEmailID("a");
		assertEquals("a",beanObj.getEmailID() );	}

	@Test
	public void testGetCreditcardno() {
		beanObj.setCreditcardno("1");
		assertEquals("1",beanObj.getCreditcardno() );	}

	@Test
	public void testGetSeatNoToBeBooked() {
		beanObj.setSeatNoToBeBooked(1);
		assertEquals(1,beanObj.getSeatNoToBeBooked() );	}

	@Test
	public void testGetFlightClass() {
		beanObj.setFlightClass("a");
		assertEquals("a",beanObj.getFlightClass() );	
		}

	@Test
	public void testGetAirline() {
		beanObj.setAirline("a");
		assertEquals("a",beanObj.getAirline() );
		}

	@Test
	public void testGetDeptCity() {
		beanObj.setDeptCity("a");
		assertEquals("a",beanObj.getDeptCity() );
		}

	@Test
	public void testGetArrCity() {
		beanObj.setArrCity("a");
		assertEquals("a",beanObj.getArrCity() );	
		}

	@Test
	public void testGetDeptDate() {
		beanObj.setDeptDate("2018/05/05");
		assertEquals("2018/05/05",beanObj.getDeptDate() );
		}

	@Test
	public void testGetDeptTime() {
		beanObj.setDeptTime("20:11:11");
		assertEquals("20:11:11",beanObj.getDeptTime() );	
		}

	@Test
	public void testGetArrDate() {
		beanObj.setArrDate("2018/05/11");
		assertEquals("2018/05/11",beanObj.getArrDate() );	
		}

	@Test
	public void testGetArrTime() {
		beanObj.setArrTime("20:11:12");
		assertEquals("20:11:12",beanObj.getArrTime());	
		}

	@Test
	public void testGetFlightno() {
		beanObj.setFlightno("1");
		assertEquals("1",beanObj.getFlightno() );	
		}

	@Test
	public void testGetUser_id() {
		beanObj.setUser_id("1");
		assertEquals("1",beanObj.getUser_id() );	
		}

	@Test
	public void testGetRole() {
		beanObj.setRole("ADMIN");
		assertEquals("ADMIN",beanObj.getRole() );	
		}

	@Test
	public void testGetUser_password() {
		beanObj.setUser_password("1");
		assertEquals("1",beanObj.getUser_password() );	
		}

}
