package com.capg.airline.test;

import static org.junit.Assert.*;

import org.junit.Test;
import com.capg.airline.dao.AIRLINEEXECUTIVEDAO.AirlineExecutiveDAO;
import com.capg.airline.dao.AIRLINEEXECUTIVEDAO.IAirlineExecutiveDAO;
import com.capg.airline.exception.MyAirlineException;

public class AirlineExecutiveDAOTest {
IAirlineExecutiveDAO executiveObj=new AirlineExecutiveDAO();
	

	@Test
	public void testTotalBookedSeats() throws MyAirlineException {
		assertNotEquals(1,executiveObj.totalBookedSeats());
	}

	@Test
	public void testFutureBookedSeats()throws MyAirlineException {
	assertNotEquals(1, executiveObj.futureBookedSeats());
	}
	


}
