package com.capg.airline.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.dao.CUSTOMERDAO.CustomerDAO;
import com.capg.airline.dao.CUSTOMERDAO.ICustomerDAO;
import com.capg.airline.exception.MyAirlineException;

public class CustomerDAOTest extends CustomerDAO {

	ICustomerDAO custObj=new CustomerDAO();
	AirlineBean beanObj=new AirlineBean();
	@Test
	public void testCheckAvailability() throws MyAirlineException{
		beanObj.setFlightClass("FLIRST CLASS");
		beanObj.setFlightno("000");
		assertEquals(-1,custObj.checkAvailability(beanObj));
	}


	
	
	
	
	
	@Test
	public void testCheckBookingId() throws MyAirlineException{
		beanObj.setBookingId("00");
		assertEquals(null, custObj.checkBookingId(beanObj));
	}

	
	
	
	
	
	
	@Test
	public void testUpdateMailId() throws MyAirlineException {
		beanObj.setEmailID("abc@xyz.com");
		beanObj.setBookingId("00");
		assertEquals(0, custObj.updateMailId(beanObj));
	}

	
	
	
	
	
	@Test
	public void testCancelReservation() throws MyAirlineException {
		beanObj.setBookingId("000");
		assertEquals(0, custObj.cancelReservation(beanObj));
	}

}
