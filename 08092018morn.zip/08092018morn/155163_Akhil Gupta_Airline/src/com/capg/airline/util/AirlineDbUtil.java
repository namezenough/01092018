package com.capg.airline.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;





public class AirlineDbUtil {
	public static Connection getConnection() {
		Connection conn=null;
		 //Object of logger is created
		 try {                                  //try starts here
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg212","training212");  //to set database path
		}										//try ends here
		 catch (ClassNotFoundException | SQLException e) {   
			 
			System.out.println(e);
		}
		 
		 
			
		 return conn;
		 
	}
}
