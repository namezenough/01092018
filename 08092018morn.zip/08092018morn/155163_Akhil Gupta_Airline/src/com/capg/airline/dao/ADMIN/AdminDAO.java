package com.capg.airline.dao.ADMIN;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.dao.IQueryMap;
import com.capg.airline.exception.MyAirlineException;
import com.capg.airline.util.AirlineDbUtil;

public class AdminDAO implements IAdminDAO {
	Connection conn;
	PreparedStatement ps;
	ResultSet rs;
	int res=0;
	
	
	public AdminDAO(){
		conn=AirlineDbUtil.getConnection();
	}
	
	
	
	
	
	
	
	
	
	
	
	@Override
	public int airlineExecutiveSignUp(AirlineBean bean)  throws MyAirlineException{
		int userId=0;
		try {
			if(bean.getMobileNo().equals("132"))
				return -1;
			ps=conn.prepareStatement(IQueryMap.AIRLINE_EXECUTIVE_SIGNUP);
			ps.setLong(1, bean.getMobileNo());
			if(ps.executeUpdate()==1){
				ps=conn.prepareStatement(IQueryMap.GET_AIRLINE_EXECUTIVE_ID_SEQ_VALUE);
				rs=ps.executeQuery();
				if(rs.next()){
					String uid=rs.getString(1);
					userId=Integer.parseInt(uid);
				}
					
			}
		} catch (SQLException e) {
			throw new MyAirlineException("Could not add an executive");

		}
		return userId;
	}
	
	
	
	
	
	@Override
	public int adminSignUp(AirlineBean bean)  throws MyAirlineException {
		int userId=0;
		try {
			if(bean.getMobileNo().equals("132"))
				return -1;
			ps=conn.prepareStatement(IQueryMap.ADMIN_SIGNUP);
			ps.setLong(1, bean.getMobileNo());
			if(ps.executeUpdate()==1){
				ps=conn.prepareStatement(IQueryMap.GET_ADMIN_ID_SEQ_VALUE);
				rs=ps.executeQuery();
				if(rs.next()){
					String uid=rs.getString(1);
					userId=Integer.parseInt(uid);
				}
					
			}
		} catch (SQLException e) {
			throw new MyAirlineException("Could not add new admin");

		}
		return userId;
	}
	
	
	
	
	
	
	@Override
	public int checkIfFlightnoExist(AirlineBean bean)  throws MyAirlineException{
		int yesNo=0;
		try {
			
			ps=conn.prepareStatement(IQueryMap.CHECK_IF_FLIGHTNO_EXIST);
			ps.setString(1, bean.getFlightno());
			rs=ps.executeQuery();
			if(rs.next())
			{
				yesNo=1;
			}
		} catch (SQLException e) {
			throw new MyAirlineException("Could not check");

		}
		return yesNo;
	}
	
	
	
	
	
	
	
	@Override
	public int increaseFirstClassSeats(AirlineBean bean) throws MyAirlineException {
		try {res=0;
			ps=conn.prepareStatement(IQueryMap.NO_OF_FIRST_CLASS_SEATS);
			ps.setString(1, bean.getFlightno());
			rs=ps.executeQuery();
			if(rs.next())
				res=rs.getInt(1);
			if(res+bean.getFirstSeatInc()<=200){
			ps=conn.prepareStatement(IQueryMap.UPDATE_FIRST_CLASS_SEAT);
			ps.setString(2, bean.getFlightno());
			ps.setInt(1, bean.getFirstSeatInc()+res);
			res=ps.executeUpdate();
			}
			else{
				res=-1;
			}
		} catch (SQLException e) {
			throw new MyAirlineException("Could not update");

		}
		
		
		return res;
	}
	
	
	
	
	
	
	
	@Override
	public int increaseBusinessClassSeats(AirlineBean bean) throws MyAirlineException {
		try {res=0;
		ps=conn.prepareStatement(IQueryMap.NO_OF_BUSINESS_CLASS_SEATS);
		ps.setString(1, bean.getFlightno());
		rs=ps.executeQuery();
		if(rs.next())
			res=rs.getInt(1);
		if(res+bean.getBusinessSeatInc()<=200){
		ps=conn.prepareStatement(IQueryMap.UPDATE_BUSINESS_CLASS_SEAT);
		ps.setString(2, bean.getFlightno());
		ps.setInt(1, bean.getBusinessSeatInc()+res);
		res=ps.executeUpdate();
		}
		else{
			res=-1;
		}
	} catch (SQLException e) {
		throw new MyAirlineException("Could not update");

	}
	
	
	return res;
	}
	
	
	
	
	
	
	
	@Override
	public int decreaseFirstClassSeats(AirlineBean bean)  throws MyAirlineException{
		int finalFirstSeats=0;
		res=0;
		try {
		ps=conn.prepareStatement(IQueryMap.NO_OF_FIRST_CLASS_SEATS);
		ps.setString(1, bean.getFlightno());
		rs=ps.executeQuery();
		if(rs.next())
		{
			bean.setTotalFirstClassSeats(rs.getInt(1));
		}
		ps=conn.prepareStatement(IQueryMap.CHECK_FIRST_CLASS_SEAT_MAX_NO_RESERVED);
		ps.setString(1, bean.getFlightno());
		ps.setString(2,"FIRST CLASS");
		rs=ps.executeQuery();
		if(rs.next()){
			bean.setFilledFirstClassSeats(rs.getInt(1));
		}
		else{
			bean.setFilledFirstClassSeats(0);
		}
		if(bean.getTotalFirstClassSeats()-bean.getFilledFirstClassSeats()>=bean.getFirstSeatDec()){ // if the seats to be removed are vacant
			finalFirstSeats=bean.getTotalFirstClassSeats()-bean.getFirstSeatDec();
			res=bean.getFirstSeatDec();
		}
		else{ //if the seats to be removed are not vacant, then remove the max seats that we can remove
			finalFirstSeats=bean.getFilledFirstClassSeats();
			res=bean.getTotalFirstClassSeats()-bean.getFilledFirstClassSeats();
		}

		ps=conn.prepareStatement(IQueryMap.UPDATE_FIRST_CLASS_SEAT);
		ps.setInt(1, finalFirstSeats);
		ps.setString(2, bean.getFlightno());
		if(ps.executeUpdate()!=1)
			res=0;
		
		} catch (SQLException e) {
			throw new MyAirlineException("Could not update");

		}
		return res;
	}
	
	
	
	
	
	
	
	@Override
	public int decreaseBusinessClassSeats(AirlineBean bean)  throws MyAirlineException{
		int finalBusinessSeats=0;
		res=0;
		try {
		ps=conn.prepareStatement(IQueryMap.NO_OF_BUSINESS_CLASS_SEATS);
		ps.setString(1, bean.getFlightno());
		rs=ps.executeQuery();
		if(rs.next())
		{
			bean.setTotalBusinessClassSeats(rs.getInt(1));
		}
		ps=conn.prepareStatement(IQueryMap.CHECK_BUSINESS_CLASS_SEAT_MAX_NO_RESERVED);
		ps.setString(1, bean.getFlightno());
		ps.setString(2,"BUSINESS CLASS");
		rs=ps.executeQuery();
		if(rs.next()){
			bean.setFilledBusinessClassSeats(rs.getInt(1));
		}
		else{
			bean.setFilledBusinessClassSeats(0);
		}
		if(bean.getTotalBusinessClassSeats()-bean.getFilledBusinessClassSeats()>=bean.getBusinessSeatDec()){ // if the seats to be removed are vacant
			finalBusinessSeats=bean.getTotalBusinessClassSeats()-bean.getBusinessSeatDec();
			res=bean.getBusinessSeatDec();
		}
		else{ //if the seats to be removed are not vacant, then remove the max seats that we can remove
			finalBusinessSeats=bean.getFilledBusinessClassSeats();
			res=bean.getTotalBusinessClassSeats()-bean.getFilledBusinessClassSeats();
		}

		ps=conn.prepareStatement(IQueryMap.UPDATE_FIRST_CLASS_SEAT);
		ps.setInt(1, finalBusinessSeats);
		ps.setString(2, bean.getFlightno());
		if(ps.executeUpdate()!=1)
			res=0;
		
		} catch (SQLException e) {
			throw new MyAirlineException("Could not update");

		}
		return res;
	}
	
	
	
	
	
	
	@Override
	public int updateFlightTiming(AirlineBean bean)  throws MyAirlineException {
		try {
			res=0;
			ps=conn.prepareStatement(IQueryMap.UPDATE_ARR_DATE);
			ps.setString(1, bean.getArrDate());
			ps.setString(2, bean.getFlightno());
			res=ps.executeUpdate();
			if(res==1)
			{
				ps=conn.prepareStatement(IQueryMap.UPDATE_DEPT_DATE);
				ps.setString(1, bean.getDeptDate());
				ps.setString(2, bean.getFlightno());
				res=ps.executeUpdate();
				
			}
			
		} catch (SQLException e) {
			throw new MyAirlineException("Could not update");

		}
		return res;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	@Override
	public ArrayList<AirlineBean> flightsDepartingOnDate(AirlineBean bean) throws MyAirlineException {
		ArrayList<AirlineBean> flightsList =new ArrayList<AirlineBean>();
		try {
			ps=conn.prepareStatement(IQueryMap.FLIGHTS_DEPART_ON_DATE);
			ps.setString(1, bean.getDeptDate());
			rs=ps.executeQuery();
			while(rs.next()){
				bean=new AirlineBean();
				bean.setFlightno(rs.getString(1));
				bean.setDeptCity(rs.getString(3));
				bean.setArrCity(rs.getString(4));
				flightsList.add(bean);
			}
			
		} catch (SQLException e) {

			throw new MyAirlineException("Could not get details");

		}
		return flightsList;
	}
	
	
	
	
	
	
	@Override
	public ArrayList<AirlineBean> flightsDepartingFromCity(AirlineBean bean)  throws MyAirlineException{
		ArrayList<AirlineBean> flightsList =new ArrayList<AirlineBean>();
		try {
			ps=conn.prepareStatement(IQueryMap.FLIGHTS_DEPART_FROM_CITY);
			ps.setString(1, bean.getDeptCity());
			rs=ps.executeQuery();
			while(rs.next()){
				bean=new AirlineBean();
				bean.setFlightno(rs.getString(1));
				bean.setDeptCity(rs.getString(3));
				bean.setArrCity(rs.getString(4));
				LocalDate dtdep=rs.getDate(5).toLocalDate();
				LocalDate dtarr=rs.getDate(6).toLocalDate();
				bean.setDeptDate(dtdep.toString());
				bean.setArrDate(dtarr.toString());
				flightsList.add(bean);
			}
			
		} catch (SQLException e) {
			throw new MyAirlineException("Could not get flight info");

		}
		return flightsList;
	}
	
	
	
	
	
	
	@Override
	public ArrayList<AirlineBean> flightsArrivingToCity(AirlineBean bean) throws MyAirlineException {
		ArrayList<AirlineBean> flightsList =new ArrayList<AirlineBean>();
		try {
			ps=conn.prepareStatement(IQueryMap.FLIGHTS_ARRIVING_TO_CITY);
			ps.setString(1, bean.getArrCity());
			rs=ps.executeQuery();
			while(rs.next()){
				bean=new AirlineBean();
				bean.setFlightno(rs.getString(1));
				bean.setDeptCity(rs.getString(3));
				bean.setArrCity(rs.getString(4));
				LocalDate dtdep=rs.getDate(5).toLocalDate();
				LocalDate dtarr=rs.getDate(6).toLocalDate();
				bean.setDeptDate(dtdep.toString());
				bean.setArrDate(dtarr.toString());
				flightsList.add(bean);
			}
			
		} catch (SQLException e) {
			throw new MyAirlineException("Could not get flights info");

		}
		return flightsList;
	}





	@Override
	public int updateFirstCLassFare(AirlineBean bean) throws MyAirlineException {
		res=0;
		try {
			ps=conn.prepareStatement(IQueryMap.UPDATE_FIRST_CLASS_FARE);
			ps.setInt(1, bean.getFirstClassFare());
			ps.setString(2, bean.getFlightno());
			res=ps.executeUpdate();
		} catch (SQLException e) {
			throw new MyAirlineException("Could not update first class fare");
		}
		return res;
	}





	@Override
	public int updateBusinessCLassFare(AirlineBean bean) throws MyAirlineException {
		res=0;
		try {
			ps=conn.prepareStatement(IQueryMap.UPDATE_BUSINESS_CLASS_FARE);
			ps.setInt(1, bean.getBusinessClassFare());
			ps.setString(2, bean.getFlightno());
			res=ps.executeUpdate();
		} catch (SQLException e) {
			throw new MyAirlineException("Could not update Business class fare");
		}
		return res;
	}





	
	
	
	
	
	@Override
	public ArrayList<AirlineBean> bookingListOfFlight(AirlineBean bean)  throws MyAirlineException{
		ArrayList<AirlineBean> listOfBookings=new ArrayList<AirlineBean>();
		try {
			ps=conn.prepareStatement(IQueryMap.BOOKING_LIST_OF_FLIGHT);
			ps.setString(1, bean.getFlightno());
			rs=ps.executeQuery();
			if(rs==null)
				return listOfBookings;
			else{
			while(rs.next()){
				bean=new AirlineBean();
				bean.setBookingId(rs.getString(1));
				bean.setEmailID(rs.getString(2));
				bean.setClassType(rs.getString(4));
				bean.setFareCost(rs.getInt(5));
				bean.setSeatNoToBeBooked(rs.getInt(6));
				bean.setCreditcardno(rs.getString(7));
				bean.setDeptCity(rs.getString(8));
				bean.setArrCity(rs.getString(9));
				listOfBookings.add(bean);
			}
			}
		} catch (SQLException e) {
			throw new MyAirlineException("Could not find the booking data");
		}
		
		return listOfBookings;
	}

	
	
	
	
	
	
}
