package com.capg.airline.dao.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.dao.ADMIN.AdminDAO;
import com.capg.airline.dao.ADMIN.IAdminDAO;
import com.capg.airline.exception.MyAirlineException;

public class AdminDAOTest extends AdminDAO {
IAdminDAO adminObj=new AdminDAO();
AirlineBean beanObj=new AirlineBean();
	

	@Test
	public void testAirlineExecutiveSignUp() throws MyAirlineException{
		String s="132";
		Long l=Long.parseLong(s);
		beanObj.setMobileNo(l);
		assertNotEquals(-1,adminObj.airlineExecutiveSignUp(beanObj));
		
	}
	

	
	
	
	
	@Test
	public void testAdminSignUp() throws MyAirlineException{
		String s="132";
		Long l=Long.parseLong(s);
		beanObj.setMobileNo(l);
		assertNotEquals(-1,adminObj.adminSignUp(beanObj));	}

	
	
	
	
	
	@Test
	public void testCheckIfFlightnoExist() throws MyAirlineException{
			beanObj.setFlightno("00");
			assertEquals(0,adminObj.checkIfFlightnoExist(beanObj) );
	}

	
	
	
	
	
	@Test
	public void testIncreaseFirstClassSeats() throws MyAirlineException{
		beanObj.setFlightno("000");
		beanObj.setFirstSeatInc(1000);
		assertEquals(-1,adminObj.increaseFirstClassSeats(beanObj) );	
		}

	
	
	
	
	@Test
	public void testIncreaseBusinessClassSeats() throws MyAirlineException {
		beanObj.setFlightno("000");
		beanObj.setBusinessSeatInc(1000);
		assertEquals(-1,adminObj.increaseBusinessClassSeats(beanObj) );	
		}

	
	

}
