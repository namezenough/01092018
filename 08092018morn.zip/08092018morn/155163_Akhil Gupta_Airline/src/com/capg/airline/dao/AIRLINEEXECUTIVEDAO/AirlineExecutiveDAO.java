package com.capg.airline.dao.AIRLINEEXECUTIVEDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.dao.IQueryMap;
import com.capg.airline.exception.MyAirlineException;
import com.capg.airline.util.AirlineDbUtil;

public class AirlineExecutiveDAO implements IAirlineExecutiveDAO{

	Connection conn;
	PreparedStatement ps;
	ResultSet rs;
	public AirlineExecutiveDAO() {
		
	}
	
	
	
	
	
	
	@Override
	public int totalBookedSeats()  throws MyAirlineException{
		conn=AirlineDbUtil.getConnection();
		try {
			 ps=conn.prepareStatement(IQueryMap.TOTAL_BOOKED_SEATS);
			 rs=ps.executeQuery();
			if(rs.next()){
				return rs.getInt(1);
			}
			else{
				return 0;
			}
		} catch (SQLException e) {
			throw new MyAirlineException("Problem in checking total booked seats.");
		}
		
	}

	
	
	
	
	
	@Override
	public int futureBookedSeats() throws MyAirlineException {
		conn=AirlineDbUtil.getConnection();
		try {
			 ps=conn.prepareStatement(IQueryMap.FUTURE_BOOKED_SEATS);
			 rs=ps.executeQuery();
			if(rs.next()){
				return rs.getInt(1);
			}
			else{
				return 0;
			}
		} catch (SQLException e) {
			throw new MyAirlineException("Problem in checking total booked seats.");
			
		}
		
	}

	
	
	
	
	@Override
	public ArrayList<AirlineBean> checkOccupancy(AirlineBean bean) throws MyAirlineException {
		ArrayList<AirlineBean> checkOccupancyList=new ArrayList<AirlineBean>();
		conn=AirlineDbUtil.getConnection();
		
		try {
			ps=conn.prepareStatement(IQueryMap.NO_OF_FIRST_CLASS_SEATS);
			ps.setString(1, bean.getFlightno());
			rs=ps.executeQuery();
			if(rs.next()){
				bean.setTotalFirstClassSeats(rs.getInt(1));
			}
			ps=conn.prepareStatement(IQueryMap.CHECK_FIRST_CLASS_SEAT_MAX_NO_RESERVED);
			ps.setString(1, bean.getFlightno());
			ps.setString(2,"FIRST CLASS");
			rs=ps.executeQuery();
			if(rs.next()){
				bean.setFilledFirstClassSeats(rs.getInt(1));
			}
			
			ps=conn.prepareStatement(IQueryMap.NO_OF_BUSINESS_CLASS_SEATS);
			ps.setString(1, bean.getFlightno());
			rs=ps.executeQuery();
			if(rs.next()){
				bean.setTotalBusinessClassSeats(rs.getInt(1));
			}
			ps=conn.prepareStatement(IQueryMap.CHECK_BUSINESS_CLASS_SEAT_MAX_NO_RESERVED);
			ps.setString(1, bean.getFlightno());
			ps.setString(2, "BUSINESS CLASS");
			rs=ps.executeQuery();
			if(rs.next()){
				int maxBussSeatNo=rs.getInt(1);
				if(maxBussSeatNo==0)
					bean.setFilledBusinessClassSeats(0);
				else{
				int filledBusinessSeats=maxBussSeatNo-bean.getTotalFirstClassSeats();
				bean.setFilledBusinessClassSeats(filledBusinessSeats);
				}
			}
			checkOccupancyList.add(bean);
			
		} catch (SQLException e) {
			throw new MyAirlineException("Could not check occupancy");
		}
		
		return checkOccupancyList;
	}

}
