package com.capg.airline.exception;

public class MyAirlineException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public MyAirlineException(){
		super();
	}
	public MyAirlineException(String s) {
		super(s);
	}
	

}
