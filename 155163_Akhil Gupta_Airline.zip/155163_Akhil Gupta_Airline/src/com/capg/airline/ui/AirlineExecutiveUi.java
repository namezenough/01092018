package com.capg.airline.ui;

import java.util.Scanner;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.service.AIRLINEEXECUTIVESERVICE.AirlineExecutiveServImpl;

public class AirlineExecutiveUi {

int AirlineExecutive(){
	AirlineBean bean=new AirlineBean();
	int innercount;
	int logincheck=0;
	Scanner scanner=new Scanner(System.in);
		System.out.println("Press 1 to get back to main menu, 2 to exit and 3 to continue");
		
		innercount=scanner.nextInt();
		if(innercount==1)
		{
			
			return 100;							
			
		}
		if(innercount==2)
		{
			System.out.println("Thanks for visiting us");
			
			return 4;						
			
		}
		bean.setRole("AIRLINE EXECUTIVE");
		System.out.println("Proceeded to Airline Executive.");
		System.out.println("Enter your user_id");
		bean.setUser_id(scanner.next());
		System.out.println("Enter your password");
		bean.setUser_password(scanner.next());
		AirlineExecutiveServImpl aeservobj=new AirlineExecutiveServImpl();
	 
		logincheck= aeservobj.checkAirlineExecutiveLogin(bean);
		
		if(logincheck==1)
		{
			System.out.println("Login Successful");
		}
		if(logincheck==0){
			System.out.println("Password Not Matched");
			AirlineExecutive();
		}
		if(logincheck==-1){
			System.out.println("User Not Found");
			AirlineExecutive();
		}
		
		
		
		
		
		return 0;
	}  //end of AirlineExecutive method
	
}
