package com.capg.airline.ui;

import java.util.Scanner;

import com.capg.airline.beans.AirlineBean;


public class AirlineUi {
	AirlineBean bean=new AirlineBean();
	int innercount=0;
	int count=0;
	int logincheck=0;
	String user_id;
	String user_password;
	Scanner scanner=new Scanner(System.in);
	public static void main(String[] args) {
		System.out.println("*********************************************");
		System.out.println("<------------------Airline------------------>");
		System.out.println("*********************************************");
		System.out.println("");
		Scanner scanner=new Scanner(System.in);
		int count=0;

	
		do{      // 100 will be returned to get back to main menu.
			System.out.println("Choose your user type");
			System.out.println("1 for Customer");
			System.out.println("2 for Airline Executive Login");
			System.out.println("3 for Admin Login");
			count=scanner.nextInt();
		switch(count){            //main switch (switch 1)
			/*
			 * Case 1 of main switch(switch 1) for customer
			 */
			case 1: System.out.println("You have chosen Customer");	
					
					CustomerUi cuiobj= new CustomerUi();
					count=cuiobj.Customer();
					break;
					
					
					
				/*
				 * Case 2 of main switch(switch 1) for Airline Executive	
				 */
			case 2: System.out.println("You have chosen Airline Executive Login");
					AirlineExecutiveUi aeuiobj=new AirlineExecutiveUi();
					count=aeuiobj.AirlineExecutive();
					break;
					
					
				
					/*
					 * Case 3 of main switch(switch 1 for Admin )
					 */
			case 3: System.out.println("You have chosen Admin Login");
				
					AdminUi adminuiobj= new AdminUi();
					count=adminuiobj.Admin();
					break;
					
					/*
					 * Case 4 of switch statement to exit the program
					 */
			case 4: System.out.println("You have chosen Exit");
					System.out.println("Thank for visit");
					break;                         //final break of case 4 of switch 1
					
					
					
					
			default: System.out.println("You have chosen wrong number");	
				break;
					
					
			}
		if(count!=4 && count!=100){
		System.out.println("4 to exit 5 to continue agin with main menu");
		count=scanner.nextInt();}
		}while(count!=4);
		scanner.close();    
	} //End of main method
	
	
	
	
	
	
	

}//End of class AirlineUi
