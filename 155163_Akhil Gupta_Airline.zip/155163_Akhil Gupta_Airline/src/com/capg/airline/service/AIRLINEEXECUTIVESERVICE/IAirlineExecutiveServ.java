package com.capg.airline.service.AIRLINEEXECUTIVESERVICE;

import com.capg.airline.beans.AirlineBean;

public interface IAirlineExecutiveServ {
	public abstract int checkAirlineExecutiveLogin(AirlineBean bean);
}
