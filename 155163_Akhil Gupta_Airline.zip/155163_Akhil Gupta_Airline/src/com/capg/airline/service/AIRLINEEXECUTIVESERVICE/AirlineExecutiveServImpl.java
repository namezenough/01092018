package com.capg.airline.service.AIRLINEEXECUTIVESERVICE;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.dao.AIRLINEEXECUTIVEDAO.AirlineExecutiveDAO;

public class AirlineExecutiveServImpl implements IAirlineExecutiveServ {

	@Override
	public int checkAirlineExecutiveLogin(AirlineBean bean) {
	
		AirlineExecutiveDAO daoae=new AirlineExecutiveDAO();
		return daoae.checkAirlineExecutiveLogin(bean);
	}

}
