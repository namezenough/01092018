package com.capg.airline.service.ADMINSERVICE;

import com.capg.airline.beans.AirlineBean;

public interface IAdminServ {
	public abstract int checkAdminLogin(AirlineBean bean);
}
