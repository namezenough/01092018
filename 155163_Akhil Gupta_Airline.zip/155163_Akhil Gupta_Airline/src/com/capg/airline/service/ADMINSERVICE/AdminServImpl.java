package com.capg.airline.service.ADMINSERVICE;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.dao.ADMIN.AdminDAO;

public class AdminServImpl implements IAdminServ {


	AdminDAO admindaoobj=new AdminDAO();
	@Override
	public int checkAdminLogin(AirlineBean bean) {
		return admindaoobj.checkAdminLogin(bean);
		
	}

}
