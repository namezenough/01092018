package com.capg.airline.beans;

public class AirlineBean {
	private String user_id;
	private String user_password;
	private String role;
	private String flightno;
	private String airline;
	private String deptCity;
	private String arrCity;
	private String deptDate;
	private String deptTime;
	private String arrDate;
	private String arrTime;
	private String bookingId;
	public String getBookingId() {
		return bookingId;
	}
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}
	private String flightClass;
	private int seatNoToBeBooked;
	private String emailID;
	public int getFareCost() {
		return fareCost;
	}
	public void setFareCost(int fareCost) {
		this.fareCost = fareCost;
	}
	private int fareCost;
	private String creditcardno;
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public String getCreditcardno() {
		return creditcardno;
	}
	public void setCreditcardno(String creditcardno) {
		this.creditcardno = creditcardno;
	}
	public int getSeatNoToBeBooked() {
		return seatNoToBeBooked;
	}
	public void setSeatNoToBeBooked(int seatNoToBeBooked) {
		this.seatNoToBeBooked = seatNoToBeBooked;
	}
	public String getFlightClass() {
		return flightClass;
	}
	public void setFlightClass(String flightClass) {
		this.flightClass = flightClass;
	}
	public String getAirline() {
		return airline;
	}
	public void setAirline(String airline) {
		this.airline = airline;
	}
	public String getDeptCity() {
		return deptCity;
	}
	public void setDeptCity(String deptCity) {
		this.deptCity = deptCity;
	}
	public String getArrCity() {
		return arrCity;
	}
	public void setArrCity(String arrCity) {
		this.arrCity = arrCity;
	}
	public String getDeptDate() {
		return deptDate;
	}
	public void setDeptDate(String deptDate) {
		this.deptDate = deptDate;
	}
	public String getDeptTime() {
		return deptTime;
	}
	public void setDeptTime(String deptTime) {
		this.deptTime = deptTime;
	}
	public String getArrDate() {
		return arrDate;
	}
	public void setArrDate(String arrDate) {
		this.arrDate = arrDate;
	}
	public String getArrTime() {
		return arrTime;
	}
	public void setArrTime(String arrTime) {
		this.arrTime = arrTime;
	}
	public String getFlightno() 
	{
		return flightno;
	}
	public void setFlightno(String flightno) {
		this.flightno = flightno;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getUser_password() {
		return user_password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public void setUser_password(String user_password) {
		this.user_password = user_password;
	}
	public AirlineBean(){
		super();
	}
}
