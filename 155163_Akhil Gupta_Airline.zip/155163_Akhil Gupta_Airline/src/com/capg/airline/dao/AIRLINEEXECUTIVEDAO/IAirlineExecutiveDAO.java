package com.capg.airline.dao.AIRLINEEXECUTIVEDAO;

import com.capg.airline.beans.AirlineBean;

public interface IAirlineExecutiveDAO {
	
		public abstract int checkAirlineExecutiveLogin(AirlineBean bean);
	
}
