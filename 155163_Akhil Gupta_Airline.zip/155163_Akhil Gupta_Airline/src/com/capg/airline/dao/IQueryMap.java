package com.capg.airline.dao;

public interface IQueryMap {
	public static final String QUERY_LOGIN="SELECT password FROM USERS WHERE username=? and role=?";
	public static final String SEARCH_BY_FLIGHTNO="SELECT * FROM FLIGHT_INFO WHERE flightno=?";
	public static final String SEARCH_BY_CITY="SELECT * FROM FLIGHT_INFO WHERE ARR_CITY=? AND DEPT_CITY=? ORDER BY dept_date";
	public static final String CHECK_FIRST_CLASS_SEAT_MAX_NO_RESERVED="SELECT MAX(seat_number) from BOOKING_INFO where flightno=? and class_type=?";
	public static final String NO_OF_FIRST_CLASS_SEATS="SELECT no_of_first_seats FROM flight_info where flightno=?";
	
	public static final String NO_OF_BUSINESS_CLASS_SEATS="SELECT no_of_business_seats FROM flight_info where flightno=?";
	public static final String NO_OF_BOTH_CLASS_SEATS="SELECT no_of_first_seats,no_of_business_seats FROM flight_info where flightno=?";

	public static final String GET_FIRST_CLASS_FARE_COST="SELECT first_seat_fare from flight_info where flightno=?";
	public static final String GET_BUSINESS_CLASS_FARE_COST="SELECT business_seat_fare from flight_info where flightno=?";
	public static final String GET_BOOKING_ID_SEQ_VALUE="SELECT to_char(BOOKING_ID_SEQ.CURRVAL) FROM DUAL";
	public static final String CONFIRM_BOOKING="INSERT INTO BOOKING_INFO VALUES(to_char(BOOKING_ID_SEQ.nextval),?,1,?,?,?,?,?,?,?)";
	public static final String CHECK_BOOKING_ID="SELECT flightno from Booking_info where booking_id=?";
	public static final String UPDATE_MAIL_ID="	UPDATE BOOKING_INFO SET cust_email=? where booking_id=?";
	public static final String CANCEL_RESERVATION="DELETE FROM Booking_info where booking_id=?";
}

