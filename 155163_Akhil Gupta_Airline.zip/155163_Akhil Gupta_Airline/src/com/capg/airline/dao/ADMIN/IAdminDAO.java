package com.capg.airline.dao.ADMIN;

import com.capg.airline.beans.AirlineBean;

public interface IAdminDAO {
	public abstract int checkAdminLogin(AirlineBean bean);
}
