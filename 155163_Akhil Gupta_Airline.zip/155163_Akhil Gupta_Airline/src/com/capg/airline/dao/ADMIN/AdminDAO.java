package com.capg.airline.dao.ADMIN;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.dao.IQueryMap;
import com.capg.airline.util.AirlineDbUtil;

public class AdminDAO implements IAdminDAO {
	Connection conn;
	@Override
	public int checkAdminLogin(AirlineBean bean) {
		conn=AirlineDbUtil.getConnection();
		int calc=0;
		try {
			
			PreparedStatement ps=conn.prepareStatement(IQueryMap.QUERY_LOGIN);
			ps.setString(1, bean.getUser_id());
			ps.setString(2, bean.getRole());
			ResultSet rs= ps.executeQuery();
			
			if(rs.next()){
				System.out.println(rs.getString(1));
				if(rs.getString(1).equals(bean.getUser_password())){
					calc=1;
				}
				else{
					calc=0;
				}
			}
			else
			{
				calc=-1;
			}
			
			
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Exception occured in admin login");
		}
		
		return calc;
	}

}
