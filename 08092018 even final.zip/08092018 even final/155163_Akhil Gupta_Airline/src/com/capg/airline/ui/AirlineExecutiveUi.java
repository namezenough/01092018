package com.capg.airline.ui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;




import org.apache.log4j.Logger;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.exception.MyAirlineException;
import com.capg.airline.service.AIRLINEEXECUTIVESERVICE.AirlineExecutiveServImpl;

/*
 * This class handles the User Interface of Airline Executive
 */

public class AirlineExecutiveUi {
	Scanner scanner=new Scanner(System.in);
	AirlineExecutiveServImpl aeservobj=new AirlineExecutiveServImpl();
	AirlineBean bean=new AirlineBean();
	int loop=0;
	int logincheck=0;
	Logger logObj=Logger.getRootLogger();

	
	
	int AirlineExecutive() throws MyAirlineException{          //start of method AirlineExecutive
		String innercount;
		if(loop==0){
		System.out.println("Press 1 to Log Out");
		System.out.println("Press 2 to exit ");
		System.out.println("Press any other key to continue as Airline Executive");
		
		innercount=scanner.nextLine();
		if(innercount.equals("1"))
		{
			logObj.info("Airline executive logged out");
			AirlineUi.main(null);      		//back to main  method
			return 100;							
			
		}
		if(innercount.equals("2"))
		{
			System.out.println("Thanks for visiting us");
			logObj.error("Exit by Airline executive");
			System.exit(0);					//exit called
			return 4;						
			
		}
	}
				System.out.println("<-----***Airline Executive Menu****----->");
				System.out.println("Press 1 for Generating Report");
				System.out.println("Press 2 to Check flight Occupancy");
				System.out.println("Press 3 to Log Out");
				System.out.println("Press 4 to exit");
				String menucount=scanner.nextLine();
				if(menucount.equals("1")){																
					System.out.println("Welcome to Report Generation");
					AEReportGeneration();
				}														//end of if(menucount.equals("1"))
				else if(menucount.equals("2")){
					AEFlightOccupancy();
				}														//end of if(menucount.equals("2"))
				else if(menucount.equals("3")){
					AirlineUi.main(null);
				}														//end of if(menucount.equals("3"))
				else if(menucount.equals("4")){
					System.out.println("Thanks for visiting us");
					System.exit(0);
					return 4;
					
				}														//end of if(menucount.equals("4"))
				else{
					System.out.println("You entered Wrong Number");
					loop=1;											//to hide some lines
					AirlineExecutive();
				}
		
					
		return 0;
	}  //end of AirlineExecutive method
	



	
	
	
	int AEReportGeneration()  throws MyAirlineException{
		String aeReportGenCount=null;
		System.out.println("Enter 1 to get the total no of people who have booked the flights till now from this portal.");
		System.out.println("Enter 2 to get no of poeple who have booked the flights for future.");
		aeReportGenCount=scanner.nextLine();
		if(aeReportGenCount.equals("1")) // start of condition get the total no of people who have booked the flights till now from this portal.
		{
			int totalSeatsBooked=aeservobj.totalBookedSeats();
			if(totalSeatsBooked==0){
				System.err.println("No seat is ever booked");
				logObj.error("No seat is ever booked");
			}
			else{
				System.out.println(totalSeatsBooked + " seats are booked from this portal ever.");
				System.out.println("");
				logObj.info("Seats report generated");
				loop=1;
				logincheck=1;
				AirlineExecutive();
				
			} 
		}// end of condition: get the total no of people who have booked the flights till now from this portal.
		else if(aeReportGenCount.equals("2")){  // start of condition: to get no of people who have booked the flights for future.
			int futureSeatsBooked=aeservobj.futureBookedSeats();
			if(futureSeatsBooked==0){
				System.err.println("No seat is booked for future");
				logObj.error("No seat is booked for future");

			}
			else{
				System.out.println(futureSeatsBooked + " seats are booked from this portal for future.");
				System.out.println("");
				logObj.info("Seats report generated");

				loop=1;
				logincheck=1;
				AirlineExecutive();
				
			} 
			
		}// end of condition: to get no of poeple who have booked the flights for future.
		else{
			System.err.println("You entered wrong Input. Please Try Again");
			logObj.error("Entered invalid number");
			AEReportGeneration();
		}
		return 0;
	}															//end of method AEReportGeneration()
	
	
	
	
	
	
	int AEFlightOccupancy() throws MyAirlineException{					//start of AEFlightOccupancy()
		System.out.println("Enter the flight no or Press 1 to go back");
		System.out.println("");
		String flightno=scanner.nextLine();					//check choice
		if(flightno.equals("1")){
			loop=1;
			logincheck=1;
			AirlineExecutive();
		}
		else{
		bean.setFlightno(flightno);
		ArrayList<AirlineBean> checkOccupancyList=new ArrayList<AirlineBean>();
		checkOccupancyList=aeservobj.checkOccupancy(bean);					//check occupancy using this method
		if(checkOccupancyList.isEmpty()){				//if no data available
			System.out.println("No such flight exist. Please try again");
			logObj.error("No flight Exist");
			AEFlightOccupancy();
		}																	//if data is available
		Iterator<AirlineBean> iterObj=checkOccupancyList.iterator();
		while(iterObj.hasNext()){
			AirlineBean beanobj=iterObj.next();
			System.out.println("Total First Class Seats: "+beanobj.getTotalFirstClassSeats());
			System.out.println("No of first Class seats booked: "+beanobj.getFilledFirstClassSeats());
			System.out.println("Total Business Class Seats: "+ beanobj.getTotalBusinessClassSeats());
			System.out.println("No of Business Class Seats Booked: "+beanobj.getFilledBusinessClassSeats());
			System.out.println("");
			logObj.info("Flight list Displayed");
			loop=1;
			logincheck=1;
			AirlineExecutive();																			//back to executive main menu
		}}
		return 0;
	}
}														//end of AEFlightOccupancy
