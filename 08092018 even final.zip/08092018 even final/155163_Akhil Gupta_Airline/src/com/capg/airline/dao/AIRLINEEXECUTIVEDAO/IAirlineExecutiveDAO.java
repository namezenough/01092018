package com.capg.airline.dao.AIRLINEEXECUTIVEDAO;

import java.util.ArrayList;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.exception.MyAirlineException;

public interface IAirlineExecutiveDAO {
	
		public abstract int totalBookedSeats() throws MyAirlineException;
		public abstract int futureBookedSeats() throws MyAirlineException;
		public abstract ArrayList<AirlineBean> checkOccupancy(AirlineBean bean) throws MyAirlineException;
}
