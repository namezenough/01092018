/*
 * This class handles the back end methods of Customer
 */
package com.capg.airline.dao.CUSTOMERDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;







import org.apache.log4j.Logger;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.dao.IQueryMap;
import com.capg.airline.exception.MyAirlineException;
import com.capg.airline.util.AirlineDbUtil;

public class CustomerDAO implements ICustomerDAO{
	Logger logObj=Logger.getRootLogger();

	Connection conn;
	
	
	
	
	// method to search flight by flight no
	@Override
	public AirlineBean searchFlightByNo(AirlineBean beanrec) {
		AirlineBean bean=null;
		conn=AirlineDbUtil.getConnection();
		try {
			PreparedStatement ps=conn.prepareStatement(IQueryMap.SEARCH_BY_FLIGHTNO);
			ps.setString(1, beanrec.getFlightno());
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				bean=new AirlineBean();
				bean.setFlightno(rs.getString(1));
				bean.setAirline(rs.getString(2));
				bean.setDeptCity(rs.getString(3));
				bean.setArrCity(rs.getString(4));
				String depdate=rs.getString(5); //get dep date and time in string
				String arrdate=rs.getString(6); //get arr date and time in string
				bean.setArrDate(arrdate.substring(0,10));
				bean.setArrTime(arrdate.substring(10));
				bean.setDeptDate(depdate.substring(0, 10));
				bean.setDeptTime(depdate.substring(10));
				bean.setFirstClassFare(rs.getInt(8));
				bean.setBusinessClassFare(rs.getInt(10));
				return bean;
			}
			else{
				System.out.println("No data found. Check for valid flight number");
				return bean;
			}
			
		} catch (SQLException e) {
			logObj.error("Exception in search by flight no "+e);		
			System.out.println("Exception in Client Dao");
		}
		return bean;
	}  // end of searchFlightByNo
	
	
	
	
	
	
	
	// method to search flight by arrival and departure city names
	@Override
	public LinkedHashMap<String, AirlineBean> searchByCity(AirlineBean bean)  throws MyAirlineException{
		LinkedHashMap<String, AirlineBean> beanHashMap=new LinkedHashMap<String, AirlineBean>();
		conn=AirlineDbUtil.getConnection();
		try {
			PreparedStatement ps=conn.prepareStatement(IQueryMap.SEARCH_BY_CITY);
			ps.setString(1, bean.getDeptCity());
			ps.setString(2, bean.getArrCity());
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				bean=new AirlineBean();
					
					bean.setFlightno(rs.getString(1));
					bean.setAirline(rs.getString(2));
					bean.setDeptCity(rs.getString(3));
					bean.setArrCity(rs.getString(4));
					bean.setDeptDate(rs.getString(5));
					bean.setArrDate(rs.getString(6));
					beanHashMap.put(bean.getFlightno(),bean); //STORE VALUES IN MAP
				
			}
			
				return beanHashMap;
			
			
			
		} catch (SQLException e) {
			logObj.error("Exception in searchByCity "+e);
			System.out.println("Exception in Client Dao.");
		}
		return beanHashMap;
	}








	// method to check Availability in the flight
	@Override
	public int checkAvailability(AirlineBean bean)  throws MyAirlineException{
		conn=AirlineDbUtil.getConnection();
		int maxFlightNoReserv=0;
		int toatalseats=0;
		
		if(bean.getFlightClass().equals("FIRST CLASS")){ // check availabilty of seat in  given flightno for first class seat
			try {
				PreparedStatement ps=conn.prepareStatement(IQueryMap.CHECK_FIRST_CLASS_SEAT_MAX_NO_RESERVED);
				ps.setString(1, bean.getFlightno());			
				ps.setString(2, bean.getFlightClass());
				ResultSet rs=ps.executeQuery();
				if(rs.next()){
					 maxFlightNoReserv=rs.getInt(1);
				}
				
				ps=conn.prepareStatement(IQueryMap.NO_OF_FIRST_CLASS_SEATS);
				ps.setString(1,bean.getFlightno());
				rs=ps.executeQuery();
				if(rs.next()){
					toatalseats=rs.getInt(1);
				}
				
				if(maxFlightNoReserv<(toatalseats-bean.getNoOfBookings()))
				{
					
					return maxFlightNoReserv+1;
				}
				else{
					return -1;
				}
				
				
			} catch (SQLException e) {
				logObj.error("Exception in checking Availability"+e);
			}
		}
		else{// check availabilty of seat in  given flightno for business class seat
			int totalfirstClassSeats=0;
			int totalbusinessClassSeats=0;
			try {
				PreparedStatement ps=conn.prepareStatement(IQueryMap.NO_OF_BOTH_CLASS_SEATS);
				ps.setString(1,bean.getFlightno());
				ResultSet rs=ps.executeQuery();
				if(rs.next()){
					totalfirstClassSeats=rs.getInt(1);
					totalbusinessClassSeats=rs.getInt(2);
				}
				 ps=conn.prepareStatement(IQueryMap.CHECK_FIRST_CLASS_SEAT_MAX_NO_RESERVED);
				ps.setString(1, bean.getFlightno());			
				ps.setString(2, bean.getFlightClass());
				rs=ps.executeQuery();
				if(rs.next()){
					 maxFlightNoReserv=rs.getInt(1);
				}
				if(maxFlightNoReserv<totalfirstClassSeats-bean.getNoOfBookings()){
					return maxFlightNoReserv=totalfirstClassSeats+1;
				}
				else if(maxFlightNoReserv< totalbusinessClassSeats +totalfirstClassSeats){
					return maxFlightNoReserv+1;
				}
				else{
					return -1;
				}
			} catch (SQLException e) {
				logObj.error("Exception in checking availability"+e);
			}
			
		}
		return 0;
	}







	// method to confirm booking
	@SuppressWarnings("resource")
	@Override
	public ArrayList<String > confirmBoking(AirlineBean bean)  throws MyAirlineException{
		String bookingId=null;
		ArrayList<String > listOfBookingId=new ArrayList<String>();
		conn=AirlineDbUtil.getConnection();
		for(int i=1;i<=bean.getNoOfBookings();i++){
			
		try {
			
			PreparedStatement ps=null;
			ResultSet rs=null;
			ps=conn.prepareStatement(IQueryMap.CHECK_ANY_CLASS_SEAT_MAX_NO_RESERVED);      //not for only first class bcz class in not specified in query
			ps.setString(1, bean.getFlightno());
			ps.setString(2, bean.getClassType());
			rs=ps.executeQuery();
			int maxSeatRes=0;
			if(rs.next()){
				maxSeatRes=rs.getInt(1);
			}
			if(bean.getFlightClass()=="FIRST CLASS")
				ps=conn.prepareStatement(IQueryMap.NO_OF_FIRST_CLASS_SEATS);
				else
				ps=conn.prepareStatement(IQueryMap.NO_OF_BUSINESS_CLASS_SEATS);
				
			ps.setString(1, bean.getFlightno());
			rs=ps.executeQuery();
			int totalSeats=0;
			if(rs.next()){
				totalSeats=rs.getInt(1);
			}
			if(totalSeats<=maxSeatRes){
				continue;
			}
			if(bean.getFlightClass()=="FIRST CLASS")
			ps=conn.prepareStatement(IQueryMap.GET_FIRST_CLASS_FARE_COST);
			else
			ps=conn.prepareStatement(IQueryMap.GET_BUSINESS_CLASS_FARE_COST);
			ps.setString(1,bean.getFlightno());
			rs=ps.executeQuery();
			if(rs.next())
				bean.setFareCost(rs.getInt(1));
			//System.out.println(bean.getFareCost());
			/*System.out.println(bean.getEmailID()+ bean.getFlightClass()+ bean.getFareCost()+bean.getSeatNoToBeBooked()+ bean.getCreditcardno() );
			System.out.println(bean.getDeptCity()+ bean.getArrCity() +bean.getFlightno());*/
			ps=conn.prepareStatement(IQueryMap.CONFIRM_BOOKING);
			ps.setString(1,bean.getEmailID());
			ps.setString(2,bean.getFlightClass());
			ps.setInt(3,bean.getFareCost());
			ps.setInt(4,bean.getSeatNoToBeBooked());
			bean.setSeatNoToBeBooked(bean.getSeatNoToBeBooked()+1);
			ps.setString(5,bean.getCreditcardno());
			ps.setString(6,bean.getDeptCity());
			ps.setString(7,bean.getArrCity());
			ps.setString(8,bean.getFlightno());
			if(ps.executeUpdate() ==1){
				ps=conn.prepareStatement(IQueryMap.GET_BOOKING_ID_SEQ_VALUE);
				rs=ps.executeQuery();
				if(rs.next())
				bean.setBookingId(rs.getString(1));
				bookingId=bean.getBookingId();
				listOfBookingId.add(bookingId);
			}
			
			
			
			
		} catch (SQLException e) {
			logObj.error("Exception in confirmation of booking "+e);
			System.out.println("Exception in customer dao");
		}
		}
		return listOfBookingId;
	}








	
	
	
	
	
	
	// method to check booking id
	@Override
	public String checkBookingId(AirlineBean bean)  throws MyAirlineException{
		conn=AirlineDbUtil.getConnection();
		String flightno=null;
		try {
			PreparedStatement ps=conn.prepareStatement(IQueryMap.CHECK_BOOKING_ID);
			ps.setString(1, bean.getBookingId());
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				flightno=rs.getString(1);
			}
			
		} catch (SQLException e) {
			logObj.error("Exception in checking booking id "+e);
		}
		return flightno;
	}








	
	
	
	
	
	
	// method to update mail id
	@Override
	public int updateMailId(AirlineBean bean)  throws MyAirlineException{
		conn=AirlineDbUtil.getConnection();
		int res=0;
		PreparedStatement ps;
		try {
			
			ps = conn.prepareStatement(IQueryMap.UPDATE_MAIL_ID);
			ps.setString(1, bean.getEmailID());
			ps.setString(2, bean.getBookingId());
			res=ps.executeUpdate();
		} catch (SQLException e) {
			logObj.error("Exception in updating Mail Id "+e);		
			System.err.println("Problem in updation");
		}
		
		return res;
	}







	// method to cancel Reservation
	@Override
	public int cancelReservation(AirlineBean bean) throws MyAirlineException {
		conn=AirlineDbUtil.getConnection();
		int res=0;
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement(IQueryMap.CANCEL_RESERVATION);
			ps.setString(1, bean.getBookingId());
			res=ps.executeUpdate();
		} catch (SQLException e) {
			logObj.error("Exception in cancelling Reservation "+e);
		}
		
		return res;
	}

}





