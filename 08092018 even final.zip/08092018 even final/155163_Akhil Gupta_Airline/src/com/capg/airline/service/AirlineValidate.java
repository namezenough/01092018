/*
 * This class is having all the validation methods 
 */

package com.capg.airline.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capg.airline.exception.MyAirlineException;

public class AirlineValidate {

	public boolean validateMobile(String mobileNo) throws MyAirlineException {
		Matcher match=null;
		Pattern patt=Pattern.compile("[0-9]{10}");
		match=patt.matcher(mobileNo);
		if(match.matches()==false)
		{
			System.err.flush();
			System.err.println("Mobile no should be of 10 digits");
		}
		return match.matches();
	}


	
	
	
	
	
	
	public boolean validateEmail(String emailId) {
		Matcher match=null;
		Pattern patt=Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);
		match=patt.matcher(emailId);
		if(match.matches()==false){
			System.err.flush();
			System.err.println("Invalid Email Id. Try Again");
			
		}
		return match.matches();
	}








	public boolean validateCreditCard(String creditCard) {
		Matcher match=null;
		Pattern patt=Pattern.compile("[0-9]{12}");    // we assume that card must have 12 digits
		match=patt.matcher(creditCard);
		if(match.matches()==false){
			System.err.flush();
			System.err.println("Invalid Credit Card Number. Try Again");
			
		}
		return match.matches();
	}








	public boolean validateNumber(String number) {
		
		Matcher match=null;
		Pattern patt=Pattern.compile("[0-9]{1,5}");    
		match=patt.matcher(number);
		if(match.matches()==false){
			System.err.flush();
			System.err.println("Invalid Number.Length must also not exceed 5. Try Again");
			
		}
		return match.matches();
	}






	public boolean validateDate(String myDate) {
		Matcher match=null;
		Pattern patt=Pattern.compile("((19|20)\\d\\d)/(0?[1-9]|1[012])/(0?[1-9]|[12][0-9]|3[01])");    // date pattern
		match=patt.matcher(myDate);
		if(match.matches()==false){
			System.err.flush();
			System.err.println("Please follow the given pattern");
			
		}
		return match.matches();
	}
	
	public boolean validateDateTime(String myDate) {
		Matcher match=null;
		Pattern patt=Pattern.compile("((19|20)\\d\\d)/(0?[1-9]|1[012])/(0?[1-9]|[12][0-9]|3[01]) [012]{0,1}[0-9]:[0-5][0-9]:[0-5][0-9]");    // date pattern
		match=patt.matcher(myDate);
		if(match.matches()==false){
			System.err.flush();
			System.err.println("Please follow given pattern");
			
		}
		return match.matches();
	}
}
