/*
 * This class has methods which allows interaction of admin user interface class methods with adminDAO class
 */
package com.capg.airline.service.ADMINSERVICE;

import java.util.ArrayList;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.dao.ADMIN.AdminDAO;
import com.capg.airline.exception.MyAirlineException;

public class AdminServImpl implements IAdminServ {


	AdminDAO admindaoobj=new AdminDAO();
	
	
	
	
	
	
	
	
	@Override
	public int airlineExecutiveSignUp(AirlineBean bean)  throws MyAirlineException{
		
		return admindaoobj.airlineExecutiveSignUp(bean);
	}








	@Override
	public int adminSignUp(AirlineBean bean) throws MyAirlineException {
		
		return admindaoobj.adminSignUp(bean);
	}








	@Override
	public int checkIfFlightnoExist(AirlineBean bean) throws MyAirlineException {
		
		return admindaoobj.checkIfFlightnoExist(bean);
	}








	
	
	
	
	
	
	@Override
	public int increaseFirstClassSeats(AirlineBean bean)  throws MyAirlineException{
		return admindaoobj.increaseFirstClassSeats(bean);
	}








	
	
	
	
	
	@Override
	public int increaseBusinessClassSeats(AirlineBean bean)  throws MyAirlineException{
		return admindaoobj.increaseBusinessClassSeats(bean);
	}








	
	
	
	
	
	
	@Override
	public int decreaseFirstClassSeats(AirlineBean bean) throws MyAirlineException {
		return admindaoobj.decreaseFirstClassSeats(bean);
	}








	
	
	
	
	
	
	@Override
	public int decreaseBusinessClassSeats(AirlineBean bean) throws MyAirlineException {
		return admindaoobj.decreaseBusinessClassSeats(bean);
	}








	@Override
	public int updateFlightTiming(AirlineBean bean) throws MyAirlineException {
		
		return admindaoobj.updateFlightTiming(bean);
	}








	@Override
	public ArrayList<AirlineBean> flightsDepartingOnDate(AirlineBean bean)  throws MyAirlineException{
		
		return admindaoobj.flightsDepartingOnDate(bean);
	}








	@Override
	public ArrayList<AirlineBean> flightsDepartingFromCity(AirlineBean bean) throws MyAirlineException {
		
		return admindaoobj.flightsDepartingFromCity(bean);
	}








	@Override
	public ArrayList<AirlineBean> flightsArrivingToCity(AirlineBean bean)  throws MyAirlineException{
		
		return admindaoobj.flightsArrivingToCity(bean);
	}








	@Override
	public int updateFirstCLassFare(AirlineBean bean) throws MyAirlineException {
		
		return admindaoobj.updateFirstCLassFare(bean);
	}








	@Override
	public int updateBusinessCLassFare(AirlineBean bean) throws MyAirlineException {
		// TODO Auto-generated method stub
		return admindaoobj.updateBusinessCLassFare(bean);
	}








	@Override
	public ArrayList<AirlineBean> bookingListOfFlight(AirlineBean bean)  throws MyAirlineException{
		// TODO Auto-generated method stub
		return admindaoobj.bookingListOfFlight(bean);
	}
	
	
}
