/*
 * This class has methods which allows interaction of customer user interface class methods with customerDAO class
 */


package com.capg.airline.service.CUSTOMERSERVICE;

import java.util.ArrayList;
import java.util.LinkedHashMap;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.dao.CUSTOMERDAO.CustomerDAO;
import com.capg.airline.dao.CUSTOMERDAO.ICustomerDAO;
import com.capg.airline.exception.MyAirlineException;

public class CustomerServImpl implements ICustomerServ {
ICustomerDAO custdao;
	public CustomerServImpl() {
		custdao=new CustomerDAO();
	}
	@Override
	public AirlineBean searchFlightByNo(AirlineBean bean)  throws MyAirlineException{
		return custdao.searchFlightByNo(bean);
	}
	@Override
	public LinkedHashMap<String, AirlineBean> searchByCity(AirlineBean bean) throws MyAirlineException {
		
		return custdao.searchByCity(bean);
	}
	@Override
	public int checkAvailability(AirlineBean bean)  throws MyAirlineException{
		
		return custdao.checkAvailability(bean);
	}
	@Override
	public ArrayList<String > confirmBoking(AirlineBean bean) throws MyAirlineException {
		
		return custdao.confirmBoking(bean);
	}
	@Override
	public String checkBookingId(AirlineBean bean) throws MyAirlineException {
		
		return custdao.checkBookingId(bean);
	}
	@Override
	public int updateMailId(AirlineBean bean)  throws MyAirlineException{
		
		return custdao.updateMailId(bean);
	}
	@Override
	public int cancelReservation(AirlineBean bean)  throws MyAirlineException{
		
		return custdao.cancelReservation(bean);
	}

}
