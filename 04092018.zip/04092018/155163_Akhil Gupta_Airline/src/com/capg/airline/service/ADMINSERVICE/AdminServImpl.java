package com.capg.airline.service.ADMINSERVICE;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.dao.ADMIN.AdminDAO;

public class AdminServImpl implements IAdminServ {


	AdminDAO admindaoobj=new AdminDAO();
	@Override
	public int checkAdminLogin(AirlineBean bean) {
		return admindaoobj.checkAdminLogin(bean);
		
	}
	
	
	
	
	
	
	
	
	@Override
	public int airlineExecutiveSignUp(AirlineBean bean) {
		
		return admindaoobj.airlineExecutiveSignUp(bean);
	}








	@Override
	public int adminSignUp(AirlineBean bean) {
		
		return admindaoobj.adminSignUp(bean);
	}








	@Override
	public int checkIfFlightnoExist(AirlineBean bean) {
		
		return admindaoobj.checkIfFlightnoExist(bean);
	}








	
	
	
	
	
	
	@Override
	public int increaseFirstClassSeats(AirlineBean bean) {
		return admindaoobj.increaseFirstClassSeats(bean);
	}








	
	
	
	
	
	@Override
	public int increaseBusinessClassSeats(AirlineBean bean) {
		return admindaoobj.increaseBusinessClassSeats(bean);
	}








	
	
	
	
	
	
	@Override
	public int decreaseFirstClassSeats(AirlineBean bean) {
		return admindaoobj.decreaseFirstClassSeats(bean);
	}








	
	
	
	
	
	
	@Override
	public int decreaseBusinessClassSeats(AirlineBean bean) {
		return admindaoobj.decreaseBusinessClassSeats(bean);
	}

	
	
}
