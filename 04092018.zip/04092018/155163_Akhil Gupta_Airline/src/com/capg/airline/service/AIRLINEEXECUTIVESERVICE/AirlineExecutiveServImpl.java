package com.capg.airline.service.AIRLINEEXECUTIVESERVICE;

import java.util.ArrayList;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.dao.AIRLINEEXECUTIVEDAO.AirlineExecutiveDAO;

public class AirlineExecutiveServImpl implements IAirlineExecutiveServ {

	AirlineExecutiveDAO daoae=null;
	 public AirlineExecutiveServImpl() {
		 	daoae=new AirlineExecutiveDAO();
	 }
		
	
	@Override
	public int checkAirlineExecutiveLogin(AirlineBean bean) {
	
		
		return daoae.checkAirlineExecutiveLogin(bean);
	}

	
	
	
	
	@Override
	public int totalBookedSeats() {
		
		return daoae.totalBookedSeats();
	}


	@Override
	public int futureBookedSeats() {
		// TODO Auto-generated method stub
		return daoae.futureBookedSeats();
	}


	
	
	
	@Override
	public ArrayList<AirlineBean> checkOccupancy(AirlineBean bean) {
		// TODO Auto-generated method stub
		return daoae.checkOccupancy(bean);
	}

}
