package com.capg.airline.service;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.dao.CombinedDAOImpl;
import com.capg.airline.dao.ICombinedDAO;

public class CombinedServImpl implements ICombinedServ {

	ICombinedDAO comDaoObj=null;
	public CombinedServImpl(){
		comDaoObj=new CombinedDAOImpl();
	}
	@Override
	public int checkLogin(AirlineBean bean) {
		// TODO Auto-generated method stub
		return comDaoObj.checkLogin(bean);
	}

}
