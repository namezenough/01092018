package com.capg.airline.service.CUSTOMERSERVICE;

import java.util.LinkedHashMap;

import com.capg.airline.beans.AirlineBean;

public interface ICustomerServ {
	public abstract AirlineBean searchFlightByNo(AirlineBean bean);
	public abstract LinkedHashMap<String, AirlineBean> searchByCity(AirlineBean bean);
	public abstract int checkAvailability(AirlineBean bean);
	public abstract String confirmBoking(AirlineBean bean);
	public abstract String checkBookingId(AirlineBean bean);
	public abstract int updateMailId(AirlineBean bean);
	public abstract int cancelReservation(AirlineBean bean);


}
