package com.capg.airline.service.AIRLINEEXECUTIVESERVICE;

import java.util.ArrayList;

import com.capg.airline.beans.AirlineBean;

public interface IAirlineExecutiveServ {
	public abstract int checkAirlineExecutiveLogin(AirlineBean bean);
	public abstract int totalBookedSeats();
	public abstract int futureBookedSeats();
	public abstract ArrayList<AirlineBean> checkOccupancy(AirlineBean bean);

}
