package com.capg.airline.service;

import com.capg.airline.beans.AirlineBean;

public interface ICombinedServ {
	public abstract int checkLogin(AirlineBean bean);

}
