package com.capg.airline.ui;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.service.CUSTOMERSERVICE.CustomerServImpl;
import com.capg.airline.service.CUSTOMERSERVICE.ICustomerServ;

public class CustomerUi {
	int loop=0;
	int viewupdateloop=0;
	AirlineBean bean=new AirlineBean();
	ICustomerServ custservobj=new CustomerServImpl();
	String innercount=null;
	int custFirstChoose=0;
	Scanner scanner=new Scanner(System.in);
	int Customer(){
		if(loop==0){
	System.out.println("Dear Customer, Press 1 to get back to main menu");
	System.out.println("2 to exit");
	System.out.println("Or any other key to continue");
	innercount=scanner.next();
	if(innercount.equals("1"))
	{
		     return 100;                         
		
	}
	if(innercount.equals("2"))
	{
		System.out.println("Thanks for visiting us");
		return 4;                                 
		
	}
	
		}
	System.out.println("Proceeded to Customer. Choose any one");
	System.out.println("1: Search flight details");
	System.out.println("2: Reserve a flight");
	System.out.println("3: View/Update/Cancel any Reservation");
	System.out.println("4: Main Menu");
	System.out.println("5: Exit");
	custFirstChoose=scanner.nextInt();
	if(custFirstChoose==1){
		SearchFlight();
	}
	else if(custFirstChoose==2){
		ReserveFlight();
	}
	else if(custFirstChoose==3){
		viewUpdateCancelFlight();
	}
	else if(custFirstChoose==4){
		return 100;
	}
	else if(custFirstChoose==5){
		System.out.println("Thanks for visiting us");
		return 4;
	}
	else{
		System.out.println("Sorry. You have chosen wrong number.");
		Customer();
	}
	
	
	
	return 0;

}
	
	int SearchFlight(){
		String searchCount=null;
		System.out.println("Press 1 to search by flightno");
		System.out.println("Press 2 to search flights between 2 locations (Use Capital letters)");
		System.out.println("Press 3 to go back");
		searchCount=scanner.next();
		if(searchCount.equals("1")) //start of search by flightno
		{
			System.out.println("Enter flight no.");
			bean.setFlightno(scanner.next());
			AirlineBean beanFlight=custservobj.searchFlightByNo(bean);
			if(beanFlight!=null){
				System.out.println("Flight Number: " +beanFlight.getFlightno()+ "\nAirline: "+ beanFlight.getAirline()+"\nDep City: "+ beanFlight.getDeptCity()+"\nArrival City: " + beanFlight.getArrCity());
				System.out.println("Departure date: " +beanFlight.getDeptDate()+ "\nDeparture Time: "+beanFlight.getDeptTime()+"\nArrival Date: "+beanFlight.getArrDate()+ "\nArrival time: " + beanFlight.getArrTime());
				System.out.println("");
				loop=1;
				Customer();
			}
			else{
				System.out.println("Search again");
				SearchFlight();
			}
			
		} //end of search by flightno
		
		
		
		
		
		
		
		else if(searchCount.equals("2")){ //Start of search flights between 2 locations
			System.out.println("Enter the following details:");
			System.out.println("Enter Departure City(Use capital letters)");
			bean.setArrCity(scanner.next());
			System.out.println("Enter Arrival City(Use capital letters)");
			bean.setDeptCity(scanner.next());
			LinkedHashMap<String, AirlineBean> lhashmap=custservobj.searchByCity(bean);
			if(lhashmap.isEmpty()){
				System.out.println("No record found. Check for valid data");
				SearchFlight();
			}else{
				System.out.println("Here is the list of available flights, ordered by date");
			for(Map.Entry<String,AirlineBean> mentry: lhashmap.entrySet()){
				bean=mentry.getValue();
				System.out.println("Details of FLight No:"+ bean.getFlightno());
				System.out.println("\nAirline: "+ bean.getAirline()+"\nDep City: "+ bean.getDeptCity()+"\nArrival City: " + bean.getArrCity());
				System.out.println("Departure date and Time: " +bean.getDeptDate()+"\nArrival Date and Time: "+bean.getArrDate());
				System.out.println("");
			}
			}
			loop=1;  // so that initial data of customer is not visible
			Customer();
		}
		
		else if(searchCount.equals("3")){
			loop=1;
			Customer();
		}
			
		else{
			System.out.println("You entered wrong number");
			SearchFlight();
		}
		
		return 0;
	}// searchFlight() ends here
	
	
	
	
	
	
	int ReserveFlight(){
		int resCount=0;
		System.out.println("Press 1 to continue, 2 to go back");
		resCount=scanner.nextInt();
		if(resCount==1){
			
			
			System.out.println("Enter the following details:");
			System.out.println("Enter Departure City (Use capital letters)");
			bean.setArrCity(scanner.next());
			System.out.println("Enter Arrival City (Use capital letters)");
			bean.setDeptCity(scanner.next());
			LinkedHashMap<String, AirlineBean> lhashmap=custservobj.searchByCity(bean);
			if(lhashmap.isEmpty()){
				System.out.println("No record found. Check for valid data");
				SearchFlight();
			}
			else{
				System.out.println("Here is the list of available flights, ordered by date");
			for(Map.Entry<String,AirlineBean> mentry: lhashmap.entrySet()){
				bean=mentry.getValue();
				System.out.println("Details of Flight No:"+ bean.getFlightno());
				System.out.println("\nAirline: "+ bean.getAirline()+"\nDep City: "+ bean.getDeptCity()+"\nArrival City: " + bean.getArrCity());
				System.out.println("Departure date and Time: " +bean.getDeptDate()+"\nArrival Date and Time: "+bean.getArrDate());
				System.out.println("");
				}
			confirmBookingUi(lhashmap);
			}
			
		}
		else{
			loop=1;
			Customer();
		}
		return 0;
	}  //reserveFlight() ends here
	
	
	
	
	
	
	int confirmBookingUi(LinkedHashMap<String, AirlineBean> lhashmap){
		
		String bookingId=null;
		System.out.println("Enter the flight no. that you want to book");
		bean.setFlightno(scanner.next());
		if(lhashmap.containsKey(bean.getFlightno())){
			System.out.println("Press 1 for business class booking");
			System.out.println("Press 2 for first class booking");
			String classbooking="0";
			classbooking=scanner.next();
			if(classbooking.equals("1")){
				bean.setFlightClass("BUSINESS CLASS");
				
			}
			else if(classbooking.equals("2")){
				bean.setFlightClass("FIRST CLASS");
			}
			else{ //is class is not selected 
				System.out.println("Sorry, you pressed wrong key");
				confirmBookingUi(lhashmap);
			}
			bean.setSeatNoToBeBooked(custservobj.checkAvailability(bean));
			if(bean.getSeatNoToBeBooked()==-1)
			{
				System.out.println("Sorry, No seat available. Please check for any other available flight");
				confirmBookingUi(lhashmap);
			}
			System.out.println("Seat is available. Please enter the following details.");
			System.out.println("Enter your email id:");
			bean.setEmailID(scanner.next());
			System.out.println("Enter Credit Card number");
			bean.setCreditcardno(scanner.next());
			bookingId=custservobj.confirmBoking(bean);
			if(bookingId==null){
				System.err.println("Could not generate booking id");
				confirmBookingUi(lhashmap);
			}
			else{
				System.out.println("Booking Successful");
				System.out.println("Your booking Id is: "+bookingId );
				System.out.println("");
				System.out.println("1: ANOTHER BOOKING?");
				System.out.println("2: NO another booking");
				bookingId=scanner.next();
				if(bookingId.equals("1")){
					confirmBookingUi(lhashmap);
				}
				else{
					loop=1;
					Customer();
				}
				
			}
			
			
			
		}
		else{   // if entered flight no is not correct
			System.out.println("Sorry you didn't enter correct flight no. Please try again");
			confirmBookingUi(lhashmap);
		}
		return 0;
		
	}  //confirmBookinhUi() ends here
	
	
	
	
	
	
	
	int viewUpdateCancelFlight(){
		String flightno=null;
		if(viewupdateloop==0){
		System.out.println("Enter Your booking Id:");
		bean.setBookingId(scanner.next());
		flightno=custservobj.checkBookingId(bean);
		if(flightno==null){
			System.out.println("Booking Id Does not exist");
			viewUpdateCancelFlight();
		}
		bean.setFlightno(flightno);
		}
		System.out.println("1: View Your Booked Flight Details");
		System.out.println("2: Update your email id");
		System.out.println("3: Cancel Reservation");
		System.out.println("4: Go Back");
		String options=scanner.next();
		if(options.equals("1")){   //view your flight details
			AirlineBean beanFlight= custservobj.searchFlightByNo(bean);
			System.out.println("Flight Number: " +beanFlight.getFlightno()+ "\nAirline: "+ beanFlight.getAirline()+"\nDep City: "+ beanFlight.getDeptCity()+"\nArrival City: " + beanFlight.getArrCity());
			System.out.println("Departure date: " +beanFlight.getDeptDate()+ "\nDeparture Time: "+beanFlight.getDeptTime()+"\nArrival Date: "+beanFlight.getArrDate()+ "\nArrival time: " + beanFlight.getArrTime());
			System.out.println("");
			viewupdateloop=1;
			viewUpdateCancelFlight();
			
		}
		else if(options.equals("2")){  //Update your mail id
			System.out.println("Enter your mail id");
			bean.setEmailID(scanner.next());
			System.out.println("Press 1 to confirm and other key to cancel");
			
			if(scanner.next().equals("1"))
			{
				
			if(custservobj.updateMailId(bean)==1){
				System.out.println("**Mail id Successfully Updated**");
				viewupdateloop=1;
				viewUpdateCancelFlight();
			}
			else{
				System.err.println("Could not update mail id");
			}}
			else{
				viewupdateloop=1;
				viewUpdateCancelFlight();
			}
			
			
			
		}// mail id updating ends here
		
		else if(options.equals("3")){
			System.err.println("Note: Only 75% of money will be returned");
			System.out.println("Press 1 to cancel your reservation any other key to go back");
			if(scanner.next().equals("1")){
				if(custservobj.cancelReservation(bean)==1){
					System.out.println("Reservation cancelled");
					loop=1;
					Customer();
				}
				else{
					System.err.println("Could not cancel");
					viewupdateloop=1;
					viewUpdateCancelFlight();
				}
				
				
			}else{
				viewupdateloop=1;
				viewUpdateCancelFlight();
				
			}
		}
		else if(options.equals("4")){
			loop=1;
			Customer();
		}
		else{
			System.err.println("Enter correct number.");
			viewupdateloop=1;
			viewUpdateCancelFlight();
		}
		
		
		return 0;
	} //viewUpdateCancelFlight() ends here
	
	
	
	
	
}