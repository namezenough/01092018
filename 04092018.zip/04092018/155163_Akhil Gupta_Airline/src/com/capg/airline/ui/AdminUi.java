package com.capg.airline.ui;

import java.util.Scanner;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.service.ADMINSERVICE.AdminServImpl;
import com.capg.airline.service.ADMINSERVICE.IAdminServ;

public class AdminUi {
	AirlineBean bean=new AirlineBean();
	String innercount=null;
	Scanner scanner=new Scanner(System.in);
	int loop=0;
	String funcChoose;
	IAdminServ admServObj=new AdminServImpl();
	public int Admin(){
		if(loop==0){
		System.out.println("Press 1 to get back to main menu, 2 to exit or Any other key to continue as Admin");
		innercount=scanner.next();
		if(innercount.equals("1"))
		{
			return 100;							
			
		}
		if(innercount.equals("2"))
		{
			System.out.println("Thanks for visiting us");
			System.exit(0);						
			
		}
		} // end of if(loop==0)
		
		
		System.out.println("Press 1 to generate an Airline Executive login credentials");
		System.out.println("Press 2 to generate an Admin login credentials");
		System.out.println("Press 3 to keep track of Flight Details");
		System.out.println("Press 4 to Update and manage flight details");
		System.out.println("Press 5 to Generate Reports");
		System.out.println("Press 6 to get back to Main menu");
		System.out.println("Press 7 to exit");
		innercount=scanner.next();
		if(innercount.equals("1")){
			airlineExecutiveSignUp();
		}
		else if(innercount.equals("2")){
			adminSignUp();
		}
		else if(innercount.equals("3")){
			trackFlight();
		}
		else if(innercount.equals("4")){
			updateManageFlight();
		}
		else if(innercount.equals("5")){
			
		}
		else if(innercount.equals("6")){
			AirlineUi.main(null);
		}
		else if(innercount.equals("7")){
			System.out.println("Thanks for Visiting.");
			System.exit(0);
		}
		else {
			System.out.println("Please enter correct number");
			loop=1;
			Admin();
	
		}
		
		return 0;
	
	}
	
	
	
	void airlineExecutiveSignUp(){
		System.out.println("Press 1 to go back");
		System.out.println("Else to go continue");
		funcChoose=scanner.next();
		if(funcChoose.equals("1")){
			loop=1;
			Admin();
		}
		else{
		System.out.println("Enter the mobile no of the Executive");
		Long mobileNo=scanner.nextLong();
		bean.setMobileNo(mobileNo);
		int userId=admServObj.airlineExecutiveSignUp(bean);
		if(userId==0){
			System.out.println("Could not Signup. Please Try again");
			airlineExecutiveSignUp();
		}
		else{
		System.out.println("Generate Airline Executive User Id is: "+userId);
		System.out.println("");
		loop=1;
		Admin();
		}
		}
		
	}

	
	
	
	void adminSignUp(){
		System.out.println("Press 1 to go back");
		System.out.println("Else to go continue");
		funcChoose=scanner.next();
		if(funcChoose.equals("1")){
			loop=1;
			Admin();
		}
		else{
		System.out.println("Enter the mobile no of the Executive");
		Long mobileNo=scanner.nextLong();
		bean.setMobileNo(mobileNo);
		int userId=admServObj.adminSignUp(bean);
		if(userId==0){
			System.out.println("Could not Signup. Please Try again");
			airlineExecutiveSignUp();
		}
		else{
		System.out.println("Generate Airline Executive User Id is: "+userId);
		System.out.println("");
		loop=1;
		Admin();
		}
		}
		
	}
	
	
	
	
	int trackFlight(){
		
		return 0;
	}
	
	
	
	
	void updateManageFlight(){
		System.out.println("Press 1 to go back, else to continue.");
		funcChoose=scanner.next();
		if(funcChoose.equals("1")){
			loop=1;
			Admin();
		}
		System.out.println("Enter flight no.");
		String flightno=scanner.next();
		bean.setFlightno(flightno);
		int checkExit=admServObj.checkIfFlightnoExist(bean);
		if(checkExit==0){
			System.out.println("Flight Does not exist");
			updateManageFlight();
		}
		else{
		System.out.println("Yes, this flight exists");
		System.out.println("Press 1 to Increase FIRST CLASS seats");
		System.out.println("Press 2 to Increase BUSINESS CLASS seats");
		System.out.println("Press 3 to Decrease FIRST CLASS seats");
		System.out.println("Press 4 to Decrease BUSINESS CLASS seats");
		System.out.println("Press 5 to change flight timings");
		System.out.println("Else to get back to Admin panel");
		funcChoose=scanner.next();
		if(funcChoose.equals("1")){
			System.out.println("Enter the new no of  seats to update in First Class");
			int firstSeatInc=scanner.nextInt();
			bean.setFirstSeatInc(firstSeatInc);
			firstSeatInc=admServObj.increaseFirstClassSeats(bean);
			if(firstSeatInc==0){
				System.out.println("Could not update. Please Try Again");
				updateManageFlight();
			}
			else{
				System.out.println("First Seat No updated");
				loop=1;
				Admin();
				
			}
		}
		
		
		else if(funcChoose.equals("2")){
			System.out.println("Enter the new no of seats to update in Business Class");
			int bussSeatInc=scanner.nextInt();
			bean.setBusinessSeatInc(bussSeatInc);
			bussSeatInc=admServObj.increaseBusinessClassSeats(bean);
			if(bussSeatInc==0){
				System.out.println("Could not update. Please Try Again");
				updateManageFlight();
			}
			else{
				System.out.println("First Seat No.s updated");
				loop=1;
				Admin();
			}

		} 
		
		
		else if(funcChoose.equals("3")){									  // start of decrease seats in first class
		System.out.println("Enter the no of seats you want to decrease in First Class");
		int firstSeatDec=scanner.nextInt();
		bean.setFirstSeatDec(firstSeatDec);
		int firstSeatDecActual = admServObj.decreaseFirstClassSeats(bean);
		if(firstSeatDecActual==0){
			System.out.println("Could not update because all seats are booked.");
			updateManageFlight();
		}
		else if(firstSeatDecActual==firstSeatDec){
			System.out.println("Successfully Removed "+firstSeatDecActual+" seats of FIRST CLASS");
			loop=1;
			Admin();
		}
		else if(firstSeatDecActual<firstSeatDec){
			System.err.println("Successfuly Removed only "+firstSeatDecActual+" seats of FIRST CLASS due to booking of remaining Seats");
			loop=1;
			Admin();
		}
		}																	// end of decrease seats in first class
		
		
		
		
		
		
		
		else if(funcChoose.equals("4")){									// start of decrease seats in business class
			
			System.out.println("Enter the no of seats you want to decrease in Business Class");
			int businessSeatDec=scanner.nextInt();
			bean.setBusinessSeatDec(businessSeatDec);
			int businessSeatDecActual = admServObj.decreaseBusinessClassSeats(bean);
			if(businessSeatDecActual==0){
				System.out.println("Could not update because all seats are booked.");
				updateManageFlight();
			}
			else if(businessSeatDecActual==businessSeatDec){
				System.out.println("Successfully Removed "+businessSeatDecActual+" seats of Business CLASS");
				loop=1;
				Admin();
			}
			else if(businessSeatDecActual<businessSeatDec){
				System.err.println("Successfuly Removed only "+businessSeatDecActual+" seats of Business CLASS due to booking of remaining Seats");
				loop=1;
				Admin();
			}
			
			
			
			
		}
		else if(funcChoose.equals("5")){
			
		}
		else{
			System.out.println("Taking back to Admin Menu");
			loop=1;
			Admin();
		}
		
		
		
		
		
		}
		
	}
	
}
