package com.capg.airline.dao.ADMIN;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.dao.IQueryMap;
import com.capg.airline.util.AirlineDbUtil;

public class AdminDAO implements IAdminDAO {
	Connection conn;
	PreparedStatement ps;
	ResultSet rs;
	int res=0;
	public AdminDAO(){
		conn=AirlineDbUtil.getConnection();
	}
	@Override
	public int checkAdminLogin(AirlineBean bean) {
		
		int calc=0;
		try {
			
			ps=conn.prepareStatement(IQueryMap.QUERY_LOGIN);
			ps.setString(1, bean.getUser_id());
			ps.setString(2, bean.getRole());
			rs= ps.executeQuery();
			
			if(rs.next()){
				System.out.println(rs.getString(1));
				if(rs.getString(1).equals(bean.getUser_password())){
					calc=1;
				}
				else{
					calc=0;
				}
			}
			else
			{
				calc=-1;
			}
			
			
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Exception occured in admin login");
		}
		
		return calc;
	}
	
	
	
	
	
	
	@Override
	public int airlineExecutiveSignUp(AirlineBean bean) {
		int userId=0;
		try {
			ps=conn.prepareStatement(IQueryMap.AIRLINE_EXECUTIVE_SIGNUP);
			ps.setLong(1, bean.getMobileNo());
			if(ps.executeUpdate()==1){
				ps=conn.prepareStatement(IQueryMap.GET_USERS_ID_SEQ_VALUE);
				rs=ps.executeQuery();
				if(rs.next()){
					String uid=rs.getString(1);
					userId=Integer.parseInt(uid);
				}
					
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userId;
	}
	
	
	
	
	
	@Override
	public int adminSignUp(AirlineBean bean) {
		int userId=0;
		try {
			ps=conn.prepareStatement(IQueryMap.ADMIN_SIGNUP);
			ps.setLong(1, bean.getMobileNo());
			if(ps.executeUpdate()==1){
				ps=conn.prepareStatement(IQueryMap.GET_USERS_ID_SEQ_VALUE);
				rs=ps.executeQuery();
				if(rs.next()){
					String uid=rs.getString(1);
					userId=Integer.parseInt(uid);
				}
					
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userId;
	}
	
	
	
	
	
	
	@Override
	public int checkIfFlightnoExist(AirlineBean bean) {
		int yesNo=0;
		try {
			
			ps=conn.prepareStatement(IQueryMap.CHECK_IF_FLIGHTNO_EXIST);
			ps.setString(1, bean.getFlightno());
			rs=ps.executeQuery();
			if(rs.next())
			{
				yesNo=1;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return yesNo;
	}
	
	
	
	
	
	
	
	@Override
	public int increaseFirstClassSeats(AirlineBean bean) {
		try {res=0;
			ps=conn.prepareStatement(IQueryMap.UPDATE_FIRST_CLASS_SEAT);
			ps.setString(2, bean.getFlightno());
			ps.setInt(1, bean.getFirstSeatInc());
			res=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return res;
	}
	
	
	
	
	
	
	
	@Override
	public int increaseBusinessClassSeats(AirlineBean bean) {
		try {res=0;
		ps=conn.prepareStatement(IQueryMap.UPDATE_BUSINESS_CLASS_SEAT);
		ps.setString(2, bean.getFlightno());
		ps.setInt(1, bean.getBusinessSeatInc());
		res=ps.executeUpdate();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	return res;
	}
	
	
	
	
	
	
	
	@Override
	public int decreaseFirstClassSeats(AirlineBean bean) {
		int finalFirstSeats=0;
		res=0;
		try {
		ps=conn.prepareStatement(IQueryMap.NO_OF_FIRST_CLASS_SEATS);
		ps.setString(1, bean.getFlightno());
		rs=ps.executeQuery();
		if(rs.next())
		{
			bean.setTotalFirstClassSeats(rs.getInt(1));
		}
		ps=conn.prepareStatement(IQueryMap.CHECK_FIRST_CLASS_SEAT_MAX_NO_RESERVED);
		ps.setString(1, bean.getFlightno());
		ps.setString(2,"FIRST CLASS");
		rs=ps.executeQuery();
		if(rs.next()){
			bean.setFilledFirstClassSeats(rs.getInt(1));
		}
		else{
			bean.setFilledFirstClassSeats(0);
		}
		if(bean.getTotalFirstClassSeats()-bean.getFilledFirstClassSeats()>=bean.getFirstSeatDec()){ // if the seats to be removed are vacant
			finalFirstSeats=bean.getTotalFirstClassSeats()-bean.getFirstSeatDec();
			res=bean.getFirstSeatDec();
		}
		else{ //if the seats to be removed are not vacant, then remove the max seats that we can remove
			finalFirstSeats=bean.getFilledFirstClassSeats();
			res=bean.getTotalFirstClassSeats()-bean.getFilledFirstClassSeats();
		}

		ps=conn.prepareStatement(IQueryMap.UPDATE_FIRST_CLASS_SEAT);
		ps.setInt(1, finalFirstSeats);
		ps.setString(2, bean.getFlightno());
		if(ps.executeUpdate()!=1)
			res=0;
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}
	
	
	
	
	
	
	
	@Override
	public int decreaseBusinessClassSeats(AirlineBean bean) {
		int finalBusinessSeats=0;
		res=0;
		try {
		ps=conn.prepareStatement(IQueryMap.NO_OF_BUSINESS_CLASS_SEATS);
		ps.setString(1, bean.getFlightno());
		rs=ps.executeQuery();
		if(rs.next())
		{
			bean.setTotalBusinessClassSeats(rs.getInt(1));
		}
		ps=conn.prepareStatement(IQueryMap.CHECK_BUSINESS_CLASS_SEAT_MAX_NO_RESERVED);
		ps.setString(1, bean.getFlightno());
		ps.setString(2,"BUSINESS CLASS");
		rs=ps.executeQuery();
		if(rs.next()){
			bean.setFilledBusinessClassSeats(rs.getInt(1));
		}
		else{
			bean.setFilledBusinessClassSeats(0);
		}
		if(bean.getTotalBusinessClassSeats()-bean.getFilledBusinessClassSeats()>=bean.getBusinessSeatDec()){ // if the seats to be removed are vacant
			finalBusinessSeats=bean.getTotalBusinessClassSeats()-bean.getBusinessSeatDec();
			res=bean.getBusinessSeatDec();
		}
		else{ //if the seats to be removed are not vacant, then remove the max seats that we can remove
			finalBusinessSeats=bean.getFilledBusinessClassSeats();
			res=bean.getTotalBusinessClassSeats()-bean.getFilledBusinessClassSeats();
		}

		ps=conn.prepareStatement(IQueryMap.UPDATE_FIRST_CLASS_SEAT);
		ps.setInt(1, finalBusinessSeats);
		ps.setString(2, bean.getFlightno());
		if(ps.executeUpdate()!=1)
			res=0;
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}

	
	
	
	
	
	
}
