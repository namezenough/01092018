package com.capg.airline.dao;

import com.capg.airline.beans.AirlineBean;

public interface ICombinedDAO {
	public abstract int checkLogin(AirlineBean bean);
}
