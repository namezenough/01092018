package com.capg.airline.ui;

import java.util.Scanner;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.service.CombinedServImpl;


public class AirlineUi {
	AirlineBean bean=new AirlineBean();
	int innercount=0;
	int logincheck=0;
	String user_id;
	
	
	String user_password;
	static int noOfLoginAttempts=0;
	Scanner scanner=new Scanner(System.in);
	AdminUi adminObj=new AdminUi();
	AirlineExecutiveUi aeUiObj=new AirlineExecutiveUi();
	public static void main(String[] args) {
		CustomerUi cuiobj= new CustomerUi();
		AirlineUi airObj=new AirlineUi();
		
		System.out.println("*********************************************");
		System.out.println("<------------------Airline------------------>");
		System.out.println("*********************************************");
		System.out.println("");
		Scanner scanner=new Scanner(System.in);
		int count=0;
		String funCount=null;
	
		do{      // 100 will be returned to get back to main menu.
			System.out.println("Press 1 to Search flight details");
			System.out.println("Press 2 to Reserve a flight");
			System.out.println("Press 3 to View/Update/Cancel any Reservation");
			System.out.println("Press 4 to To exit");
			System.out.println("Press 5 to To Login");
			funCount=scanner.next();
		switch(funCount){            //main switch (switch 1)
			/*
			 * Case 1 of main switch(switch 1) for customer
			 */
			case "1": System.out.println("You have chosen Customer");	
					count=cuiobj.Customer();
					break;
					
					
					
				
			case "2": 
				System.out.println("You have chosen Customer");	
				count=cuiobj.Customer();
					break;
					
					
				
					/*
					 * Case 3 of main switch(switch 1 for Admin )
					 */
			case "3": System.out.println("You have chosen Customer");	
			count=cuiobj.Customer();
					break;
					
					/*
					 * Case 4 of switch statement to exit the program
					 */
			case "4": System.out.println("You have chosen Exit");
					System.out.println("Thank for visit");
					System.exit(0);
					break;                         //final break of case 4 of switch 1
					
				
			case "5":
				count=airObj.checkLoginUi();
				
				break;
					
			default: System.out.println("You have chosen wrong number");	
				break;
					
					
			}
		if(count!=4 && count!=100){
		
		System.out.println("Choose:");
		System.err.println("4 to Exit, else to continue with main menu");
		funCount=scanner.next();}
		}while(count!=4);
		scanner.close();
		  
	} //End of main method
	
	
	int checkLoginUi(){
		
		
		if(noOfLoginAttempts<3){
			AirlineBean bean=new AirlineBean();
			System.out.println("Enter your user_id");

			bean.setUser_id(scanner.nextLine());
			System.out.println("Enter your password");
			bean.setUser_password(scanner.nextLine());
			CombinedServImpl combServObj=new CombinedServImpl();
			
			int role=combServObj.checkLogin(bean);
			if(role==0){
				System.out.println("Try Again");
				noOfLoginAttempts++;
				checkLoginUi();
			}
			else if(role==-1){
				System.out.println("Try Again");
				noOfLoginAttempts++;
				checkLoginUi();
			}
			else if(role==1){
				System.out.println("You are ADMIN");
				return adminObj.Admin();
			}
			else{
				if(role==2){
					System.out.println("You are AIRLINE EXCUTIVE");
					return aeUiObj.AirlineExecutive();
				}
			}
			
			}
			else{
				System.err.println("You have reached your max login attempts.");
			
			}
		
		
		
		return 0;
	}
	
	
	
	

}//End of class AirlineUi
