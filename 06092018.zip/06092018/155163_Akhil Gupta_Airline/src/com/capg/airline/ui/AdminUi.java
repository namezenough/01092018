package com.capg.airline.ui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.service.ADMINSERVICE.AdminServImpl;
import com.capg.airline.service.ADMINSERVICE.IAdminServ;

public class AdminUi {
	AirlineBean bean=new AirlineBean();
	String innercount=null;
	Scanner scanner=new Scanner(System.in);
	int loop=0;
	String funcChoose;
	IAdminServ admServObj=new AdminServImpl();
	public int Admin(){
		if(loop==0){
			System.out.println("Press 1 to Log Out");
			System.out.println("Press 2 to exit ");
			System.out.println("Press any other key to continue as Admin");	
			innercount=scanner.next();
		if(innercount.equals("1"))
		{
			return 100;							
			
		}
		if(innercount.equals("2"))
		{
			System.out.println("Thanks for visiting us");
			System.exit(0);						
			
		}
		} // end of if(loop==0)
		
		
		System.out.println("Press 1 to generate an Airline Executive login credentials");
		System.out.println("Press 2 to generate an Admin login credentials");
		System.out.println("Press 3 to Update and manage flight details");
		System.out.println("Press 4 to Generate Reports");
		System.out.println("Press 5 to Log Out");
		System.out.println("Press 6 to exit");
		innercount=scanner.next();
		if(innercount.equals("1")){
			airlineExecutiveSignUp();
		}
		else if(innercount.equals("2")){
			adminSignUp();
		}
		
		else if(innercount.equals("3")){
			updateManageFlight();
		}
		else if(innercount.equals("4")){
			generateAdminReports();
		}
		else if(innercount.equals("5")){
			AirlineUi.main(null);
		}
		else if(innercount.equals("6")){
			System.out.println("Thanks for Visiting.");
			System.exit(0);
		}
		else {
			System.err.println("Please enter correct number");
			loop=1;
			Admin();
	
		}
		
		return 0;
	
	}
	
	
	
	void airlineExecutiveSignUp(){
		System.out.println("Press 1 to go back");
		System.out.println("Else to go continue");
		funcChoose=scanner.next();
		if(funcChoose.equals("1")){
			loop=1;
			Admin();
		}
		else{
		System.out.println("Enter the mobile no of the Executive");
		Long mobileNo=scanner.nextLong();
		bean.setMobileNo(mobileNo);
		int userId=admServObj.airlineExecutiveSignUp(bean);
		if(userId==0){
			System.out.println("Could not Signup. Please Try again");
			airlineExecutiveSignUp();
		}
		else{
		System.out.println("Generate Airline Executive User Id is: "+userId);
		System.out.println("");
		loop=1;
		Admin();
		}
		}
		
	}

	
	
	
	void adminSignUp(){
		System.out.println("Press 1 to go back");
		System.out.println("Else to go continue");
		funcChoose=scanner.next();
		if(funcChoose.equals("1")){
			loop=1;
			Admin();
		}
		else{
		System.out.println("Enter the mobile no of the Executive");
		Long mobileNo=scanner.nextLong();
		bean.setMobileNo(mobileNo);
		int userId=admServObj.adminSignUp(bean);
		if(userId==0){
			System.out.println("Could not Signup. Please Try again");
			airlineExecutiveSignUp();
		}
		else{
		System.out.println("Generate Airline Executive User Id is: "+userId);
		System.out.println("");
		loop=1;
		Admin();
		}
		}
		
	}
	
	
	
	
	
	
	
	void updateManageFlight(){
		System.out.println("Press 1 to go back");
		System.out.println("Press 2 to get list of flights departing from particular location ");
		System.out.println("Press 3 to get list of flights arriving to a particular location ");
		System.out.println("Else to continue with entering flight no");
		funcChoose=scanner.next();
		if(funcChoose.equals("1")){
			loop=1;
			Admin();
		}
		else if(funcChoose.equals("2")){    // start of get list of flights from particular location
			System.out.println("Enter the departure city");
			ArrayList<AirlineBean> flightslist=new ArrayList<AirlineBean>();
			bean.setDeptCity(scanner.next());;
			flightslist=admServObj.flightsDepartingFromCity(bean);
			if(flightslist.isEmpty())
			{
				System.out.println("No flight available from this city");
				generateAdminReports();
			}
			else{
				System.out.println("<---Here is the list of available flights departuring from entered location--->:\n");
				Iterator<AirlineBean> it=flightslist.iterator();
				while(it.hasNext()){
					AirlineBean beanob=it.next();
					System.out.println("Flightno: "+ beanob.getFlightno());
					System.out.println("Departure City: "+ beanob.getDeptCity());
					System.out.println("Arrival City: "+beanob.getArrCity());
					System.out.println("Dept Date: "+beanob.getDeptDate());
					System.out.println("Arrival Date: "+beanob.getArrDate());
					System.out.println("");
				}
				
			}
			
		}											//end of  get list of flights from particular location
		
		
		
		
		else if(funcChoose.equals("3")){			//start of get list of flights to a particular location
			System.out.println("Enter the arrival city");
			ArrayList<AirlineBean> flightslist=new ArrayList<AirlineBean>();
			bean.setArrCity(scanner.next());;
			flightslist=admServObj.flightsArrivingToCity(bean);
			if(flightslist.isEmpty())
			{
				System.out.println("No flight available from this city");
				generateAdminReports();
			}
			else{
				System.out.println("<---Here is the list of available flights arriving to entered location--->:\n");
				Iterator<AirlineBean> it=flightslist.iterator();
				while(it.hasNext()){
					AirlineBean beanob=it.next();
					System.out.println("Flightno: "+ beanob.getFlightno());
					System.out.println("Departure City: "+ beanob.getDeptCity());
					System.out.println("Arrival City: "+beanob.getArrCity());
					System.out.println("Dept Date: "+beanob.getDeptDate());
					System.out.println("Arrival Date: "+beanob.getArrDate());
					System.out.println("");
				}
				
			}
		}
		System.out.println("Enter flight no.");
		String flightno=scanner.next();
		bean.setFlightno(flightno);
		int checkExit=admServObj.checkIfFlightnoExist(bean);
		if(checkExit==0){
			System.out.println("Flight Does not exist");
			updateManageFlight();
		}
		else{
		System.out.println("Yes, this flight exists");
		System.out.println("Press 1 to Increase FIRST CLASS seats");
		System.out.println("Press 2 to Increase BUSINESS CLASS seats");
		System.out.println("Press 3 to Decrease FIRST CLASS seats");
		System.out.println("Press 4 to Decrease BUSINESS CLASS seats");
		System.out.println("Press 5 to change flight timings");
		System.out.println("Press 6 to change First Class Charges");
		System.out.println("Press 7 to change Business Class Charges");
		System.out.println("Else to get back to Admin panel");
		funcChoose=scanner.next();
		if(funcChoose.equals("1")){
			System.out.println("Enter the new no of  seats to update in First Class");
			int firstSeatInc=scanner.nextInt();
			bean.setFirstSeatInc(firstSeatInc);
			firstSeatInc=admServObj.increaseFirstClassSeats(bean);
			if(firstSeatInc==0){
				System.out.println("Could not update. Please Try Again");
				updateManageFlight();
			}
			else{
				System.out.println("First Seat No updated");
				loop=1;
				Admin();
				
			}
		}
		
		
		else if(funcChoose.equals("2")){
			System.out.println("Enter the new no of seats to update in Business Class");
			int bussSeatInc=scanner.nextInt();
			bean.setBusinessSeatInc(bussSeatInc);
			bussSeatInc=admServObj.increaseBusinessClassSeats(bean);
			if(bussSeatInc==0){
				System.out.println("Could not update. Please Try Again");
				updateManageFlight();
			}
			else{
				System.out.println("First Seat No.s updated");
				loop=1;
				Admin();
			}

		} 
		
		
		else if(funcChoose.equals("3")){									  // start of decrease seats in first class
		System.out.println("Enter the no of seats you want to decrease in First Class");
		int firstSeatDec=scanner.nextInt();
		bean.setFirstSeatDec(firstSeatDec);
		int firstSeatDecActual = admServObj.decreaseFirstClassSeats(bean);
		if(firstSeatDecActual==0){
			System.out.println("Could not update because all seats are booked.");
			updateManageFlight();
		}
		else if(firstSeatDecActual==firstSeatDec){
			System.out.println("Successfully Removed "+firstSeatDecActual+" seats of FIRST CLASS");
			loop=1;
			Admin();
		}
		else if(firstSeatDecActual<firstSeatDec){
			System.err.println("Successfuly Removed only "+firstSeatDecActual+" seats of FIRST CLASS due to booking of remaining Seats");
			loop=1;
			Admin();
		}
		}																	// end of decrease seats in first class
		
		
		
		
		
		
		
		else if(funcChoose.equals("4")){									// start of decrease seats in business class
			
			System.out.println("Enter the no of seats you want to decrease in Business Class");
			int businessSeatDec=scanner.nextInt();
			bean.setBusinessSeatDec(businessSeatDec);
			int businessSeatDecActual = admServObj.decreaseBusinessClassSeats(bean);
			if(businessSeatDecActual==0){
				System.out.println("Could not update because all seats are booked.");
				updateManageFlight();
			}
			else if(businessSeatDecActual==businessSeatDec){
				System.out.println("Successfully Removed "+businessSeatDecActual+" seats of Business CLASS");
				loop=1;
				Admin();
			}
			else if(businessSeatDecActual<businessSeatDec){
				System.err.println("Successfuly Removed only "+businessSeatDecActual+" seats of Business CLASS due to booking of remaining Seats");
				loop=1;
				Admin();
			}
			
			
			
			
		}																	//end of decrease seats in business class
		
		
		
		else if(funcChoose.equals("5")){
			System.out.println("Enter departure date and time in the format: 'yyyy/mm/dd hh24:mi:ss'");
			scanner.nextLine();
			bean.setDeptDate(scanner.nextLine());
			System.out.println("Enter arrival date and time in the format: 'yyyy/mm/dd hh24:mi:ss'");
			bean.setArrDate(scanner.nextLine());
			int res=admServObj.updateFlightTiming(bean);
			if(res==1){
				System.out.println("<---Date Updated Successfully--->");
				loop=1;
				Admin();
			}
			else{
				System.err.println("Sorry Could not update date. Try Again");
				updateManageFlight();
			}
		}
		else if(funcChoose.equals("6")){
			System.out.println("Enter the new charges for FIRST CLASS seats");
			int firstClassFare=scanner.nextInt();
			if(firstClassFare<20000)
			{
				bean.setFirstClassFare(firstClassFare);
				if(admServObj.updateFirstCLassFare(bean)==1){
					System.out.println("First Class Fare Updated Successfully");
					updateManageFlight();
				}
				else{
					System.err.println("Sorry, Could not update");
					updateManageFlight();
				}
			}
			else{
				System.err.println("Cost must be less than 20000");
				updateManageFlight();
			}
		}          // end of option 6
		
		
		
		
		else if(funcChoose.equals("7")){
			System.out.println("Enter the new charges for Business CLASS seats");
			int businessClassFare=scanner.nextInt();
			if(businessClassFare<20000)
			{
				bean.setBusinessClassFare(businessClassFare);
				if(admServObj.updateBusinessCLassFare(bean)==1){
					System.out.println("Business Class Fare Updated Successfully");
					updateManageFlight();
				}
				else{
					System.err.println("Sorry, Could not update");
					updateManageFlight();
				}
			}
			else{
				System.err.println("Cost must be less than 20000");
				updateManageFlight();
			}
		}
		else{
			System.out.println("Taking back to Admin Menu");
			loop=1;
			Admin();
		}
		
		
		
		
		
		}
		
	}
	
	
	
	
	
	
	void generateAdminReports(){
		System.out.println("Press 1 to go back, else to continue");
		funcChoose=scanner.next();
		if(funcChoose.equals("1")){
			loop=1;
			Admin();
		}
		else{
			System.out.println("Press 1 to get list of flights daparting on a particular day");
			System.out.println("Press 2 to get list of flights departing from particular location");
			System.out.println("Press 3 to get list of flights arriving to a particular location");
			System.out.println("Press 4 to go back to Admin's main menu");
			System.out.println("Else to exit");
			funcChoose=scanner.next();
			if(funcChoose.equals("1")){       //start of get list of flights daparting on a particular day
				System.out.println("Enter departure date int the format 'yyyy/mm/dd'");
				bean.setDeptDate(scanner.next());
				ArrayList<AirlineBean> flightslist=new ArrayList<AirlineBean>();
				flightslist=admServObj.flightsDepartingOnDate(bean);
				if(flightslist.isEmpty())
				{
					System.out.println("No flight available on this particular day");
					generateAdminReports();
				}
				else{
					System.out.println("<---Here is the list of available flights--->:\n");
					Iterator<AirlineBean> it=flightslist.iterator();
					while(it.hasNext()){
						AirlineBean beanob=it.next();
						System.out.println("Flightno: "+ beanob.getFlightno());
						System.out.println("Departure City: "+ beanob.getDeptCity());
						System.out.println("Arrival City: "+beanob.getArrCity());
						System.out.println("");
					}
					loop=1;
					Admin();
				}
				
			}                                   // end of get list of flights daparting on a particular day
			
			
			else if(funcChoose.equals("2")){    // start of get list of flights from particular location
				System.out.println("Enter the departure city");
				ArrayList<AirlineBean> flightslist=new ArrayList<AirlineBean>();
				bean.setDeptCity(scanner.next());;
				flightslist=admServObj.flightsDepartingFromCity(bean);
				if(flightslist.isEmpty())
				{
					System.out.println("No flight available from this city");
					generateAdminReports();
				}
				else{
					System.out.println("<---Here is the list of available flights departuring from entered location--->:\n");
					Iterator<AirlineBean> it=flightslist.iterator();
					while(it.hasNext()){
						AirlineBean beanob=it.next();
						System.out.println("Flightno: "+ beanob.getFlightno());
						System.out.println("Departure City: "+ beanob.getDeptCity());
						System.out.println("Arrival City: "+beanob.getArrCity());
						System.out.println("Dept Date: "+beanob.getDeptDate());
						System.out.println("Arrival Date: "+beanob.getArrDate());
						System.out.println("");
					}
					loop=1;
					Admin();
				}
				
			}											//end of  get list of flights from particular location
			
			
			
			
			else if(funcChoose.equals("3")){			//start of get list of flights to a particular location
				System.out.println("Enter the arrival city");
				ArrayList<AirlineBean> flightslist=new ArrayList<AirlineBean>();
				bean.setArrCity(scanner.next());;
				flightslist=admServObj.flightsArrivingToCity(bean);
				if(flightslist.isEmpty())
				{
					System.out.println("No flight available from this city");
					generateAdminReports();
				}
				else{
					System.out.println("<---Here is the list of available flights arriving to entered location--->:\n");
					Iterator<AirlineBean> it=flightslist.iterator();
					while(it.hasNext()){
						AirlineBean beanob=it.next();
						System.out.println("Flightno: "+ beanob.getFlightno());
						System.out.println("Departure City: "+ beanob.getDeptCity());
						System.out.println("Arrival City: "+beanob.getArrCity());
						System.out.println("Dept Date: "+beanob.getDeptDate());
						System.out.println("Arrival Date: "+beanob.getArrDate());
						System.out.println("");
					}
					loop=1;
					Admin();
				}
			}
			else if(funcChoose.equals("4")){
				loop=1;
				Admin();
			}
			else{
				System.out.println("Thank You for Visiting!");
				System.exit(0);
			}
			
			
			
		}
	}
	
}





	