package com.capg.airline.service.ADMINSERVICE;

import java.util.ArrayList;

import com.capg.airline.beans.AirlineBean;

public interface IAdminServ {
	public abstract int checkAdminLogin(AirlineBean bean);
	public abstract int airlineExecutiveSignUp(AirlineBean bean);
	public abstract int adminSignUp(AirlineBean bean);
	public abstract int checkIfFlightnoExist(AirlineBean bean);
	public abstract int increaseFirstClassSeats(AirlineBean bean);
	public abstract int increaseBusinessClassSeats(AirlineBean bean);
	public abstract int decreaseFirstClassSeats(AirlineBean bean);
	public abstract int decreaseBusinessClassSeats(AirlineBean bean);
	public abstract int updateFlightTiming(AirlineBean bean);
	public abstract int updateFirstCLassFare(AirlineBean bean);
	public abstract int updateBusinessCLassFare(AirlineBean bean);
	public abstract ArrayList<AirlineBean> flightsDepartingOnDate(AirlineBean bean);
	public abstract ArrayList<AirlineBean> flightsDepartingFromCity(AirlineBean bean);
	public abstract ArrayList<AirlineBean> flightsArrivingToCity(AirlineBean bean);


}
