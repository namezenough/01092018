package com.capg.airline.service.CUSTOMERSERVICE;

import java.util.LinkedHashMap;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.dao.CUSTOMERDAO.CustomerDAO;
import com.capg.airline.dao.CUSTOMERDAO.ICustomerDAO;

public class CustomerServImpl implements ICustomerServ {
ICustomerDAO custdao;
	public CustomerServImpl() {
		custdao=new CustomerDAO();
	}
	@Override
	public AirlineBean searchFlightByNo(AirlineBean bean) {
		return custdao.searchFlightByNo(bean);
	}
	@Override
	public LinkedHashMap<String, AirlineBean> searchByCity(AirlineBean bean) {
		
		return custdao.searchByCity(bean);
	}
	@Override
	public int checkAvailability(AirlineBean bean) {
		
		return custdao.checkAvailability(bean);
	}
	@Override
	public String confirmBoking(AirlineBean bean) {
		
		return custdao.confirmBoking(bean);
	}
	@Override
	public String checkBookingId(AirlineBean bean) {
		
		return custdao.checkBookingId(bean);
	}
	@Override
	public int updateMailId(AirlineBean bean) {
		
		return custdao.updateMailId(bean);
	}
	@Override
	public int cancelReservation(AirlineBean bean) {
		
		return custdao.cancelReservation(bean);
	}

}
