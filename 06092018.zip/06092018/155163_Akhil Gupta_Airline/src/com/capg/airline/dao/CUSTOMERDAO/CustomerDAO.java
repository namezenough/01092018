package com.capg.airline.dao.CUSTOMERDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;



import com.capg.airline.beans.AirlineBean;
import com.capg.airline.dao.IQueryMap;
import com.capg.airline.util.AirlineDbUtil;

public class CustomerDAO implements ICustomerDAO{

	Connection conn;
	
	@Override
	public AirlineBean searchFlightByNo(AirlineBean beanrec) {
		AirlineBean bean=null;
		conn=AirlineDbUtil.getConnection();
		try {
			PreparedStatement ps=conn.prepareStatement(IQueryMap.SEARCH_BY_FLIGHTNO);
			ps.setString(1, beanrec.getFlightno());
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				bean=new AirlineBean();
				bean.setFlightno(rs.getString(1));
				bean.setAirline(rs.getString(2));
				bean.setDeptCity(rs.getString(3));
				bean.setArrCity(rs.getString(4));
				String depdate=rs.getString(5); //get dep date and time in string
				String arrdate=rs.getString(6); //get arr date and time in string
				bean.setArrDate(arrdate.substring(0,10));
				bean.setArrTime(arrdate.substring(10));
				bean.setDeptDate(depdate.substring(0, 10));
				bean.setDeptTime(depdate.substring(10));
				bean.setFirstClassFare(rs.getInt(8));
				bean.setBusinessClassFare(rs.getInt(10));
				return bean;
			}
			else{
				System.out.println("No data found. Check for valid flight number");
				return bean;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Exception in Client Dao");
		}
		return bean;
	}  // end of searchFlightByNo
	
	
	
	
	
	
	

	@Override
	public LinkedHashMap<String, AirlineBean> searchByCity(AirlineBean bean) {
		LinkedHashMap<String, AirlineBean> beanHashMap=new LinkedHashMap<String, AirlineBean>();
		conn=AirlineDbUtil.getConnection();
		try {
			PreparedStatement ps=conn.prepareStatement(IQueryMap.SEARCH_BY_CITY);
			ps.setString(1, bean.getDeptCity());
			ps.setString(2, bean.getArrCity());
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				bean=new AirlineBean();
					
					bean.setFlightno(rs.getString(1));
					bean.setAirline(rs.getString(2));
					bean.setDeptCity(rs.getString(3));
					bean.setArrCity(rs.getString(4));
					bean.setDeptDate(rs.getString(5));
					bean.setArrDate(rs.getString(6));
					beanHashMap.put(bean.getFlightno(),bean); //STORE VALUES IN MAP
				
			}
			
				return beanHashMap;
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Exception in Client Dao.");
		}
		return beanHashMap;
	}








	
	@Override
	public int checkAvailability(AirlineBean bean) {
		conn=AirlineDbUtil.getConnection();
		int maxFlightNoReserv=0;
		int toatalseats=0;
		
		if(bean.getFlightClass().equals("FIRST CLASS")){ // check availabilty of seat in  given flightno for first class seat
			try {
				PreparedStatement ps=conn.prepareStatement(IQueryMap.CHECK_FIRST_CLASS_SEAT_MAX_NO_RESERVED);
				ps.setString(1, bean.getFlightno());			
				ps.setString(2, bean.getFlightClass());
				ResultSet rs=ps.executeQuery();
				if(rs.next()){
					 maxFlightNoReserv=rs.getInt(1);
				}
				
				ps=conn.prepareStatement(IQueryMap.NO_OF_FIRST_CLASS_SEATS);
				ps.setString(1,bean.getFlightno());
				rs=ps.executeQuery();
				if(rs.next()){
					toatalseats=rs.getInt(1);
				}
				
				if(maxFlightNoReserv<toatalseats)
				{
					
					return maxFlightNoReserv+1;
				}
				else{
					return -1;
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else{// check availabilty of seat in  given flightno for business class seat
			int totalfirstClassSeats=0;
			int totalbusinessClassSeats=0;
			try {
				PreparedStatement ps=conn.prepareStatement(IQueryMap.NO_OF_BOTH_CLASS_SEATS);
				ps.setString(1,bean.getFlightno());
				ResultSet rs=ps.executeQuery();
				if(rs.next()){
					totalfirstClassSeats=rs.getInt(1);
					totalbusinessClassSeats=rs.getInt(2);
				}
				 ps=conn.prepareStatement(IQueryMap.CHECK_FIRST_CLASS_SEAT_MAX_NO_RESERVED);
				ps.setString(1, bean.getFlightno());			
				ps.setString(2, bean.getFlightClass());
				rs=ps.executeQuery();
				if(rs.next()){
					 maxFlightNoReserv=rs.getInt(1);
				}
				if(maxFlightNoReserv<totalfirstClassSeats){
					return maxFlightNoReserv=totalfirstClassSeats+1;
				}
				else if(maxFlightNoReserv< totalbusinessClassSeats +totalfirstClassSeats){
					return maxFlightNoReserv+1;
				}
				else{
					return -1;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return 0;
	}








	@Override
	public String confirmBoking(AirlineBean bean) {
		String bookingId=null;
		conn=AirlineDbUtil.getConnection();
		try {
			PreparedStatement ps=null;
			if(bean.getFlightClass()=="FIRST CLASS")
			ps=conn.prepareStatement(IQueryMap.GET_FIRST_CLASS_FARE_COST);
			else
			ps=conn.prepareStatement(IQueryMap.GET_BUSINESS_CLASS_FARE_COST);
			ps.setString(1,bean.getFlightno());
			ResultSet rs=ps.executeQuery();
			if(rs.next())
				bean.setFareCost(rs.getInt(1));
			//System.out.println(bean.getFareCost());
			/*System.out.println(bean.getEmailID()+ bean.getFlightClass()+ bean.getFareCost()+bean.getSeatNoToBeBooked()+ bean.getCreditcardno() );
			System.out.println(bean.getDeptCity()+ bean.getArrCity() +bean.getFlightno());*/
			ps=conn.prepareStatement(IQueryMap.CONFIRM_BOOKING);
			ps.setString(1,bean.getEmailID());
			ps.setString(2,bean.getFlightClass());
			ps.setInt(3,bean.getFareCost());
			ps.setInt(4,bean.getSeatNoToBeBooked());
			ps.setString(5,bean.getCreditcardno());
			ps.setString(6,bean.getDeptCity());
			ps.setString(7,bean.getArrCity());
			ps.setString(8,bean.getFlightno());
			if(ps.executeUpdate() ==1){
				ps=conn.prepareStatement(IQueryMap.GET_BOOKING_ID_SEQ_VALUE);
				rs=ps.executeQuery();
				if(rs.next())
				bean.setBookingId(rs.getString(1));
				bookingId=bean.getBookingId();
				
			}
			
			
			
			
		} catch (SQLException e) {
			System.out.println("Exception in customer dao");
			e.printStackTrace();
		}
		return bookingId;
	}








	
	
	
	
	
	
	
	@Override
	public String checkBookingId(AirlineBean bean) {
		conn=AirlineDbUtil.getConnection();
		String flightno=null;
		try {
			PreparedStatement ps=conn.prepareStatement(IQueryMap.CHECK_BOOKING_ID);
			ps.setString(1, bean.getBookingId());
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				flightno=rs.getString(1);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flightno;
	}








	
	
	
	
	
	
	
	@Override
	public int updateMailId(AirlineBean bean) {
		conn=AirlineDbUtil.getConnection();
		int res=0;
		PreparedStatement ps;
		try {
			
			ps = conn.prepareStatement(IQueryMap.UPDATE_MAIL_ID);
			ps.setString(1, bean.getEmailID());
			ps.setString(2, bean.getBookingId());
			res=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return res;
	}








	@Override
	public int cancelReservation(AirlineBean bean) {
		conn=AirlineDbUtil.getConnection();
		int res=0;
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement(IQueryMap.CANCEL_RESERVATION);
			ps.setString(1, bean.getBookingId());
			res=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return res;
	}

}





