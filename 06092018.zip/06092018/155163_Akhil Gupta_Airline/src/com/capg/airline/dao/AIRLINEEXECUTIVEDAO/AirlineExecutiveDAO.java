package com.capg.airline.dao.AIRLINEEXECUTIVEDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.dao.IQueryMap;
import com.capg.airline.util.AirlineDbUtil;

public class AirlineExecutiveDAO implements IAirlineExecutiveDAO{

	Connection conn;
	PreparedStatement ps;
	ResultSet rs;
	public AirlineExecutiveDAO() {
		
	}
	@Override
	public int checkAirlineExecutiveLogin(AirlineBean bean) {
		conn=AirlineDbUtil.getConnection();
		int calc=0;
		try {
			
			PreparedStatement ps=conn.prepareStatement(IQueryMap.QUERY_LOGIN);
			ps.setString(1, bean.getUser_id());
			ps.setString(2, bean.getRole());
			rs= ps.executeQuery();
			
			if(rs.next()){
				
				if(rs.getString(1).equals(bean.getUser_password())){
					calc=1;
				}
				else{
					calc=0;
				}
			}
			else
			{
				calc=-1;
			}
			
			
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Exception occured in airline exec login.");
		}
		
		return calc;
	}
	
	
	
	
	
	
	
	@Override
	public int totalBookedSeats() {
		conn=AirlineDbUtil.getConnection();
		try {
			 ps=conn.prepareStatement(IQueryMap.TOTAL_BOOKED_SEATS);
			 rs=ps.executeQuery();
			if(rs.next()){
				return rs.getInt(1);
			}
			else{
				return 0;
			}
		} catch (SQLException e) {
			System.out.println("Exception in checking total booked seats.");
			e.printStackTrace();
		}
		return 0;
	}

	
	
	
	
	
	@Override
	public int futureBookedSeats() {
		conn=AirlineDbUtil.getConnection();
		try {
			 ps=conn.prepareStatement(IQueryMap.FUTURE_BOOKED_SEATS);
			 rs=ps.executeQuery();
			if(rs.next()){
				return rs.getInt(1);
			}
			else{
				return 0;
			}
		} catch (SQLException e) {
			System.out.println("Exception in checking total booked seats.");
			e.printStackTrace();
		}
		return 0;
	}

	
	
	
	
	@Override
	public ArrayList<AirlineBean> checkOccupancy(AirlineBean bean) {
		ArrayList<AirlineBean> checkOccupancyList=new ArrayList<AirlineBean>();
		conn=AirlineDbUtil.getConnection();
		
		try {
			ps=conn.prepareStatement(IQueryMap.NO_OF_FIRST_CLASS_SEATS);
			ps.setString(1, bean.getFlightno());
			rs=ps.executeQuery();
			if(rs.next()){
				bean.setTotalFirstClassSeats(rs.getInt(1));
			}
			ps=conn.prepareStatement(IQueryMap.CHECK_FIRST_CLASS_SEAT_MAX_NO_RESERVED);
			ps.setString(1, bean.getFlightno());
			ps.setString(2,"FIRST CLASS");
			rs=ps.executeQuery();
			if(rs.next()){
				bean.setFilledFirstClassSeats(rs.getInt(1));
			}
			
			ps=conn.prepareStatement(IQueryMap.NO_OF_BUSINESS_CLASS_SEATS);
			ps.setString(1, bean.getFlightno());
			rs=ps.executeQuery();
			if(rs.next()){
				bean.setTotalBusinessClassSeats(rs.getInt(1));
			}
			ps=conn.prepareStatement(IQueryMap.CHECK_BUSINESS_CLASS_SEAT_MAX_NO_RESERVED);
			ps.setString(1, bean.getFlightno());
			ps.setString(2, "BUSINESS CLASS");
			rs=ps.executeQuery();
			if(rs.next()){
				int maxBussSeatNo=rs.getInt(1);
				int filledBusinessSeats=maxBussSeatNo-bean.getTotalBusinessClassSeats();
				bean.setFilledBusinessClassSeats(filledBusinessSeats);
			}
			checkOccupancyList.add(bean);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return checkOccupancyList;
	}

}
