package com.capg.airline.dao.AIRLINEEXECUTIVEDAO;

import java.util.ArrayList;

import com.capg.airline.beans.AirlineBean;

public interface IAirlineExecutiveDAO {
	
		public abstract int checkAirlineExecutiveLogin(AirlineBean bean);
		public abstract int totalBookedSeats();
		public abstract int futureBookedSeats();
		public abstract ArrayList<AirlineBean> checkOccupancy(AirlineBean bean);
}
