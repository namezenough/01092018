/*
 * <-----------------------------------------------******Airline_Akhil Gupta_155163_11thJuly_AbridgeBatch******----------------------------------------------------->
 * This class has methods to test the methods of CustomerDAO Class
 */
package com.capg.airline.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.dao.CUSTOMERDAO.CustomerDAO;
import com.capg.airline.dao.CUSTOMERDAO.ICustomerDAO;
import com.capg.airline.exception.MyAirlineException;

public class CustomerDAOTest extends CustomerDAO {

	ICustomerDAO custObj;
	AirlineBean beanObj;
	
	
	public CustomerDAOTest() {                                                                 //Unparametrized constructor
		custObj=new CustomerDAO();
		beanObj=new AirlineBean();
	}
	@Test
	public void testCheckAvailability() throws MyAirlineException{                                       //to test checkAvailability()
		beanObj.setFlightClass("FLIRST CLASS");
		beanObj.setFlightno("000");
		assertEquals(-1,custObj.checkAvailability(beanObj));
	}


	
	
	
	
	
	@Test
	public void testCheckBookingId() throws MyAirlineException{                                    //to test checkBookingId()
		beanObj.setBookingId("00");
		assertEquals(null, custObj.checkBookingId(beanObj));
	}

	
	
	
	
	
	
	@Test
	public void testUpdateMailId() throws MyAirlineException {                                    //to test updateMailId()
		beanObj.setEmailID("abc@xyz.com");
		beanObj.setBookingId("00");
		assertEquals(0, custObj.updateMailId(beanObj));
	}

	
	
	
	
	
	@Test
	public void testCancelReservation() throws MyAirlineException {                                    //to test cancelReservation()
		beanObj.setBookingId("000");
		assertEquals(0, custObj.cancelReservation(beanObj));
	}

}
