/*
 * <-----------------------------------------------******Airline_Akhil Gupta_155163_11thJuly_AbridgeBatch******----------------------------------------------------->
 * This class has methods to test the methods of CombinedDAOImpl Class
 */

package com.capg.airline.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.dao.CombinedDAOImpl;
import com.capg.airline.dao.ICombinedDAO;
import com.capg.airline.exception.MyAirlineException;

public class CombinedDAOImplTest extends CombinedDAOImpl {
ICombinedDAO combObj;
AirlineBean beanObj;


	public CombinedDAOImplTest() {
		combObj=new CombinedDAOImpl();
		beanObj=new AirlineBean();
	}

	
	
	
	@Test
	public void testCheckLogin() throws MyAirlineException{														// to test checkLogin()
		beanObj.setUser_id("00");
		assertEquals(0, combObj.checkLogin(beanObj));
		
	}

}
