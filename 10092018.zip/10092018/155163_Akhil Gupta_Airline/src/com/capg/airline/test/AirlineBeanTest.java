/*
 * <-----------------------------------------------******Airline_Akhil Gupta_155163_11thJuly_AbridgeBatch******----------------------------------------------------->
 * This class has methods to test the methods of Bean Class
 */
package com.capg.airline.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capg.airline.beans.AirlineBean;

public class AirlineBeanTest {
AirlineBean beanObj;


	public AirlineBeanTest() {
		beanObj=new AirlineBean();
		}
	@Test
	public void testGetClassType() {													// to test getClassType
		beanObj.setClassType("ABC");
		assertEquals("ABC",beanObj.getClassType());
		
	}

	@Test
	public void testGetNoOfBookings() {													// to test getNoOfBookings()
		beanObj.setNoOfBookings(1);
		assertEquals(1, beanObj.getNoOfBookings());
		
	}

	@Test
	public void testGetFirstClassFare() {													// to test getFirstClassFare()
		beanObj.setFirstClassFare(100);
		assertEquals(100,beanObj.getFirstClassFare());
		}

	@Test
	public void testGetBusinessClassFare() {													// to test getBusinessClassFare()
		beanObj.setBusinessClassFare(100);
		assertEquals(100,beanObj.getBusinessClassFare() );
		}

	@Test
	public void testGetFirstSeatInc() {													// to test getFirstSeatInc()
		beanObj.setFirstSeatInc(1);
		assertEquals(1,beanObj.getFirstSeatInc() );
		}

	@Test
	public void testGetBusinessSeatInc() {													// to test getBusinessSeatInc()
		beanObj.setBusinessSeatInc(1);
		assertEquals(1,beanObj.getBusinessSeatInc() );
		}

	@Test
	public void testGetFirstSeatDec() {													// to test getFirstSeatDec()
		beanObj.setFirstSeatDec(1);
		assertEquals(1,beanObj.getFirstSeatDec() );
		}

	@Test
	public void testGetBusinessSeatDec() {													// to test getBusinessSeatDec() 
		beanObj.setBusinessSeatDec(1);
		assertEquals(1,beanObj.getBusinessSeatDec() );}

	@Test
	public void testGetMobileNo() {													// to test getMobileNo() 
		String s="123";
		Long l=Long.parseLong(s);
		beanObj.setMobileNo(l);
		assertEquals(l,beanObj.getMobileNo() );
		}

	@Test
	public void testGetTotalFirstClassSeats() {													// to test getTotalFirstClassSeats() 
		beanObj.setTotalFirstClassSeats(1);
		assertEquals(1,beanObj.getTotalFirstClassSeats() );
		}

	@Test
	public void testGetFilledFirstClassSeats() {													// to test getFilledFirstClassSeats()
		beanObj.setFilledFirstClassSeats(1);
		assertEquals(1,beanObj.getFilledFirstClassSeats() );	
		}

	@Test
	public void testGetTotalBusinessClassSeats() {													// to test getTotalBusinessClassSeats()
		beanObj.setTotalBusinessClassSeats(1);
		assertEquals(1,beanObj.getTotalBusinessClassSeats() );	}

	@Test
	public void testGetFilledBusinessClassSeats() {													// to test getFilledBusinessClassSeats()
		beanObj.setFilledBusinessClassSeats(1);
		assertEquals(1,beanObj.getFilledBusinessClassSeats() );	}

	@Test
	public void testGetBookingId() {													// to test getBookingId()
		beanObj.setBookingId("1");
		assertEquals("1",beanObj.getBookingId() );	}

	@Test
	public void testGetFareCost() {													// to test getFareCost() 
		beanObj.setFareCost(1);
		assertEquals(1,beanObj.getFareCost() );	}

	@Test
	public void testGetEmailID() {													// to test getEmailID() 
		beanObj.setEmailID("a");
		assertEquals("a",beanObj.getEmailID() );	}

	@Test
	public void testGetCreditcardno() {													// to test getCreditcardno()
		beanObj.setCreditcardno("1");
		assertEquals("1",beanObj.getCreditcardno() );	}

	@Test
	public void testGetSeatNoToBeBooked() {													// to test getSeatNoToBeBooked()
		beanObj.setSeatNoToBeBooked(1);
		assertEquals(1,beanObj.getSeatNoToBeBooked() );	}

	@Test
	public void testGetFlightClass() {													// to test getFlightClass() 
		beanObj.setFlightClass("a");
		assertEquals("a",beanObj.getFlightClass() );	
		}

	@Test
	public void testGetAirline() {													// to test getAirline() 
		beanObj.setAirline("a");
		assertEquals("a",beanObj.getAirline() );
		}

	@Test
	public void testGetDeptCity() {													// to test getDeptCity() 
		beanObj.setDeptCity("a");
		assertEquals("a",beanObj.getDeptCity() );
		}

	@Test
	public void testGetArrCity() {													// to test getArrCity()
		beanObj.setArrCity("a");
		assertEquals("a",beanObj.getArrCity() );	
		}

	@Test
	public void testGetDeptDate() {													// to test getDeptDate()
		beanObj.setDeptDate("2018/05/05");
		assertEquals("2018/05/05",beanObj.getDeptDate() );
		}

	@Test
	public void testGetDeptTime() {													// to test getDeptTime()
		beanObj.setDeptTime("20:11:11");
		assertEquals("20:11:11",beanObj.getDeptTime() );	
		}

	@Test
	public void testGetArrDate() {													// to test getArrDate()
		beanObj.setArrDate("2018/05/11");
		assertEquals("2018/05/11",beanObj.getArrDate() );	
		}

	@Test
	public void testGetArrTime() {												// to test getArrTime()
		beanObj.setArrTime("20:11:12");
		assertEquals("20:11:12",beanObj.getArrTime());	
		}

	@Test
	public void testGetFlightno() {												// to test getFlightno()
		beanObj.setFlightno("1");
		assertEquals("1",beanObj.getFlightno() );	
		}

	@Test
	public void testGetUser_id() {												// to test getUser_id()
		beanObj.setUser_id("1");
		assertEquals("1",beanObj.getUser_id() );	
		}

	@Test
	public void testGetRole() {												// to test getRole() 
		beanObj.setRole("ADMIN");
		assertEquals("ADMIN",beanObj.getRole() );	
		}

	@Test
	public void testGetUser_password() {												// to test getUser_password()
		beanObj.setUser_password("1");
		assertEquals("1",beanObj.getUser_password() );	
		}

}
