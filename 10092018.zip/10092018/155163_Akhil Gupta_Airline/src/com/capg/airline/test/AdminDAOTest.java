/*
 * <-----------------------------------------------******Airline_Akhil Gupta_155163_11thJuly_AbridgeBatch******----------------------------------------------------->
 * Methods of this class tests the methods of Admin DAO class
 */

package com.capg.airline.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.dao.ADMIN.AdminDAO;
import com.capg.airline.dao.ADMIN.IAdminDAO;
import com.capg.airline.exception.MyAirlineException;

public class AdminDAOTest extends AdminDAO {
IAdminDAO adminObj;
AirlineBean beanObj;
	
	public AdminDAOTest() {
		adminObj=new AdminDAO();
		beanObj=new AirlineBean();
	}

	@Test
	public void testAirlineExecutiveSignUp() throws MyAirlineException{												// to test airlineExecutiveSignUp()
		String s="132";
		Long l=Long.parseLong(s);
		beanObj.setMobileNo(l);
		assertNotEquals(-1,adminObj.airlineExecutiveSignUp(beanObj));
		
	}
	

	
	
	
	
	@Test
	public void testAdminSignUp() throws MyAirlineException{												// to test adminSignUp()
		String s="132";
		Long l=Long.parseLong(s);
		beanObj.setMobileNo(l);
		assertNotEquals(-1,adminObj.adminSignUp(beanObj));	}

	
	
	
	
	
	@Test
	public void testCheckIfFlightnoExist() throws MyAirlineException{												// to test cCheckIfFlightnoExist()
			beanObj.setFlightno("00");
			assertEquals(0,adminObj.checkIfFlightnoExist(beanObj) );
	}

	
	
	
	
	
	@Test
	public void testIncreaseFirstClassSeats() throws MyAirlineException{												// to test increaseFirstClassSeats()
		beanObj.setFlightno("000");
		beanObj.setFirstSeatInc(1000);
		assertEquals(-1,adminObj.increaseFirstClassSeats(beanObj) );	
		}

	
	
	
	
	@Test
	public void testIncreaseBusinessClassSeats() throws MyAirlineException {												// to test increaseBusinessClassSeats()
		beanObj.setFlightno("000");
		beanObj.setBusinessSeatInc(1000);
		assertEquals(-1,adminObj.increaseBusinessClassSeats(beanObj) );	
		}

	
	

}
