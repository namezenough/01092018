/*
 * <-----------------------------------------------******Airline_Akhil Gupta_155163_11thJuly_AbridgeBatch******----------------------------------------------------->
 * This class has methods which allows interaction of Airline Executive user interface class methods with AirlineExecutiveDAO class methods
 */


package com.capg.airline.service.AIRLINEEXECUTIVESERVICE;

import java.util.ArrayList;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.dao.AIRLINEEXECUTIVEDAO.AirlineExecutiveDAO;
import com.capg.airline.exception.MyAirlineException;

public class AirlineExecutiveServImpl implements IAirlineExecutiveServ {

	AirlineExecutiveDAO daoae=null;
	 public AirlineExecutiveServImpl() {
		 	daoae=new AirlineExecutiveDAO();
	 }
		
	

	
	
	
	
	@Override
	public int totalBookedSeats()  throws MyAirlineException{
		
		return daoae.totalBookedSeats();
	}


	@Override
	public int futureBookedSeats()  throws MyAirlineException{
		// TODO Auto-generated method stub
		return daoae.futureBookedSeats();
	}


	
	
	
	@Override
	public ArrayList<AirlineBean> checkOccupancy(AirlineBean bean) throws MyAirlineException {
		// TODO Auto-generated method stub
		return daoae.checkOccupancy(bean);
	}

}
