/*
 * <-----------------------------------------------******Airline_Akhil Gupta_155163_11thJuly_AbridgeBatch******----------------------------------------------------->
 */


package com.capg.airline.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.exception.MyAirlineException;
import com.capg.airline.util.AirlineDbUtil;

public class CombinedDAOImpl implements ICombinedDAO {
	Logger logObj=Logger.getRootLogger();

	Connection conn;
	PreparedStatement ps;
	ResultSet  rs;
	@Override
	public int checkLogin(AirlineBean bean) throws MyAirlineException {
		int role=0;
		conn=AirlineDbUtil.getConnection();
		try {
			ps=conn.prepareStatement(IQueryMap.CHECK_LOGIN);
			ps.setString(1, bean.getUser_id());
			rs=ps.executeQuery();
			if(rs.next()){
				if(rs.getString(1).equals(bean.getUser_password())){
					
					if(rs.getString(2).equals("ADMIN"))
						role=1;
					if(rs.getString(2).equals("AIRLINE EXECUTIVE"))
						role=2;
					
				
				}
				else
				{
					System.out.println("Wrong password");
					role=-1;
				}
			}
			else{
				role=0;
				System.out.println("No user with such user id found");
			}
		} catch (SQLException e) {
				throw new MyAirlineException("Do not use spaces");
		}
		
		
		
		return role;
	}

}
