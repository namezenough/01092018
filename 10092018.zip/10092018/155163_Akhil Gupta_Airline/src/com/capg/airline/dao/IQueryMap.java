/*
 * <-----------------------------------------------******Airline_Akhil Gupta_155163_11thJuly_AbridgeBatch******----------------------------------------------------->
 * This Interface contains all the sql queries which are needed by the program to interact with the database
 */

package com.capg.airline.dao;

public interface IQueryMap {
	//to get password and user type of given user name/ user id
	public static final String CHECK_LOGIN="SELECT password, role FROM USERS WHERE username=?";
	//to get all the details of a given flight
	public static final String SEARCH_BY_FLIGHTNO="SELECT * FROM FLIGHT_INFO WHERE flightno=?";
	//to get the details of flights search between 2 cities
	public static final String SEARCH_BY_CITY="SELECT * FROM FLIGHT_INFO WHERE UPPER(ARR_CITY)=UPPER(?) AND UPPER(DEPT_CITY)=UPPER(?) AND dept_date>=sysdate ORDER BY dept_date";
	//to get the max first class seat no booked of a flight
	public static final String CHECK_FIRST_CLASS_SEAT_MAX_NO_RESERVED="SELECT MAX(seat_number) from BOOKING_INFO where flightno=? and class_type=?";
	//to get the max seat no booked of a flight, of given class type
	public static final String CHECK_ANY_CLASS_SEAT_MAX_NO_RESERVED="SELECT MAX(seat_number) from BOOKING_INFO where flightno=? and class_type=?";
	//to get the max business class seat no booked of a flight
	public static final String CHECK_BUSINESS_CLASS_SEAT_MAX_NO_RESERVED="SELECT MAX(seat_number) from BOOKING_INFO where flightno=? and class_type=?";
	//to get the no first class seats  in a flight
	public static final String NO_OF_FIRST_CLASS_SEATS="SELECT no_of_first_seats FROM flight_info where flightno=?";
	//to get the no of business class seats in a flight
	public static final String NO_OF_BUSINESS_CLASS_SEATS="SELECT no_of_business_seats FROM flight_info where flightno=?";
	//to get the total no of seats of both class
	public static final String NO_OF_BOTH_CLASS_SEATS="SELECT no_of_first_seats,no_of_business_seats FROM flight_info where flightno=?";
	//to get the first class fare cost of a flight
	public static final String GET_FIRST_CLASS_FARE_COST="SELECT first_seat_fare from flight_info where flightno=?";
	//to get the business class fare cost of a flight
	public static final String GET_BUSINESS_CLASS_FARE_COST="SELECT business_seat_fare from flight_info where flightno=?";
	//to get the current value of the sequence
	public static final String GET_BOOKING_ID_SEQ_VALUE="SELECT to_char(BOOKING_ID_SEQ.CURRVAL) FROM DUAL";
	//to insert data in the BOOKING_INFO table
	public static final String CONFIRM_BOOKING="INSERT INTO BOOKING_INFO VALUES(to_char(BOOKING_ID_SEQ.nextval),?,1,?,?,?,?,?,?,?)";
	//to get flight no related to a booking ID
	public static final String CHECK_BOOKING_ID="SELECT flightno from Booking_info where booking_id=?";
	//to update mail id of a particular customer 
	public static final String UPDATE_MAIL_ID="	UPDATE BOOKING_INFO SET cust_email=? where booking_id=?";
	// to delete the record of the reserved seat
	public static final String CANCEL_RESERVATION="DELETE FROM Booking_info where booking_id=?";
	//to count the total bookings on the system till date
	public static final String TOTAL_BOOKED_SEATS="SELECT COUNT(BOOKING_ID) FROM BOOKING_INFO";
	//to count the total bookings for future
	public static final String FUTURE_BOOKED_SEATS="SELECT COUNT(BOOKING_ID) FROM BOOKING_INFO, FLIGHT_INFO WHERE BOOKING_INFO.flightno=FLIGHT_INFO.flightno and dept_date>=sysdate";
	//to add login credentials for airline executive in USERS
	public static final String AIRLINE_EXECUTIVE_SIGNUP="INSERT INTO USERS VALUES(to_char(AIRLINE_EXECUTIVE_ID_SEQ.nextval),to_char(AIRLINE_EXECUTIVE_ID_SEQ.currval), 'AIRLINE EXECUTIVE',?)";
	//to add login credentials for admin in USERS
	public static final String ADMIN_SIGNUP="INSERT INTO USERS VALUES(to_char(ADMIN_ID_SEQ.nextval),to_char(ADMIN_ID_SEQ.currval),'ADMIN',?)";
	//get the user id of the last added admin
	public static final String GET_ADMIN_ID_SEQ_VALUE="SELECT to_char(ADMIN_ID_SEQ.CURRVAL) FROM DUAL";
	//to get the user id of the last added airline executive
	public static final String GET_AIRLINE_EXECUTIVE_ID_SEQ_VALUE="SELECT to_char(AIRLINE_EXECUTIVE_ID_SEQ.CURRVAL) FROM DUAL";
	//to get details of flight. If something returns, then flight exists
	public static final String CHECK_IF_FLIGHTNO_EXIST="SELECT * FROM FLIGHT_INFO WHERE flightno=? AND DEPT_DATE>=SYSDATE";
	//to update first class seats of a particular flight
	public static final String UPDATE_FIRST_CLASS_SEAT="UPDATE FLIGHT_INFO SET no_of_first_seats=? where flightno=?";
	//to update business class seats of a particular flight
	public static final String UPDATE_BUSINESS_CLASS_SEAT="UPDATE FLIGHT_INFO SET no_of_business_seats=? where flightno=?";
	//to update arrival date of a particular flight
	public static final String UPDATE_ARR_DATE="UPDATE FLIGHT_INFO SET arr_date=TO_DATE(?, 'yyyy/mm/dd hh24:mi:ss') where flightno=?";
	//to update departure date of a particular flight
	public static final String UPDATE_DEPT_DATE="UPDATE FLIGHT_INFO SET dept_date=TO_DATE(?, 'yyyy/mm/dd hh24:mi:ss') where flightno=?";
	//to update first class fare of a particular flight
	public static final String UPDATE_FIRST_CLASS_FARE="UPDATE FLIGHT_INFO SET first_seat_fare=? where flightno=?";
	//to update business class fare of a particular flight
	public static final String UPDATE_BUSINESS_CLASS_FARE="UPDATE FLIGHT_INFO SET business_seat_fare=?  where flightno=?";
	//to get the details of flights departing on a particular date
	public static final String FLIGHTS_DEPART_ON_DATE="SELECT * FROM FLIGHT_INFO WHERE trunc(dept_date)=to_date(?,'yyyy/mm/dd')";
	//to get the details of flights departing from a particular city
	public static final String FLIGHTS_DEPART_FROM_CITY="SELECT * FROM FLIGHT_INFO WHERE UPPER(dept_city)=upper(?) and dept_date>=sysdate";
	//to get the details of flights arriving to particular city
	public static final String FLIGHTS_ARRIVING_TO_CITY="SELECT * FROM FLIGHT_INFO WHERE UPPER(arr_city)=upper(?) and dept_date>=sysdate";
	// to get the booking s of a particular flight
	public static final String BOOKING_LIST_OF_FLIGHT="SELECT * FROM BOOKING_INFO WHERE flightno=?";
}

