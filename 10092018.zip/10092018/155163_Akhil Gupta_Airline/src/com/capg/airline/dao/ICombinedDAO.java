/*
 * <-----------------------------------------------******Airline_Akhil Gupta_155163_11thJuly_AbridgeBatch******----------------------------------------------------->
 */

package com.capg.airline.dao;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.exception.MyAirlineException;

public interface ICombinedDAO {
	public abstract int checkLogin(AirlineBean bean) throws MyAirlineException;
}
