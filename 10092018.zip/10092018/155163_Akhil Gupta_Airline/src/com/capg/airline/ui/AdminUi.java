
/*
 * <-----------------------------------------------******Airline_Akhil Gupta_155163_11thJuly_AbridgeBatch******----------------------------------------------------->
 * This is a class build to handle to user interface of Admin
 * After admin login, the flow comes to this class.
 */


package com.capg.airline.ui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.exception.MyAirlineException;
import com.capg.airline.service.AirlineValidate;
import com.capg.airline.service.ADMINSERVICE.AdminServImpl;
import com.capg.airline.service.ADMINSERVICE.IAdminServ;

public class AdminUi {      
	Logger logObj=Logger.getRootLogger();

	AirlineBean bean=new AirlineBean();                                            //    Creating bean object globally
	AirlineValidate validateObj=new AirlineValidate();
	AirlineValidate validObj=new AirlineValidate();                                           //    Creating validator class object globally
	String innercount=null;                                           //    Creating a string globally. This is used in Admin() method to handle what option a user chooses.
	Scanner scanner=new Scanner(System.in);
	int loop=0;                                           //    it will help to remove some part of  Admin() function whenever its value will change from 0.
	String funcChoose;                         //    Creating a string globally. This is used in every method to handle what option a user chooses.
	IAdminServ admServObj=new AdminServImpl();
	
	
	public int Admin()  throws MyAirlineException{                       //   start of Admin()
		if(loop==0){  		                       //   start of if condition if(loop==0)
			System.out.println("Press 1 to Log Out");
			System.out.println("Press 2 to exit ");
			System.out.println("Press any other key to continue as Admin");	
			innercount=scanner.nextLine();
		if(innercount.equals("1"))                        //checking if Admin has chosen Log Out                              
		{
			logObj.info("Admin Logged out");
			AirlineUi.main(null);                 //Returning back to main method, to the first appearing GUI
			return 100;							
			
		}
		if(innercount.equals("2"))
		{
			System.out.println("<---Thanks for visiting us--->");
			System.exit(0);						
			
		}
		} // end of if(loop==0)
		
		System.out.println("<--------Admin Main Menu---------->");
		System.out.println("Press 1 to generate an Airline Executive login credentials");
		System.out.println("Press 2 to generate an Admin login credentials");
		System.out.println("Press 3 to Update and manage flight details");
		System.out.println("Press 4 to Generate Reports");
		System.out.println("Press 5 to Log Out");
		System.out.println("Press 6 to exit");
		innercount=scanner.nextLine();
		if(innercount.equals("1")){
			airlineExecutiveSignUp();
		}
		else if(innercount.equals("2")){
			adminSignUp();
		}
		
		else if(innercount.equals("3")){
			updateManageFlight();
		}
		else if(innercount.equals("4")){
			generateAdminReports();
		}
		else if(innercount.equals("5")){
			logObj.info("Admin Logged Out");
			AirlineUi.main(null);                //Returning back to main method, to the first appearing GUI
		}
		else if(innercount.equals("6")){
			System.out.println("Thanks for Visiting.");
			logObj.info("Exit by Admin");
			System.exit(0);
		}
		else {
			System.err.println("Please enter correct number");
			loop=1;
			Admin();
	
		}
		
		return 0;
	
	}
	
	
	
	void airlineExecutiveSignUp()  throws MyAirlineException{      // chosen to generate an Airline Executive login credentials
		System.out.println("Press 1 to go back");					//to go to Admin()
		System.out.println("Press any key other than 1 to go continue");						//to continue here
		funcChoose=scanner.nextLine();
		if(funcChoose.equals("1")){
			loop=1;								//to hide starting lines of Admin()
			Admin();
		}
		else{
			String mobileNo=null;
			do{
		System.out.println("Enter the mobile no of the Executive");
		 mobileNo=scanner.nextLine();
			}while(!validObj.validateMobile(mobileNo));                        //to check if mobile no is having 10 digits or not
			Long mobile=Long.parseLong(mobileNo);					//parsing string to long
		bean.setMobileNo(mobile);
		int userId=admServObj.airlineExecutiveSignUp(bean);          //calling service layer to generate login credentials
		if(userId==0){													//if could not generate userID
			System.out.println("Could not Signup. Please Try again");
			airlineExecutiveSignUp();           //to sign up again
		}
		else{																//in case of successful generation
		System.out.println("Generate Airline Executive User Id is: "+userId);    //print generated userID
		System.out.println("");
		loop=1;												//to hide starting lines of Admin()
		Admin();										//returning back to Admin()
		}
		}
		
	}                           //end of airlineExecutiveSignUp()

	
	
	
	void adminSignUp()  throws MyAirlineException{
		System.out.println("Press 1 to go back");
		System.out.println("Press any other key to go continue");
		funcChoose=scanner.nextLine();
		if(funcChoose.equals("1")){

			loop=1;												//to hide starting lines of Admin()
			Admin();										//returning back to Admin()
		}
		else{
		System.out.println("Enter the mobile no of the Executive");
		String mobileNo=null;
		do{
		 mobileNo=scanner.nextLine();
		}while(!validObj.validateMobile(mobileNo)); //to check if mobile no is having 10 digits or not
		Long mobile=Long.parseLong(mobileNo);
		bean.setMobileNo(mobile);
		int userId=admServObj.adminSignUp(bean);      //calling service layer to generate login credentials
		if(userId==0){ 								//if could not generate userID
			System.out.println("Could not Signup. Please Try again"); 
			logObj.error("Admin Id not generated");
			adminSignUp();                    //to again sign up
		}
		else{
		System.out.println("Generate Admin User Id is: "+userId);  //print generated Admin ID
		System.out.println("");
		logObj.info("Admin ID generated");
		loop=1;												//to hide starting lines of Admin()
		Admin();										//returning back to Admin()
		}
		}
		
	}                //end of adminSignUp();
	
	
	
	
	
	
	
	void updateManageFlight()  throws MyAirlineException{                  //method will provide different options of updation to admin
		System.out.println("Press 1 to go back");
		System.out.println("Press 2 to get list of flights departing from particular location ");
		System.out.println("Press 3 to get list of flights arriving to a particular location ");
		System.out.println("Press any other key to continue with entering flight no");
		funcChoose=scanner.nextLine();
		if(funcChoose.equals("1")){                           //to get back to Admin()
			loop=1;															//to hide starting lines of Admin()
			Admin();
		}
		else if(funcChoose.equals("2")){    // start of get list of flights from particular location
			System.out.println("Enter the departure city");              
			ArrayList<AirlineBean> flightslist=new ArrayList<AirlineBean>();    //to store the data got from database
			bean.setDeptCity(scanner.nextLine());;
			flightslist=admServObj.flightsDepartingFromCity(bean);
			if(flightslist.isEmpty())                            // if no flight is available
			{
				System.out.println("No flight available from this city");     
				logObj.error("No flight available");
				updateManageFlight();                                     //same method called AGAIN     
			}
			else{
				System.out.println("<---Here is the list of available flights departuring from entered location--->:\n");
				Iterator<AirlineBean> it=flightslist.iterator();
				while(it.hasNext()){
					AirlineBean beanob=it.next();
					System.out.println("Flightno: "+ beanob.getFlightno());
					System.out.println("Departure City: "+ beanob.getDeptCity());
					System.out.println("Arrival City: "+beanob.getArrCity());
					System.out.println("Dept Date: "+beanob.getDeptDate());
					System.out.println("Arrival Date: "+beanob.getArrDate());
					System.out.println("");
				}					//END OF while(it.hasNext())
				logObj.info("Available flights list shown");
			}//END OF ELSE
			
		}											//end of  get list of flights from particular location
		
		
		
		
		else if(funcChoose.equals("3")){			//start of get list of flights to a particular location
			System.out.println("Enter the arrival city");
			ArrayList<AirlineBean> flightslist=new ArrayList<AirlineBean>();       //to store the data got from database
			bean.setArrCity(scanner.nextLine());
			flightslist=admServObj.flightsArrivingToCity(bean);          //CALLING FUNCTION TO CHECK THE FLIGHTS
			if(flightslist.isEmpty())						//	if no flight is available
			{
				System.out.println("No flight available from this city");
				logObj.error("No flight Available");
				updateManageFlight();								//call same function again
			}
			else{                   // if flight is available
				System.out.println("<---Here is the list of available flights arriving to entered location--->:\n");
				Iterator<AirlineBean> it=flightslist.iterator();       //making object of iterator
				while(it.hasNext()){
					AirlineBean beanob=it.next();
					System.out.println("Flightno: "+ beanob.getFlightno());
					System.out.println("Departure City: "+ beanob.getDeptCity());
					System.out.println("Arrival City: "+beanob.getArrCity());
					System.out.println("Dept Date: "+beanob.getDeptDate());
					System.out.println("Arrival Date: "+beanob.getArrDate());
					System.out.println("");
				}		//end of while
				logObj.info("Flihgt List Displayed");
			}	//end of else
		}  				//end of else if
		System.out.println("Enter flight no.");
		String flightno=scanner.nextLine();
		bean.setFlightno(flightno);
		int checkExit=admServObj.checkIfFlightnoExist(bean);         //to check the existence of entered flight
		if(checkExit==0){
			System.out.println("Flight Does not exist");		
			logObj.error("Entered Flight does not exist");
			updateManageFlight();			//get back to same method
		}
		else{                     												// start of continue with entering flight no
		System.out.println("Yes, this flight exists");
		System.out.println("Press 1 to Increase FIRST CLASS seats");
		System.out.println("Press 2 to Increase BUSINESS CLASS seats");
		System.out.println("Press 3 to Decrease FIRST CLASS seats");
		System.out.println("Press 4 to Decrease BUSINESS CLASS seats");
		System.out.println("Press 5 to change flight timings");
		System.out.println("Press 6 to change First Class Charges");
		System.out.println("Press 7 to change Business Class Charges");
		System.out.println("Press any other key to get back to Admin panel");
		funcChoose=scanner.nextLine();
		if(funcChoose.equals("1")){													// start of increase first class seats
			System.out.println("Enter the new no of  seats to be added in First Class");
			String validatenum=null;
			do{
			validatenum=scanner.nextLine();
			}while(!validateObj.validateNumber(validatenum));
			bean.setFirstSeatInc(Integer.parseInt(validatenum));
			int firstSeatInc=admServObj.increaseFirstClassSeats(bean);
			if(firstSeatInc==0){
				System.err.println("Could not update. Please Try Again");
				logObj.error("Could not update seats");
				updateManageFlight();
			}
			else if(firstSeatInc==-1){
				System.err.println("Seat no cant exceed 200");
				updateManageFlight();
				
				
			}
			else{
				System.out.println("First Seat No updated");
				loop=1;
				Admin();
				
			}
		}												// end of inc first class seats
		
		
		else if(funcChoose.equals("2")){												// start of inc business class seats
			System.out.println("Enter the new no of seats to be added in Business Class");
			String validatenum=null;
			do{
			validatenum=scanner.nextLine();
			}while(!validateObj.validateNumber(validatenum));
			bean.setBusinessSeatInc(Integer.parseInt(validatenum));
			int bussSeatInc=admServObj.increaseBusinessClassSeats(bean);
			if(bussSeatInc==0){
				System.err.println("Could not update. Please Try Again");
				logObj.error("Could not update seats");
				updateManageFlight();
			}
			else if(bussSeatInc==-1){
				System.err.println("Total seats can't exceed 200");
				logObj.info("Seats Updated");
				updateManageFlight();
			}
			else{
				System.out.println("First Seat No.s updated");
				loop=1;
				Admin();
			}

		} 												// end of inc of business class seats
		
		
		else if(funcChoose.equals("3")){									  // start of decrease seats in first class
		System.out.println("Enter the no of seats you want to decrease in First Class");
		String validatenum=null;
		do{
		validatenum=scanner.nextLine();
		}while(!validateObj.validateNumber(validatenum));
		int firstSeatDec=Integer.parseInt(validatenum);
		bean.setFirstSeatDec(firstSeatDec);
		int firstSeatDecActual = admServObj.decreaseFirstClassSeats(bean);
		if(firstSeatDecActual==0){
			System.out.println("Could not update because all seats are booked.");
			logObj.error("Could not update seats");

			updateManageFlight();
		}
		else if(firstSeatDecActual==firstSeatDec){
			System.out.println("Successfully Removed "+firstSeatDecActual+" seats of FIRST CLASS");
			logObj.info("Seats Updated");
			loop=1;
			Admin();
		}
		else if(firstSeatDecActual<firstSeatDec){
			System.err.println("Successfuly Removed only "+firstSeatDecActual+" seats of FIRST CLASS due to booking of remaining Seats");
			logObj.info("Seats Updated");
			loop=1;
			Admin();
		}
		}																	// end of decrease seats in first class
		
		
		
		
		
		
		
		else if(funcChoose.equals("4")){									// start of decrease seats in business class
			
			System.out.println("Enter the no of seats you want to decrease in Business Class");
			String validatenum=null;
			do{
			validatenum=scanner.nextLine();
			}while(!validateObj.validateNumber(validatenum));
			int businessSeatDec=Integer.parseInt(validatenum);
			bean.setBusinessSeatDec(businessSeatDec);
			int businessSeatDecActual = admServObj.decreaseBusinessClassSeats(bean);
			if(businessSeatDecActual==0){
				System.out.println("Could not update because all seats are booked.");
				logObj.error("Could not update seats");
				updateManageFlight();
			}
			else if(businessSeatDecActual==businessSeatDec){
				System.out.println("Successfully Removed "+businessSeatDecActual+" seats of Business CLASS");
				logObj.info("Seats Updated");
				loop=1;
				Admin();
			}
			else if(businessSeatDecActual<businessSeatDec){
				System.err.println("Successfuly Removed only "+businessSeatDecActual+" seats of Business CLASS due to booking of remaining Seats");
				logObj.info("Seats Updated");
				loop=1;
				Admin();
			}
			
			
			
			
		}																	//end of decrease seats in business class
		
		
		
		else if(funcChoose.equals("5")){											// start of change flight timings
			
			System.out.println("Enter departure date and time in the format: 'yyyy/mm/dd hh24:mi:ss'");
			String dateStr=null;
			do{
				dateStr=scanner.nextLine();
			}while(!validateObj.validateDateTime(dateStr));
			bean.setDeptDate(dateStr);
			System.out.println("Enter arrival date and time in the format: 'yyyy/mm/dd hh24:mi:ss'");
			do{
				dateStr=scanner.nextLine();
			}while(!validateObj.validateDateTime(dateStr));
			bean.setArrDate(dateStr);
			int res=admServObj.updateFlightTiming(bean);
			if(res==1){
				System.out.println("<---Date Updated Successfully--->");
				logObj.info("Date Updated");
				loop=1;
				Admin();
			}
			else{
				System.err.println("Sorry Could not update date. Try Again");
				logObj.error("Could not update date");
				updateManageFlight();
			}
		}																							// end of change flight timings
		
		
		
		
		else if(funcChoose.equals("6")){												// start of updating first class charges(<20000)
			System.out.println("Enter the new charges for FIRST CLASS seats");
			String validatenum=null;
			do{
			validatenum=scanner.nextLine();
			}while(!validateObj.validateNumber(validatenum));
			int firstClassFare=Integer.parseInt(validatenum);
			if(firstClassFare<=20000)
			{
				bean.setFirstClassFare(firstClassFare);
				if(admServObj.updateFirstCLassFare(bean)==1){
					System.out.println("First Class Fare Updated Successfully");
					logObj.info("First class Fares Updated");
					updateManageFlight();
				}
				else{
					System.err.println("Sorry, Could not update");
					logObj.error("First Class Fares could not be updated");
					updateManageFlight();
				}
			}
			else{
				System.err.println("Cost must be less than 20000");
				logObj.error("First CLass Fare value cant be greater than 20000");
				updateManageFlight();
			}
		}          // end of updating first class charges
		
		
		
		
		else if(funcChoose.equals("7")){												// start of updating business class charges(<20000)
			System.out.println("Enter the new charges for Business CLASS seats");
			String validatenum=null;
			do{
			validatenum=scanner.nextLine();
			}while(!validateObj.validateNumber(validatenum));
			int businessClassFare=Integer.parseInt(validatenum);
			if(businessClassFare<=20000)
			{
				bean.setBusinessClassFare(businessClassFare);
				if(admServObj.updateBusinessCLassFare(bean)==1){												// calling service class method
					System.out.println("Business Class Fare Updated Successfully");
					logObj.info("Business Class Fares Updated");
					updateManageFlight();
				}
				else{
					System.err.println("Sorry, Could not update");
					logObj.error("Business Class Fare not updated");
					updateManageFlight();
				}
			}
			else{
				System.err.println("Cost must be less than 20000");
				logObj.error("Business cass fare cost cant be more than 20000");
				updateManageFlight();
			}
		}												// end of updating business class charges
		
		else{									//start of back to admin's main menu
			System.out.println("Taking back to Admin Menu");
			loop=1;
			Admin();
		}												// end of back to admin's main menu
		
		
		
		}												// end of continue with entering flightno
		
	}     												// end of method updateManageFlight()
	
	
	
	
	
	
	void generateAdminReports()  throws MyAirlineException{				//start of method generateAdminReports
		System.out.println("Press 1 to go back, else to continue");
		funcChoose=scanner.nextLine();
		if(funcChoose.equals("1")){
			loop=1;
			Admin();
		}
		else{
			System.out.println("Press 1 to get list of flights daparting on a particular day");
			System.out.println("Press 2 to get list of flights departing from particular location");
			System.out.println("Press 3 to get list of flights arriving to a particular location");
			System.out.println("Press 4 to see bookings of specific flight");
			System.out.println("Press 5 to go back to Admin's main menu");
			System.out.println("Else to exit");
			funcChoose=scanner.nextLine();
			if(funcChoose.equals("1")){       //start of get list of flights daparting on a particular day
				System.out.println("Enter departure date int the format 'yyyy/mm/dd'");
				String myDate=null;
				do{
					myDate=scanner.nextLine();
				}while(!validateObj.validateDate(myDate));
				bean.setDeptDate(myDate);
				ArrayList<AirlineBean> flightslist=new ArrayList<AirlineBean>();
				flightslist=admServObj.flightsDepartingOnDate(bean);
				if(flightslist.isEmpty())
				{
					System.out.println("No flight available on this particular day");
					generateAdminReports();
				}
				else{
					System.out.println("<---Here is the list of available flights--->:\n");
					Iterator<AirlineBean> it=flightslist.iterator();
					while(it.hasNext()){
						AirlineBean beanob=it.next();
						System.out.println("Flightno: "+ beanob.getFlightno());
						System.out.println("Departure City: "+ beanob.getDeptCity());
						System.out.println("Arrival City: "+beanob.getArrCity());
						System.out.println("");
					}
					loop=1;
					Admin();
				}
				
			}                                   // end of get list of flights daparting on a particular day
			
			
			else if(funcChoose.equals("2")){    // start of get list of flights from particular location
				System.out.println("Enter the departure city");
				ArrayList<AirlineBean> flightslist=new ArrayList<AirlineBean>();
				bean.setDeptCity(scanner.nextLine());;
				flightslist=admServObj.flightsDepartingFromCity(bean);
				if(flightslist.isEmpty())							//if no data is retrieved 
				{
					System.out.println("No flight available from this city");
					logObj.error("No fight available for given input");
					generateAdminReports();
				}
				else{
					System.out.println("<---Here is the list of available flights departuring from entered location--->:\n");
					Iterator<AirlineBean> it=flightslist.iterator();
					while(it.hasNext()){
						AirlineBean beanob=it.next();
						System.out.println("Flightno: "+ beanob.getFlightno());
						System.out.println("Departure City: "+ beanob.getDeptCity());
						System.out.println("Arrival City: "+beanob.getArrCity());
						System.out.println("Dept Date: "+beanob.getDeptDate());
						System.out.println("Arrival Date: "+beanob.getArrDate());
						System.out.println("");
					}							//end of while loop
					logObj.info("List of flight is displayed");
					loop=1;
					Admin();
				}							//end of else
				
			}											//end of  get list of flights from particular location
			
			
			
			
			else if(funcChoose.equals("3")){			//start of get list of flights to a particular location
				System.out.println("Enter the arrival city");
				ArrayList<AirlineBean> flightslist=new ArrayList<AirlineBean>();
				bean.setArrCity(scanner.nextLine());;
				flightslist=admServObj.flightsArrivingToCity(bean);
				if(flightslist.isEmpty())
				{
					System.out.println("No flight available from this city");
					logObj.error("No flight available");
					generateAdminReports();
				}
				else{
					System.out.println("<---Here is the list of available flights arriving to entered location--->:\n");
					Iterator<AirlineBean> it=flightslist.iterator();
					while(it.hasNext()){
						AirlineBean beanob=it.next();
						System.out.println("Flightno: "+ beanob.getFlightno());
						System.out.println("Departure City: "+ beanob.getDeptCity());
						System.out.println("Arrival City: "+beanob.getArrCity());
						System.out.println("Dept Date: "+beanob.getDeptDate());
						System.out.println("Arrival Date: "+beanob.getArrDate());
						System.out.println("");
					}							//end of while
					logObj.info("List of availbale flights is displayed");
					loop=1;
					Admin();
				}							//end of else
			}							//end of get list of flights to a particular location
			
			
			else if(funcChoose.equals("4")){							//start of checking flight bookings
				System.out.println("Enter the flight no whose booking you want to check ");
				ArrayList<AirlineBean> listOfBookings= new ArrayList<AirlineBean>();
				bean.setFlightno(scanner.nextLine());
				listOfBookings=admServObj.bookingListOfFlight(bean);
				if(listOfBookings.isEmpty()){
					System.out.println("No record found");
					logObj.error("No booking found");
				}
				else{
					System.out.println("<---Here is the list of booking-->");
					Iterator< AirlineBean> it= listOfBookings.iterator();
					while(it.hasNext()){
						AirlineBean bean=it.next();
						System.out.println(" Booking ID: "+bean.getBookingId() +" Email id: "+ bean.getEmailID()+ " Class type: "+ bean.getClassType()+" Fare Cost: "+bean.getFareCost() + " Seat No booked: "+ bean.getSeatNoToBeBooked()+" Credit Card No: "+bean.getCreditcardno() + " Departure City: "+bean.getDeptCity()+" Arrival City: "+bean.getArrCity());
						System.out.println("");
					}
					logObj.info("Bookings of flight shown");
					loop=1;
					Admin();
				}
			}							//end of checking bookings of flight
			
			
			
			else if(funcChoose.equals("5")){							//to get back to Admin()
				loop=1;								//to hide starting lines of Admin()
				Admin();
			}
			else{							//if entered unnecessary value
				System.out.println("Thank You for Visiting!");
				logObj.info("Exit by Admin");
				System.exit(0);							//terminate program
			}
			
			
			
		}
	}							//end of method generateAdminReports
	
}





	