/*
 * <-----------------------------------------------******Airline_Akhil Gupta_155163_11thJuly_AbridgeBatch******----------------------------------------------------->
 * This class holds the user interface of Customer
 * Customer interacts with the system using this class
 * It interacts with Customer service class 
 */

package com.capg.airline.ui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.exception.MyAirlineException;
import com.capg.airline.service.AirlineValidate;
import com.capg.airline.service.CUSTOMERSERVICE.CustomerServImpl;
import com.capg.airline.service.CUSTOMERSERVICE.ICustomerServ;

public class CustomerUi {                      
	Logger logObj;             //object of logger is created
	AirlineValidate validateObj;    //object of validator class is created
	int loop=0;                                        //its value will be used to prevent  some lines  from printing
	int viewupdateloop=0;
	AirlineBean bean;				//bean class object
	ICustomerServ custservobj;       //service class object
	String innercount=null;
	String custFirstChoose=null;
	Scanner scanner=new Scanner(System.in);
	public CustomerUi(){                          //Starting of Non parameterized constructor of CustomerUi
		custservobj=new CustomerServImpl(); 
		bean=new AirlineBean();
		validateObj=new AirlineValidate();
		logObj=Logger.getRootLogger();
	}                      //End of Non parameterized constructor of CustomerUi
	
	
	
	
	
	int Customer()  throws MyAirlineException{        //start of method Customer()
		if(loop==0){
	System.out.println("You are a customer.");
	System.out.println("Press 1 to get back to main menu");
	System.out.println("Press 2 to exit");
	System.out.println("Press any other key to continue to customer's main menu");
	innercount=scanner.next();
	scanner.nextLine();
	if(innercount.equals("1"))             //to get back to main menu
	{
		logObj.info("Returned to main menu");
		AirlineUi.main(null);
		     return 100;                         
		
	}
	if(innercount.equals("2"))			//to terminate program
	{
		System.out.println("Thanks for visiting us");
		logObj.error("Exit by customer");
		System.exit(0);
		return 4;                                 
		
	}
	
		}                          //end of if(loop==0)
	System.out.println("<---------Customer's Main Menu--------->");
	System.out.println("1: Search flight details");
	System.out.println("2: Reserve a flight");
	System.out.println("3: View/Update/Cancel any Reservation");
	System.out.println("4: Main Menu");
	System.out.println("5: Exit");
	
	custFirstChoose=scanner.nextLine();
	if(custFirstChoose.equals("1")){            //search flight details
		logObj.info("Flight details search chosen");
		SearchFlight();
	}
	else if(custFirstChoose.equals("2")){
		logObj.info("Reserve a flight chosen");
		ReserveFlight();
	}
	else if(custFirstChoose.equals("3")){
		viewupdateloop=0;
		viewUpdateCancelFlight();
	}
	else if(custFirstChoose.equals("4")){			//main method called 
		AirlineUi.main(null);
	}
	else if(custFirstChoose.equals("5")){ 				  //customer chosen exit
		System.out.println("Thanks for visiting us");
		logObj.error("Exit by customer");
		System.exit(0);
		return 4;
	}
	else{              //unwanted input
		System.out.println("Sorry. You have chosen wrong number.");
		Customer();
	}
	
	
	
	return 0;

}
	
	int SearchFlight()  throws MyAirlineException{
		String searchCount=null;
		System.out.println("Press 1 to search by flightno");
		System.out.println("Press 2 to search flights between 2 locations (Use Capital letters)");
		System.out.println("Press 3 to go back");
		searchCount=scanner.nextLine();
		if(searchCount.equals("1")) //start of search by flightno
		{
			System.out.println("Enter flight no.");
			bean.setFlightno(scanner.nextLine());
			AirlineBean beanFlight=custservobj.searchFlightByNo(bean);
			if(beanFlight!=null){
				System.out.println("Flight Number: " +beanFlight.getFlightno()+ "\nAirline: "+ beanFlight.getAirline()+"\nDep City: "+ beanFlight.getDeptCity()+"\nArrival City: " + beanFlight.getArrCity());
				System.out.println("Departure date: " +beanFlight.getDeptDate()+ "\nDeparture Time: "+beanFlight.getDeptTime()+"\nArrival Date: "+beanFlight.getArrDate()+ "\nArrival time: " + beanFlight.getArrTime());
				System.out.println("First Class Charge:"+beanFlight.getFirstClassFare());
				System.out.println("Business Class Charge:+ "+beanFlight.getBusinessClassFare());
				System.out.println("");
				logObj.info("Flight Details Displayed");
				loop=1;
				Customer();
			}
			else{
				System.out.println("Search again");
				logObj.error("No flight found");
				SearchFlight();
			}
			
		} //end of search by flightno
		
		
		
		
		
		
		
		else if(searchCount.equals("2")){ //Start of search flights between 2 locations
			System.out.println("Enter the following details:");
			System.out.println("Enter Departure City(Use capital letters)");
			bean.setArrCity(scanner.nextLine());
			System.out.println("Enter Arrival City(Use capital letters)");
			bean.setDeptCity(scanner.nextLine());
			LinkedHashMap<String, AirlineBean> lhashmap=custservobj.searchByCity(bean);
			if(lhashmap.isEmpty()){                                                     //if no flight is found
				System.out.println("No record found. Check for valid data");
				logObj.error("No flight found between given cities"); 
				SearchFlight();
			}else{															//if flight is found
				System.out.println("Here is the list of available flights, ordered by date");
				
			for(Map.Entry<String,AirlineBean> mentry: lhashmap.entrySet()){               //to print list of flights
				bean=mentry.getValue();
				System.out.println("Details of FLight No:"+ bean.getFlightno());
				System.out.println("\nAirline: "+ bean.getAirline()+"\nDep City: "+ bean.getDeptCity()+"\nArrival City: " + bean.getArrCity());
				System.out.println("Departure date and Time: " +bean.getDeptDate()+"\nArrival Date and Time: "+bean.getArrDate());
				System.out.println("");
			}
			logObj.info("Available flights are displayed");
			}
			
			loop=1;  // so that initial data of customer is not visible
			Customer();				
		}
		
		else if(searchCount.equals("3")){
			loop=1;										//to hide some lines of Customer()
			Customer();
		}
			
		else{					//for unwanted input
			System.out.println("You entered wrong number");
			SearchFlight();
		}
		
		return 0;
	}// searchFlight() ends here
	
	
	
	
	
	
	int ReserveFlight() throws MyAirlineException{
		int resCount=0;
		System.out.println("Press 1 to continue, or Press any other key to go back");
		String validatenum=null;
		do{
		validatenum=scanner.nextLine();
		}while(!validateObj.validateNumber(validatenum));
		resCount=Integer.parseInt(validatenum);
		if(resCount==1){
			
			
			System.out.println("Enter the following details:");
			System.out.println("Enter Departure City (Use capital letters)");  //enter departure city
			bean.setArrCity(scanner.nextLine());
			System.out.println("Enter Arrival City (Use capital letters)");			//enter arrival city
			bean.setDeptCity(scanner.nextLine());
			LinkedHashMap<String, AirlineBean> lhashmap=custservobj.searchByCity(bean);
			if(lhashmap.isEmpty()){										//if no data found
				System.out.println("No record found. Check for valid data");
				logObj.info("No flight found");
				SearchFlight();
			}
			else{											//IF related data is found
				System.out.println("Here is the list of available flights, ordered by date");
			for(Map.Entry<String,AirlineBean> mentry: lhashmap.entrySet()){
				bean=mentry.getValue();
				System.out.println("Details of Flight No:"+ bean.getFlightno());
				System.out.println("\nAirline: "+ bean.getAirline()+"\nDep City: "+ bean.getDeptCity()+"\nArrival City: " + bean.getArrCity());
				System.out.println("Departure date and Time: " +bean.getDeptDate()+"\nArrival Date and Time: "+bean.getArrDate());
				System.out.println("");
				}
			logObj.info("Flight found and displayed");
			confirmBookingUi(lhashmap);
			}
			
		}
		else{
			loop=1;
			Customer();
		}
		return 0;
	}  //reserveFlight() ends here
	
	
	
	
	
	
	int confirmBookingUi(LinkedHashMap<String, AirlineBean> lhashmap) throws MyAirlineException{     //method to do operations of booking confirmation
		
		String bookingId=null;
		System.out.println("Enter the flight no. that you want to book");
		bean.setFlightno(scanner.nextLine());
		if(lhashmap.containsKey(bean.getFlightno())){										//if entered flight no is correct
			System.out.println("Press 1 for business class booking");						//choose booking class
			System.out.println("Press 2 for first class booking");					//choose booking class
			String classbooking="0";
			classbooking=scanner.nextLine();					
			if(classbooking.equals("1")){
				bean.setFlightClass("BUSINESS CLASS");
				
			}
			else if(classbooking.equals("2")){
				bean.setFlightClass("FIRST CLASS");
			}
			else{ 																//if no class is  selected 
				System.out.println("Sorry, you pressed wrong key");
				confirmBookingUi(lhashmap);
			}
			System.out.println("Enter the no of seats you want to book");    //get no of seats to be booked
			String validatenum=null;
			int num=50;	
			while(num>10){
			do{	
			validatenum=scanner.nextLine();
			}while(!validateObj.validateNumber(validatenum));
				num=Integer.parseInt(validatenum);
				if(num>10)
				{
					System.err.println("1 user cant book for more than 10 seats");
				}
			}
			bean.setNoOfBookings(Integer.parseInt(validatenum));
			bean.setSeatNoToBeBooked(custservobj.checkAvailability(bean));		//call method to ckeck if seats are available
			if(bean.getSeatNoToBeBooked()==-1)
			{
				System.out.println("Sorry, No seat available. Please check for any other available flight");
				logObj.error("Seat not available");
				confirmBookingUi(lhashmap);
			}									//end of no seat avail
			
			System.out.println("Seats are available. Please enter the following details."); //seats are avail
			String emailId=null;
			System.out.println("Enter your email id:");
			do{	
				emailId=scanner.nextLine();				//get mail id
			}
			while(!validateObj.validateEmail(emailId));			//validate mail id
			bean.setEmailID(emailId);
			System.out.println("Enter 12 digits Credit Card number");
			String creditCard=null;
			do{																//validate credit card no
				creditCard=scanner.nextLine();
			}while(!validateObj.validateCreditCard(creditCard));

			bean.setCreditcardno(creditCard);
			ArrayList<String> listOfBookingId=new ArrayList<String>();
			listOfBookingId=custservobj.confirmBoking(bean);
			if(listOfBookingId.isEmpty()){
				System.err.println("Could not book your tickets");
				logObj.error("Tickets not booked");
				confirmBookingUi(lhashmap);
			}
			else{
				System.out.println("Booking Successful");								//booking successfull
				System.out.println("Your booking Ids are: ");
				Iterator<String> it=listOfBookingId.iterator();
				while(it.hasNext())
				{
					System.out.println(it.next());
				}
				logObj.info("Tickets Booked");
				System.out.println("1: ANOTHER BOOKING?");
				System.out.println("2: NO another booking");
				bookingId=scanner.nextLine();
				if(bookingId.equals("1")){     //To do another booking
					confirmBookingUi(lhashmap);
				}
				else{
					loop=1;
					Customer();
				}					//end of elses
				
			}									//end of booking successful
			
			
			
		}									//			end of if(lhashmap.containsKey(bean.getFlightno()))						
		
		else{   // if entered flight no is not correct
			System.out.println("Sorry you didn't enter correct flight no. Please try again");
			confirmBookingUi(lhashmap);
		}
		return 0;
		
	}  //confirmBookinhUi() ends here
	
	
	
	
	
	
	
	int viewUpdateCancelFlight() throws MyAirlineException{    //start of method 
		String flightno=null;
		if(viewupdateloop==0){
		System.out.println("Enter Your booking Id:");
		bean.setBookingId(scanner.nextLine());
		flightno=custservobj.checkBookingId(bean);
		if(flightno==null){
			System.out.println("Booking Id Does not exist");
			logObj.error("Booking Id not found");
			viewUpdateCancelFlight();
		}
		bean.setFlightno(flightno);
		}
		logObj.info("Booking ID found");
		System.out.println("1: View Your Booked Flight Details");
		System.out.println("2: Update your email id");
		System.out.println("3: Cancel Reservation");
		System.out.println("4: Go Back");
		String options=scanner.nextLine();
		if(options.equals("1")){   //view your flight details
			AirlineBean beanFlight= custservobj.searchFlightByNo(bean);
			System.out.println("Flight Number: " +beanFlight.getFlightno()+ "\nAirline: "+ beanFlight.getAirline()+"\nDep City: "+ beanFlight.getDeptCity()+"\nArrival City: " + beanFlight.getArrCity());
			System.out.println("Departure date: " +beanFlight.getDeptDate()+ "\nDeparture Time: "+beanFlight.getDeptTime()+"\nArrival Date: "+beanFlight.getArrDate()+ "\nArrival time: " + beanFlight.getArrTime());
			System.out.println("");
			logObj.info("Booking details printed");
			viewupdateloop=1;
			viewUpdateCancelFlight();
			
		}
		else if(options.equals("2")){  //Update your mail id
			System.out.println("Enter your mail id");
			String emailId=null;
			do{																							//validating mail Id
				emailId=scanner.nextLine();
			}
			while(!validateObj.validateEmail(emailId));
			bean.setEmailID(emailId);
			System.out.println("Press 1 to confirm and other key to cancel");
			
			if(scanner.next().equals("1"))
			{
				
			if(custservobj.updateMailId(bean)==1){
				System.out.println("**Mail id Successfully Updated**");
				logObj.info("Mail id updated");
				viewupdateloop=1;
				viewUpdateCancelFlight();
			}
			else{																											//could not update mail id
				System.err.println("Could not update mail id");
				logObj.error("Could not update mail id");
			}}
			else{
				viewupdateloop=1;																		//to hide some lines
				viewUpdateCancelFlight();
			}
			
			
			
		}// mail id updating ends here
		
		else if(options.equals("3")){													//cancel reservation
			System.err.println("Note: Only 75% of money will be returned");
			System.out.println("Press 1 to cancel your reservation any other key to go back");
			if(scanner.nextLine().equals("1")){				//confirm cancellation
				if(custservobj.cancelReservation(bean)==1){
					System.out.println("Reservation cancelled");
					logObj.info("Reservation cancelled");
					loop=1;
					Customer();
				}
				else{														//reservation not cancelled
					System.err.println("Did not cancel");
					logObj.error("Reservation not cancelled");
					viewupdateloop=1;
					viewUpdateCancelFlight();
				}
				
				
			}else{
				viewupdateloop=1;
				viewUpdateCancelFlight();
				
			}
		}
		else if(options.equals("4")){
			loop=1;
			Customer();
		}
		else{
			System.err.println("Enter correct number.");
			viewupdateloop=1;
			viewUpdateCancelFlight();
		}
		
		
		return 0;
	} //viewUpdateCancelFlight() ends here
	
	
	
	
	
}