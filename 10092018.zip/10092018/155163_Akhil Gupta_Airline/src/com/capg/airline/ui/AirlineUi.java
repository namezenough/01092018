/*
 * <-----------------------------------------------******Airline_Akhil Gupta_155163_11thJuly_AbridgeBatch******----------------------------------------------------->
 * This is the class which is having main method
 * Flow of project starts from this class
 * It presents the first screen to the user
 */

package com.capg.airline.ui;

import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capg.airline.beans.AirlineBean;
import com.capg.airline.exception.MyAirlineException;
import com.capg.airline.service.AirlineValidate;
import com.capg.airline.service.CombinedServImpl;

public class AirlineUi {
	Logger logObj;
	AirlineBean bean;
	int innercount = 0;
	int logincheck = 0;
	String user_id;
	Scanner scanner;
	AdminUi adminObj;
	AirlineExecutiveUi aeUiObj;

	String user_password;
	static int noOfLoginAttempts = 0;

	public AirlineUi() {
		logObj = Logger.getRootLogger();
		bean = new AirlineBean();
		scanner = new Scanner(System.in);
		adminObj = new AdminUi();
		aeUiObj = new AirlineExecutiveUi();
	}

	public static void main(String[] args) throws MyAirlineException {
		Logger logObj = Logger.getRootLogger();

		CustomerUi cuiobj = new CustomerUi();
		AirlineUi airObj = new AirlineUi();
		AirlineValidate validateObj = new AirlineValidate();

		System.out.println("*********************************************");
		System.out.println("<------------------Airline------------------>");
		System.out.println("*********************************************");
		System.out.println("");
		Scanner scanner = new Scanner(System.in);
		int count = 100; // so that next loop must function in a good way and must not end abruptly
		String funCount = null;

		do { // 100 will be returned to get back to main menu.
			System.out.println("Press 1 to Search flight details");
			System.out.println("Press 2 to Reserve a flight");
			System.out.println("Press 3 to View/Update/Cancel any Reservation");
			System.out.println("Press 4 to To exit");
			System.out.println("Press 5 to To Login");
			funCount = scanner.nextLine();
			switch (funCount) { // main switch (switch 1)
			/*
			 * Case 1 of main switch(switch 1) for customer 
			 * Customer will be able to see only customer functionalities now
			 */
			case "1":
				logObj.info("Customer access");
				count = cuiobj.Customer();
				break;

				/*
				 * Case 2 of main switch(switch 1) for customer
				 * Customer will be able to see only customer functionalities now
				 */	
			case "2":

				logObj.info("Customer access");
				count = cuiobj.Customer();
				break;

			/*
			 * Case 3 of main switch(switch 1 for Customer )
			 * Customer will be able to see only customer functionalities now
			 */
			case "3":
				logObj.info("Customer access");
				count = cuiobj.Customer();
				break;

			/*
			 * Case 4 of switch statement to exit the program
			 */
			case "4":
				System.out.println("You have chosen Exit");
				logObj.error("Exit");
				System.out.println("Thank for visit");
				System.exit(0);
				break; // final break of case 4 of switch 1
				
				
				
				
			/*
			 * Case 5 of switch statement to check login details
			 */
			case "5":
				count = airObj.checkLoginUi();

				break;
				
				
			default:
				System.out.println("You have chosen wrong number");
				break;

			}
			if (count != 4 && count != 100) {
				System.err.flush();
				System.out.println("Choose:");
				System.err
						.println("4 to Exit, other number to continue with main menu");
				String validatenum = null;
				do {
					validatenum = scanner.nextLine();
				} while (!validateObj.validateNumber(validatenum));
				count = Integer.parseInt(validatenum);
			}
		} while (count != 4);
		scanner.close();

	} // End of main method

	int checkLoginUi() throws MyAirlineException {

		if (noOfLoginAttempts < 3) {
			AirlineBean bean = new AirlineBean();
			System.out.println("Enter your user_id");
			bean.setUser_id(scanner.nextLine()); // input for userID
			System.out.println("Enter your password");
			bean.setUser_password(scanner.nextLine()); // input for Password
			CombinedServImpl combServObj = new CombinedServImpl();

			int role = combServObj.checkLogin(bean);
			if (role == 0) { // role=0 => invaild
				System.out.println("Try Again");
				noOfLoginAttempts++;
				logObj.error("Error in LogIn");
				checkLoginUi();
			} else if (role == -1) { // role=-1 => invaild
				System.out.println("Try Again");
				noOfLoginAttempts++;
				logObj.error("Error in LogIn");

				checkLoginUi();
			} else if (role == 1) { // role=1 => Admin Login
				System.out.println("You are ADMIN");
				logObj.info("Admin Login Successful");
				return adminObj.Admin();
			} else {
				if (role == 2) { // role=2 => Airline Executive Login
					System.out.println("You are AIRLINE EXCUTIVE");
					logObj.info("Airline Executive Login");
					return aeUiObj.AirlineExecutive();
				} // end of if(role==2)
			}

		} // if no of login attempts are within 3
		else { // if no of login attempts exceed 3
			System.err.println("You have reached your max login attempts.");
			logObj.error("Reached Max Login Attempts");

		}

		return 0;
	} // end of method checkLoginUi()

}// End of class AirlineUi
