/*
 * <-----------------------------------------------******Airline_Akhil Gupta_155163_11thJuly_AbridgeBatch******----------------------------------------------------->
 * This class has a static method which returns the connection every time. So, there is no need to create connection for each class separately
 */

package com.capg.airline.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.log4j.Logger;





public class AirlineDbUtil {
	public static Connection getConnection() {
		Connection conn=null;
		Logger logObj=Logger.getRootLogger(); //Object of logger is created
		 try {                                  //try starts here
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg212","training212");  //to set database path
		}										//try ends here
		 catch (ClassNotFoundException | SQLException e) {   
			 logObj.error("Porblem in eatablishing connection with database "+e);
			System.out.println("Problem in establishing connection with database");
		}
		 
		 
			
		 return conn;
		 
	}
}
